package com.hms.service;

import com.hms.dto.appointment.*;
import com.hms.entity.*;
import com.hms.repository.*;
import org.springframework.stereotype.Service;
import java.time.*;

@Service
public class AppointmentService {
    private final AppointmentRepository apptRepo;
    private final DoctorRepository doctorRepo;
    private final PatientRepository patientRepo;
    private final DoctorService doctorService;

    public AppointmentService(AppointmentRepository a, DoctorRepository d, PatientRepository p, DoctorService ds){
        this.apptRepo=a; this.doctorRepo=d; this.patientRepo=p; this.doctorService=ds;
    }

    public AppointmentResponse book(AppointmentRequest req){
        Doctor d = doctorRepo.findById(req.getDoctorId()).orElseThrow(() -> new RuntimeException("Doctor not found"));
        Patient p = patientRepo.findById(req.getPatientId()).orElseThrow(() -> new RuntimeException("Patient not found"));
        LocalDate date = LocalDate.parse(req.getDate());
        LocalTime time = LocalTime.parse(req.getTime());

        if(!doctorService.availableSlots(d.getId(), date).contains(time))
            throw new RuntimeException("Slot not available");

        Appointment a = new Appointment();
        a.setDoctor(d); a.setPatient(p); a.setDate(date); a.setTime(time);
        a = apptRepo.save(a);

        AppointmentResponse res = new AppointmentResponse();
        res.setAppointmentId(a.getId());
        res.setDoctorName(d.getFullName());
        res.setPatientName(p.getFullName());
        res.setDate(a.getDate().toString());
        res.setTime(a.getTime().toString());
        res.setStatus(a.getStatus().name());
        return res;
    }

    public void cancel(Long id){
        Appointment a = apptRepo.findById(id).orElseThrow(() -> new RuntimeException("Appointment not found"));
        a.setStatus(Appointment.Status.CANCELLED);
        apptRepo.save(a);
    }
}
