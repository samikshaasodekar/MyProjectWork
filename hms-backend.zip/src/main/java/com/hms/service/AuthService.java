package com.hms.service;

import com.hms.entity.*;
import com.hms.repository.*;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.Collections;

@Service
public class AuthService implements UserDetailsService {
    private final UserRepository userRepo;
    private final PatientRepository patientRepo;
    private final BCryptPasswordEncoder encoder;

    public AuthService(UserRepository u, PatientRepository p, BCryptPasswordEncoder e) {
        this.userRepo=u; this.patientRepo=p; this.encoder=e;
    }

    public User registerPatient(String username, String rawPassword){
        if(userRepo.findByUsername(username).isPresent())
            throw new RuntimeException("Username already exists");
        User u = new User();
        u.setUsername(username);
        u.setPassword(encoder.encode(rawPassword));
        u.setRole(Role.PATIENT);
        return userRepo.save(u);
    }

    public User registerDoctorAccount(String username, String commonPassword){
        if(userRepo.findByUsername(username).isPresent())
            throw new RuntimeException("Username already exists");
        User u = new User();
        u.setUsername(username);
        u.setPassword(encoder.encode(commonPassword));
        u.setRole(Role.DOCTOR);
        return userRepo.save(u);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User u = userRepo.findByUsername(username).orElseThrow(() -> new UsernameNotFoundException("User not found"));
        String role = "ROLE_" + u.getRole().name();
        return new org.springframework.security.core.userdetails.User(u.getUsername(), u.getPassword(),
                Collections.singletonList(new SimpleGrantedAuthority(role)));
    }
}
