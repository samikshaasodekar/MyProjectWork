package com.hms.service;

import com.hms.dto.doctor.DoctorDTO;
import com.hms.entity.*;
import com.hms.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AdminService {
    private final DoctorRepository doctorRepo;
    private final PatientRepository patientRepo;
    private final BillRepository billRepo;
    private final AuthService authService;

    public AdminService(DoctorRepository d, PatientRepository p, BillRepository b, AuthService a){
        this.doctorRepo=d; this.patientRepo=p; this.billRepo=b; this.authService=a;
    }

    @Transactional
    public Doctor createDoctor(DoctorDTO dto, String doctorUsername, String commonPassword){
        User user = authService.registerDoctorAccount(doctorUsername, commonPassword);
        Doctor d = new Doctor();
        d.setFullName(dto.getFullName());
        d.setQualification(dto.getQualification());
        if ("MD".equalsIgnoreCase(dto.getQualification())) {
            if (dto.getSpecialization()==null || dto.getSpecialization().isBlank())
                throw new RuntimeException("Specialization required for MD");
            d.setSpecialization(dto.getSpecialization());
        } else {
            d.setSpecialization("General");
        }
        d.setContactNumber(dto.getContactNumber());
        double base = (dto.getBaseFee()!=null)? dto.getBaseFee() :
                ("MD".equalsIgnoreCase(dto.getQualification()) ? 1000.0 : 500.0);
        d.setBaseFee(base);
        d.setUser(user);
        return doctorRepo.save(d);
    }

    public Doctor updateDoctor(Long id, DoctorDTO dto){
        Doctor d = doctorRepo.findById(id).orElseThrow(() -> new RuntimeException("Doctor not found"));
        d.setFullName(dto.getFullName());
        d.setQualification(dto.getQualification());
        if ("MD".equalsIgnoreCase(dto.getQualification())) {
            if (dto.getSpecialization()==null || dto.getSpecialization().isBlank())
                throw new RuntimeException("Specialization required for MD");
            d.setSpecialization(dto.getSpecialization());
        } else {
            d.setSpecialization("General");
        }
        d.setContactNumber(dto.getContactNumber());
        if(dto.getBaseFee()!=null) d.setBaseFee(dto.getBaseFee());
        return doctorRepo.save(d);
    }

    public void deleteDoctor(Long id){ doctorRepo.deleteById(id); }

    public long totalPatients(){ return patientRepo.count(); }
    public long totalDoctors(){ return doctorRepo.count(); }
}
