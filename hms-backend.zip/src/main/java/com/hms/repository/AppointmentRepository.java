package com.hms.repository;

import com.hms.entity.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    boolean existsByDoctorIdAndDateAndTime(Long doctorId, LocalDate date, LocalTime time);
    List<Appointment> findByPatientId(Long patientId);
    List<Appointment> findByDoctorIdAndDateGreaterThanEqual(Long doctorId, LocalDate from);
    long count();
}
