package com.hms.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
public class Appointment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional=false) private Patient patient;
    @ManyToOne(optional=false) private Doctor doctor;

    @NotNull private LocalDate date;
    @NotNull private LocalTime time;

    @Enumerated(EnumType.STRING)
    private Status status = Status.CONFIRMED;

    public enum Status { CONFIRMED, CANCELLED, COMPLETED }

    public Long getId(){ return id; }
    public void setId(Long id){ this.id=id; }
    public Patient getPatient(){ return patient; }
    public void setPatient(Patient patient){ this.patient=patient; }
    public Doctor getDoctor(){ return doctor; }
    public void setDoctor(Doctor doctor){ this.doctor=doctor; }
    public LocalDate getDate(){ return date; }
    public void setDate(LocalDate date){ this.date=date; }
    public LocalTime getTime(){ return time; }
    public void setTime(LocalTime time){ this.time=time; }
    public Status getStatus(){ return status; }
    public void setStatus(Status status){ this.status=status; }
}
