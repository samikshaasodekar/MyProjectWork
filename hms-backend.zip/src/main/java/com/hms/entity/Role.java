package com.hms.entity;
public enum Role { ADMIN, DOCTOR, PATIENT }
