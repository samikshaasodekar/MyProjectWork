package com.hms.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Entity
public class Patient {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank @Size(max=100)
    private String fullName;

    @Past
    private LocalDate dateOfBirth;

    @NotBlank @Size(max=10)
    private String gender;

    @NotBlank @Size(max=15)
    private String contactNumber;

    @NotBlank @Size(max=255)
    private String address;

    @Column(length=2000)
    private String medicalHistory;

    @OneToOne(optional=false)
    private User user;

    public Long getId(){ return id; }
    public void setId(Long id){ this.id=id; }
    public String getFullName(){ return fullName; }
    public void setFullName(String fullName){ this.fullName=fullName; }
    public LocalDate getDateOfBirth(){ return dateOfBirth; }
    public void setDateOfBirth(LocalDate dateOfBirth){ this.dateOfBirth=dateOfBirth; }
    public String getGender(){ return gender; }
    public void setGender(String gender){ this.gender=gender; }
    public String getContactNumber(){ return contactNumber; }
    public void setContactNumber(String contactNumber){ this.contactNumber=contactNumber; }
    public String getAddress(){ return address; }
    public void setAddress(String address){ this.address=address; }
    public String getMedicalHistory(){ return medicalHistory; }
    public void setMedicalHistory(String medicalHistory){ this.medicalHistory=medicalHistory; }
    public User getUser(){ return user; }
    public void setUser(User user){ this.user=user; }
}
