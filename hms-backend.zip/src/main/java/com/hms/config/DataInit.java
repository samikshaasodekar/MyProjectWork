package com.hms.config;

import com.hms.entity.Role;
import com.hms.entity.User;
import com.hms.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Configuration
public class DataInit {
    @Bean
    CommandLineRunner initAdmin(UserRepository users, BCryptPasswordEncoder enc){
        return args -> users.findByUsername("admin").orElseGet(() -> {
            User u = new User();
            u.setUsername("admin");
            u.setPassword(enc.encode("admin123"));
            u.setRole(Role.ADMIN);
            u.setEnabled(true);
            return users.save(u);
        });
    }
}
