package com.hms.controller;

import com.hms.dto.common.ApiResponse;
import com.hms.dto.patient.PatientDTO;
import com.hms.entity.Patient;
import com.hms.service.PatientService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/patient")
public class PatientController {
    private final PatientService patientService;
    public PatientController(PatientService p){ this.patientService=p; }

    @GetMapping("/by-username/{username}")
    public ApiResponse<Patient> byUser(@PathVariable String username){
        return new ApiResponse<>(true,"Patient", patientService.getByUser(username));
    }

    @PutMapping("/{id}")
    public ApiResponse<Long> update(@PathVariable Long id, @Valid @RequestBody PatientDTO dto){
        Patient p = patientService.updateBasic(id, dto.getFullName(), dto.getContactNumber(), dto.getAddress(), dto.getMedicalHistory());
        return new ApiResponse<>(true,"Updated", p.getId());
    }
}
