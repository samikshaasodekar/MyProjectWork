package com.hms.controller;

import com.hms.dto.common.ApiResponse;
import com.hms.dto.doctor.DoctorAvailabilityDTO;
import com.hms.entity.DoctorAvailability;
import com.hms.service.DoctorService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/doctor")
public class DoctorController {
    private final DoctorService doctorService;
    public DoctorController(DoctorService d){ this.doctorService=d; }

    @PostMapping("/availability")
    public ApiResponse<Long> addAvailability(@Valid @RequestBody DoctorAvailabilityDTO dto){
        DoctorAvailability a = doctorService.addAvailability(dto);
        return new ApiResponse<>(true,"Availability added", a.getId());
    }

    @GetMapping("/{doctorId}/slots")
    public ApiResponse<List<String>> slots(@PathVariable Long doctorId, @RequestParam String date){
        LocalDate d = LocalDate.parse(date);
        List<String> s = doctorService.availableSlots(doctorId, d).stream().map(Object::toString).toList();
        return new ApiResponse<>(true,"Free slots", s);
    }

    @GetMapping("/search/name")
    public ApiResponse<?> byName(@RequestParam String q){ return new ApiResponse<>(true,"Doctors", doctorService.searchByName(q)); }

    @GetMapping("/search/specialization")
    public ApiResponse<?> bySpec(@RequestParam String s){ return new ApiResponse<>(true,"Doctors", doctorService.searchBySpecialization(s)); }
}
