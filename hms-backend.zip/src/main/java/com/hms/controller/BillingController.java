package com.hms.controller;

import com.hms.dto.common.ApiResponse;
import com.hms.entity.Bill;
import com.hms.service.BillingService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/billing")
public class BillingController {
    private final BillingService billingService;
    public BillingController(BillingService b){ this.billingService=b; }

    @PostMapping("/{billId}/pay")
    public ApiResponse<Long> pay(@PathVariable Long billId){
        Bill b = billingService.markPaidRequest(billId);
        return new ApiResponse<>(true,"Payment requested (pending admin verification)", b.getId());
    }
}
