package com.hms.dto.appointment;

import jakarta.validation.constraints.*;

public class AppointmentRequest {
    @NotNull private Long doctorId;
    @NotNull private Long patientId;
    @NotBlank private String date;
    @NotBlank private String time;

    public Long getDoctorId(){ return doctorId; }
    public void setDoctorId(Long doctorId){ this.doctorId=doctorId; }
    public Long getPatientId(){ return patientId; }
    public void setPatientId(Long patientId){ this.patientId=patientId; }
    public String getDate(){ return date; }
    public void setDate(String date){ this.date=date; }
    public String getTime(){ return time; }
    public void setTime(String time){ this.time=time; }
}
