package com.hms.dto.auth;

import jakarta.validation.constraints.*;
import java.time.LocalDate;

public class RegisterPatientRequest {
    @NotBlank private String username;
    @NotBlank @Size(min=6) private String password;
    @NotBlank private String fullName;
    @Past private LocalDate dateOfBirth;
    @NotBlank private String gender;
    @NotBlank private String contactNumber;
    @NotBlank private String address;
    private String medicalHistory;

    public String getUsername(){ return username; }
    public void setUsername(String username){ this.username=username; }
    public String getPassword(){ return password; }
    public void setPassword(String password){ this.password=password; }
    public String getFullName(){ return fullName; }
    public void setFullName(String fullName){ this.fullName=fullName; }
    public LocalDate getDateOfBirth(){ return dateOfBirth; }
    public void setDateOfBirth(LocalDate dateOfBirth){ this.dateOfBirth=dateOfBirth; }
    public String getGender(){ return gender; }
    public void setGender(String gender){ this.gender=gender; }
    public String getContactNumber(){ return contactNumber; }
    public void setContactNumber(String contactNumber){ this.contactNumber=contactNumber; }
    public String getAddress(){ return address; }
    public void setAddress(String address){ this.address=address; }
    public String getMedicalHistory(){ return medicalHistory; }
    public void setMedicalHistory(String medicalHistory){ this.medicalHistory=medicalHistory; }
}
