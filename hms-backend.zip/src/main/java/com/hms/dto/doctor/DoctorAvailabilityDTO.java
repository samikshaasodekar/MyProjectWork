package com.hms.dto.doctor;

import jakarta.validation.constraints.*;

public class DoctorAvailabilityDTO {
    @NotNull private Long doctorId;
    @NotBlank private String dayOfWeek;
    @NotBlank private String startTime;
    @NotBlank private String endTime;
    @Min(5) @Max(180) private Integer slotMinutes = 30;

    public Long getDoctorId(){ return doctorId; }
    public void setDoctorId(Long doctorId){ this.doctorId=doctorId; }
    public String getDayOfWeek(){ return dayOfWeek; }
    public void setDayOfWeek(String dayOfWeek){ this.dayOfWeek=dayOfWeek; }
    public String getStartTime(){ return startTime; }
    public void setStartTime(String startTime){ this.startTime=startTime; }
    public String getEndTime(){ return endTime; }
    public void setEndTime(String endTime){ this.endTime=endTime; }
    public Integer getSlotMinutes(){ return slotMinutes; }
    public void setSlotMinutes(Integer slotMinutes){ this.slotMinutes=slotMinutes; }
}
