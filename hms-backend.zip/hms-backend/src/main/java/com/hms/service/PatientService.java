package com.hms.service;

import com.hms.dto.auth.RegisterPatientRequest;
import com.hms.entity.*;
import com.hms.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PatientService {
    private final AuthService authService;
    private final PatientRepository patientRepo;

    public PatientService(AuthService a, PatientRepository p){ this.authService=a; this.patientRepo=p; }

    @Transactional
    public Patient register(RegisterPatientRequest r){
        User u = authService.registerPatient(r.getUsername(), r.getPassword());
        Patient p = new Patient();
        p.setFullName(r.getFullName());
        p.setDateOfBirth(r.getDateOfBirth());
        p.setGender(r.getGender());
        p.setContactNumber(r.getContactNumber());
        p.setAddress(r.getAddress());
        p.setMedicalHistory(r.getMedicalHistory());
        p.setUser(u);
        return patientRepo.save(p);
    }

    public Patient getByUser(String username){
        return patientRepo.findByUserUsername(username).orElseThrow(() -> new RuntimeException("Patient not found"));
    }

    public Patient updateBasic(Long id, String name, String contact, String address, String history){
        Patient p = patientRepo.findById(id).orElseThrow(() -> new RuntimeException("Patient not found"));
        p.setFullName(name);
        p.setContactNumber(contact);
        p.setAddress(address);
        p.setMedicalHistory(history);
        return patientRepo.save(p);
    }
}
