package com.hms.service;

import com.hms.dto.doctor.DoctorAvailabilityDTO;
import com.hms.entity.*;
import com.hms.repository.*;
import org.springframework.stereotype.Service;

import java.time.*;
import java.util.*;

@Service
public class DoctorService {
    private final DoctorRepository doctorRepo;
    private final DoctorAvailabilityRepository availRepo;
    private final AppointmentRepository apptRepo;

    public DoctorService(DoctorRepository d, DoctorAvailabilityRepository a, AppointmentRepository ap){
        this.doctorRepo=d; this.availRepo=a; this.apptRepo=ap;
    }

    public DoctorAvailability addAvailability(DoctorAvailabilityDTO dto){
        Doctor doc = doctorRepo.findById(dto.getDoctorId())
                .orElseThrow(() -> new RuntimeException("Doctor not found"));
        DoctorAvailability av = new DoctorAvailability();
        av.setDoctor(doc);
        av.setDayOfWeek(DayOfWeek.valueOf(dto.getDayOfWeek().toUpperCase()));
        av.setStartTime(LocalTime.parse(dto.getStartTime()));
        av.setEndTime(LocalTime.parse(dto.getEndTime()));
        av.setSlotMinutes(dto.getSlotMinutes());
        return availRepo.save(av);
    }

    public List<LocalTime> availableSlots(Long doctorId, LocalDate date){
        DayOfWeek dow = date.getDayOfWeek();
        List<DoctorAvailability> lis = availRepo.findByDoctorId(doctorId);
        List<LocalTime> free = new ArrayList<>();
        for(DoctorAvailability av: lis){
            if(av.getDayOfWeek()==dow){
                LocalTime t=av.getStartTime();
                while(!t.isAfter(av.getEndTime().minusMinutes(av.getSlotMinutes()))){
                    if(!apptRepo.existsByDoctorIdAndDateAndTime(doctorId, date, t)){
                        free.add(t);
                    }
                    t=t.plusMinutes(av.getSlotMinutes());
                }
            }
        }
        return free;
    }

    public List<Doctor> searchByName(String q){ return doctorRepo.findByFullNameContainingIgnoreCase(q); }
    public List<Doctor> searchBySpecialization(String sp){ return doctorRepo.findBySpecializationIgnoreCase(sp); }
}
