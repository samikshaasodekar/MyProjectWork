package com.hms.service;

import com.hms.dto.billing.BillDTO;
import com.hms.entity.*;
import com.hms.repository.*;
import org.springframework.stereotype.Service;

@Service
public class BillingService {
    private final BillRepository billRepo;
    private final PatientRepository patientRepo;
    private final DoctorRepository doctorRepo;

    public BillingService(BillRepository b, PatientRepository p, DoctorRepository d){
        this.billRepo=b; this.patientRepo=p; this.doctorRepo=d;
    }

    public Bill generate(BillDTO dto){
        Patient pat = patientRepo.findById(dto.getPatientId()).orElseThrow(() -> new RuntimeException("Patient not found"));
        Doctor doc = doctorRepo.findById(dto.getDoctorId()).orElseThrow(() -> new RuntimeException("Doctor not found"));
        double amount = (dto.getAmount()!=null) ? dto.getAmount() :
                ("MD".equalsIgnoreCase(doc.getQualification()) ? 1000.0 : 500.0);
        Bill bill = new Bill();
        bill.setPatient(pat);
        bill.setDoctor(doc);
        bill.setAmount(amount);
        bill.setDescription(dto.getDescription());
        bill.setPaymentStatus(Bill.PaymentStatus.UNPAID);
        return billRepo.save(bill);
    }

    public Bill markPaidRequest(Long billId){
        Bill b = billRepo.findById(billId).orElseThrow(() -> new RuntimeException("Bill not found"));
        if(b.getPaymentStatus()==Bill.PaymentStatus.PAID) return b;
        b.setPaymentStatus(Bill.PaymentStatus.PENDING_VERIFICATION);
        return billRepo.save(b);
    }

    public Bill verifyPayment(Long billId){
        Bill b = billRepo.findById(billId).orElseThrow(() -> new RuntimeException("Bill not found"));
        b.setPaymentStatus(Bill.PaymentStatus.PAID);
        return billRepo.save(b);
    }
}
