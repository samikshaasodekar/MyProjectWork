package com.hms.dto.doctor;
import jakarta.validation.constraints.*;

public class DoctorDTO {
    @NotBlank private String fullName;
    @NotBlank private String qualification;
    @NotBlank private String specialization;
    @NotBlank private String contactNumber;
    private Double baseFee;
    public String getFullName(){ return fullName; }
    public void setFullName(String fullName){ this.fullName=fullName; }
    public String getQualification(){ return qualification; }
    public void setQualification(String qualification){ this.qualification=qualification; }
    public String getSpecialization(){ return specialization; }
    public void setSpecialization(String specialization){ this.specialization=specialization; }
    public String getContactNumber(){ return contactNumber; }
    public void setContactNumber(String contactNumber){ this.contactNumber=contactNumber; }
    public Double getBaseFee(){ return baseFee; }
    public void setBaseFee(Double baseFee){ this.baseFee=baseFee; }
}
