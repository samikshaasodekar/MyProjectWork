package com.hms.dto.billing;
import jakarta.validation.constraints.*;

public class BillDTO {
    @NotNull private Long patientId;
    @NotNull private Long doctorId;
    @NotBlank private String description;
    private Double amount;
    public Long getPatientId(){ return patientId; }
    public void setPatientId(Long patientId){ this.patientId=patientId; }
    public Long getDoctorId(){ return doctorId; }
    public void setDoctorId(Long doctorId){ this.doctorId=doctorId; }
    public String getDescription(){ return description; }
    public void setDescription(String description){ this.description=description; }
    public Double getAmount(){ return amount; }
    public void setAmount(Double amount){ this.amount=amount; }
}
