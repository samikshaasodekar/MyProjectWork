package com.hms.dto.appointment;

public class AppointmentResponse {
    private Long appointmentId;
    private String doctorName;
    private String patientName;
    private String date;
    private String time;
    private String status;
    public Long getAppointmentId(){ return appointmentId; }
    public void setAppointmentId(Long appointmentId){ this.appointmentId=appointmentId; }
    public String getDoctorName(){ return doctorName; }
    public void setDoctorName(String doctorName){ this.doctorName=doctorName; }
    public String getPatientName(){ return patientName; }
    public void setPatientName(String patientName){ this.patientName=patientName; }
    public String getDate(){ return date; }
    public void setDate(String date){ this.date=date; }
    public String getTime(){ return time; }
    public void setTime(String time){ this.time=time; }
    public String getStatus(){ return status; }
    public void setStatus(String status){ this.status=status; }
}
