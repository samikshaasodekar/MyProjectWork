package com.hms.dto.patient;
import jakarta.validation.constraints.*;

public class PatientDTO {
    @NotBlank private String fullName;
    @NotBlank private String contactNumber;
    @NotBlank private String address;
    private String medicalHistory;
    public String getFullName(){ return fullName; }
    public void setFullName(String fullName){ this.fullName=fullName; }
    public String getContactNumber(){ return contactNumber; }
    public void setContactNumber(String contactNumber){ this.contactNumber=contactNumber; }
    public String getAddress(){ return address; }
    public void setAddress(String address){ this.address=address; }
    public String getMedicalHistory(){ return medicalHistory; }
    public void setMedicalHistory(String medicalHistory){ this.medicalHistory=medicalHistory; }
}
