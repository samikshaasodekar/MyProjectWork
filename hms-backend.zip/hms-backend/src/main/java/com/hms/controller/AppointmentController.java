package com.hms.controller;

import com.hms.dto.appointment.*;
import com.hms.dto.common.ApiResponse;
import com.hms.service.AppointmentService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/appointment")
public class AppointmentController {
    private final AppointmentService appointmentService;
    public AppointmentController(AppointmentService a){ this.appointmentService=a; }

    @PostMapping("/book")
    public ApiResponse<AppointmentResponse> book(@Valid @RequestBody AppointmentRequest req){
        return new ApiResponse<>(true,"Booked", appointmentService.book(req));
    }

    @PostMapping("/{id}/cancel")
    public ApiResponse<Void> cancel(@PathVariable Long id){
        appointmentService.cancel(id);
        return new ApiResponse<>(true,"Cancelled", null);
    }
}
