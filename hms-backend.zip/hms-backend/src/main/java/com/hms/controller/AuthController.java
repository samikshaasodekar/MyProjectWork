package com.hms.controller;

import com.hms.dto.auth.RegisterPatientRequest;
import com.hms.dto.common.ApiResponse;
import com.hms.entity.Patient;
import com.hms.service.PatientService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@CrossOrigin
public class AuthController {
    private final PatientService patientService;
    public AuthController(PatientService p){ this.patientService=p; }

    @PostMapping("/register/patient")
    public ApiResponse<Long> registerPatient(@Valid @RequestBody RegisterPatientRequest req){
        Patient p = patientService.register(req);
        return new ApiResponse<>(true, "Registered", p.getId());
    }

    @GetMapping("/me")
    public ApiResponse<String> me(){ return new ApiResponse<>(true, "Authenticated", "OK"); }
}
