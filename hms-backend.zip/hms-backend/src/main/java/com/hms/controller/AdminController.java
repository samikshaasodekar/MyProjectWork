package com.hms.controller;

import com.hms.dto.billing.BillDTO;
import com.hms.dto.common.ApiResponse;
import com.hms.dto.doctor.DoctorDTO;
import com.hms.entity.Bill;
import com.hms.entity.Doctor;
import com.hms.service.AdminService;
import com.hms.service.BillingService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin")
public class AdminController {
    private final AdminService adminService;
    private final BillingService billingService;
    public AdminController(AdminService a, BillingService b){ this.adminService=a; this.billingService=b; }

    @PostMapping("/doctors/{username}/create")
    public ApiResponse<Long> createDoctor(@PathVariable String username,
                                          @RequestParam String commonPassword,
                                          @Valid @RequestBody DoctorDTO dto){
        Doctor d = adminService.createDoctor(dto, username, commonPassword);
        return new ApiResponse<>(true, "Doctor created", d.getId());
    }

    @PutMapping("/doctors/{id}")
    public ApiResponse<Long> updateDoctor(@PathVariable Long id, @Valid @RequestBody DoctorDTO dto){
        return new ApiResponse<>(true,"Updated", adminService.updateDoctor(id, dto).getId());
    }

    @DeleteMapping("/doctors/{id}")
    public ApiResponse<Void> deleteDoctor(@PathVariable Long id){
        adminService.deleteDoctor(id);
        return new ApiResponse<>(true,"Deleted", null);
    }

    @GetMapping("/dashboard/totals")
    public ApiResponse<String> totals(){
        long d=adminService.totalDoctors(), p=adminService.totalPatients();
        return new ApiResponse<>(true,"Totals","doctors="+d+", patients="+p);
    }

    @PostMapping("/bills")
    public ApiResponse<Long> generateBill(@Valid @RequestBody BillDTO dto){
        Bill b = billingService.generate(dto);
        return new ApiResponse<>(true,"Bill generated", b.getId());
    }

    @PostMapping("/bills/{id}/verify")
    public ApiResponse<Long> verify(@PathVariable Long id){
        return new ApiResponse<>(true,"Payment verified", billingService.verifyPayment(id).getId());
    }
}
