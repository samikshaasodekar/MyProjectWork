package com.hms.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

@Entity
public class Bill {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional=false)
    private Patient patient;

    @ManyToOne(optional=false)
    private Doctor doctor;

    @NotNull
    private Double amount;

    @Enumerated(EnumType.STRING)
    private PaymentStatus paymentStatus = PaymentStatus.UNPAID;

    private LocalDateTime createdAt = LocalDateTime.now();

    private String description;

    public enum PaymentStatus { PAID, UNPAID, PENDING_VERIFICATION }

    // getters/setters
    public Long getId(){ return id; }
    public void setId(Long id){ this.id=id; }
    public Patient getPatient(){ return patient; }
    public void setPatient(Patient patient){ this.patient=patient; }
    public Doctor getDoctor(){ return doctor; }
    public void setDoctor(Doctor doctor){ this.doctor=doctor; }
    public Double getAmount(){ return amount; }
    public void setAmount(Double amount){ this.amount=amount; }
    public PaymentStatus getPaymentStatus(){ return paymentStatus; }
    public void setPaymentStatus(PaymentStatus paymentStatus){ this.paymentStatus=paymentStatus; }
    public LocalDateTime getCreatedAt(){ return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt){ this.createdAt=createdAt; }
    public String getDescription(){ return description; }
    public void setDescription(String description){ this.description=description; }
}
