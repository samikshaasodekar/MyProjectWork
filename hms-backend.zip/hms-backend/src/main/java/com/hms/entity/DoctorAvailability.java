package com.hms.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.DayOfWeek;
import java.time.LocalTime;

@Entity
public class DoctorAvailability {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional=false)
    private Doctor doctor;

    @Enumerated(EnumType.STRING)
    private DayOfWeek dayOfWeek;

    @NotNull
    private LocalTime startTime;

    @NotNull
    private LocalTime endTime;

    @NotNull @Min(5) @Max(180)
    private Integer slotMinutes = 30;

    // getters/setters
    public Long getId(){ return id; }
    public void setId(Long id){ this.id=id; }
    public Doctor getDoctor(){ return doctor; }
    public void setDoctor(Doctor doctor){ this.doctor=doctor; }
    public DayOfWeek getDayOfWeek(){ return dayOfWeek; }
    public void setDayOfWeek(DayOfWeek dayOfWeek){ this.dayOfWeek=dayOfWeek; }
    public LocalTime getStartTime(){ return startTime; }
    public void setStartTime(LocalTime startTime){ this.startTime=startTime; }
    public LocalTime getEndTime(){ return endTime; }
    public void setEndTime(LocalTime endTime){ this.endTime=endTime; }
    public Integer getSlotMinutes(){ return slotMinutes; }
    public void setSlotMinutes(Integer slotMinutes){ this.slotMinutes=slotMinutes; }
}
