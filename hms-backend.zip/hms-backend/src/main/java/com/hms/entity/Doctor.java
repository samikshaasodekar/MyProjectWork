package com.hms.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
public class Doctor {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank @Size(max=100)
    private String fullName;

    @NotBlank @Size(max=20)
    private String qualification; // MBBS or MD

    @NotBlank
    private String specialization;

    @NotBlank @Size(max=15)
    private String contactNumber;

    @DecimalMin("0.0")
    private Double baseFee;

    @OneToOne(optional=false)
    private User user;

    // getters/setters
    public Long getId(){ return id; }
    public void setId(Long id){ this.id=id; }
    public String getFullName(){ return fullName; }
    public void setFullName(String fullName){ this.fullName=fullName; }
    public String getQualification(){ return qualification; }
    public void setQualification(String qualification){ this.qualification=qualification; }
    public String getSpecialization(){ return specialization; }
    public void setSpecialization(String specialization){ this.specialization=specialization; }
    public String getContactNumber(){ return contactNumber; }
    public void setContactNumber(String contactNumber){ this.contactNumber=contactNumber; }
    public Double getBaseFee(){ return baseFee; }
    public void setBaseFee(Double baseFee){ this.baseFee=baseFee; }
    public User getUser(){ return user; }
    public void setUser(User user){ this.user=user; }
}
