package com.genc.ecommerce.user;

import com.genc.ecommerce.cart.CartData;
import com.genc.ecommerce.cart.CartRepo;
import com.genc.ecommerce.utils.CustomException;
import com.genc.ecommerce.utils.ErrorCodes;
import com.twilio.rest.verify.v2.service.Verification;
import com.twilio.rest.verify.v2.service.VerificationCheck;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service
public class UserService {
    private final LoginDetailsRepo loginDetailsRepo;
    private final UserRepo userRepo;
    private final PersonalDetailsRepo personalDetailsRepo;
    private final CartRepo cartRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    private final static Logger logger = LogManager.getLogger(UserService.class);

    @Autowired
    public UserService(LoginDetailsRepo loginDetailsRepo, UserRepo userRepo, PersonalDetailsRepo personalDetailsRepo,CartRepo cartRepo) {
        this.loginDetailsRepo = loginDetailsRepo;
        this.userRepo = userRepo;
        this.personalDetailsRepo = personalDetailsRepo;
        this.cartRepo=cartRepo;
    }

    @Value("${twilio.verify.sid}")
    private String verifyServiceSid;

    public UserData createUser(UserData user) {
        if (userRepo.findByEmailAndRole(user.getEmail(), user.getRole()).isEmpty()) {
            if (loginDetailsRepo.findByUserName(user.getUserName()).isPresent()) {
                throw new CustomException("Username already exists", ErrorCodes.ALREADY_EXISTS);
            }
            LoginDetails loginDetails = new LoginDetails();
            loginDetails.setUserName(user.getUserName());
            loginDetails.setEncPwd(passwordEncoder.encode(user.getDecPwd()));
            user.setLoginDetails(loginDetails);
            logger.info("Login Details for User - {} created successfully at {}", loginDetails.getUserName(), new Date());
            loginDetailsRepo.save(loginDetails);
            personalDetailsRepo.save(user.getPersonalDetails());
            logger.info("User - {} saved successfully at {}", user.getUserId().toString(), new Date());
            CartData cart = new CartData();
            cart.setUser(user);
            cartRepo.save(cart);
            logger.info("Cart for User - {} created successfully at {}", user.getUserId().toString(), new Date());
            return userRepo.save(user);
        } else {
            logger.error("User with email {} and role {} already exists", user.getEmail(), user.getRole());
            throw new CustomException("User already exists", ErrorCodes.ALREADY_EXISTS);
        }
    }

    public UserData getUserById(UUID userId) {
        return userRepo.findById(userId).orElseThrow(() -> new CustomException("User not found", ErrorCodes.NOT_FOUND));
    }

    public String validateUser(String userName, String pwd) {
        if (loginDetailsRepo.findByUserName(userName).isPresent()) {
            LoginDetails loginDetails = loginDetailsRepo.findByUserName(userName).get();
            if (loginDetails.isLocked()) {
                logger.error("Account locked for user: {}", userName);
                throw new CustomException("Account Blocked Change Password", ErrorCodes.UNAUTHORIZED);
            }
            if (passwordEncoder.matches(pwd, loginDetails.getEncPwd())) {
                logger.info("Login Success for user: {}", userName);
                return "Success";
            } else if (!passwordEncoder.matches(pwd, loginDetails.getEncPwd()) && loginDetails.getCount() < 3) {
                loginDetails.setCount(loginDetails.getCount() + 1);
                if (loginDetails.getCount() == 3) {
                    loginDetails.setLocked(true);
                }
                loginDetailsRepo.save(loginDetails);
                logger.error("Incorrect password attempt {} for user: {}", loginDetails.getCount(), userName);
                throw new CustomException("Incorrect Password", ErrorCodes.UNAUTHORIZED);
            }
            else{
                logger.error("Account locked due to multiple failed attempts for user: {}", userName);
                throw new CustomException("Account Blocked Change Password", ErrorCodes.UNAUTHORIZED);
            }
        } else {
            throw new CustomException(ErrorCodes.NOT_FOUND_MESSAGE, ErrorCodes.NOT_FOUND);
        }
    }

    public UserData updateUser(UserData user) {
        if (userRepo.findById(user.getUserId()).isPresent()) {
            UserData updatedUser = userRepo.findById(user.getUserId()).get();
            if (StringUtils.isNotBlank(user.getUserName())) {
                if (loginDetailsRepo.findById(user.getLoginDetails().getId()).isPresent()) {
                    LoginDetails loginDetails = loginDetailsRepo.findById(user.getLoginDetails().getId()).get();
                    if (loginDetailsRepo.findByUserName(user.getLoginDetails().getUserName()).isPresent()) {
                        throw new CustomException("Username already exists", ErrorCodes.ALREADY_EXISTS);
                    }
                    loginDetails.setUserName(user.getUserName());
                    loginDetails.setUpdatedTimeStamp(new Date());
                }
            }
            updatedUser.setPersonalDetails(user.getPersonalDetails());
            updatedUser.setUpdatedTimeStamp(new Date());
            return userRepo.save(updatedUser);
        } else {
            throw new CustomException("User not found", ErrorCodes.NOT_FOUND);
        }
    }

    public String updatePwd(String userName, String oldPwd, String newPwd) {
        if (loginDetailsRepo.findByUserName(userName).isPresent()) {
            LoginDetails loginDetails = loginDetailsRepo.findByUserName(userName).get();
            if (passwordEncoder.matches(oldPwd, loginDetails.getEncPwd())) {
                loginDetails.setEncPwd(passwordEncoder.encode(newPwd));
                loginDetails.setLocked(false);
                loginDetails.setCount(0);
                loginDetails.setUpdatedTimeStamp(new Date());
                loginDetailsRepo.save(loginDetails);
                return "Password updated successfully";
            } else {
                throw new CustomException("Incorrect old password", ErrorCodes.UNAUTHORIZED);
            }
        } else {
            throw new CustomException("User not found", ErrorCodes.NOT_FOUND);
        }
    }

    public String forgotPasswordSendOtp(String userName) {
        if (loginDetailsRepo.findByUserName(userName).isPresent()) {
            LoginDetails loginDetails = loginDetailsRepo.findByUserName(userName).get();
            UserData user = userRepo.findByLoginDetails_Id(loginDetails.getId());
            sendOtp(user.getPersonalDetails().getCountryCode() + user.getPersonalDetails().getMobileNumber());
            return "Otp Send";
        } else {
            throw new CustomException("UserName not found", ErrorCodes.NOT_FOUND);
        }
    }

    public String forgotPasswordVerifyOtp(String userName, String code, String newPwd) {
        if (loginDetailsRepo.findByUserName(userName).isPresent()) {
            LoginDetails loginDetails = loginDetailsRepo.findByUserName(userName).get();
            UserData user = userRepo.findByLoginDetails_Id(loginDetails.getId());
            if (verifyOtp(user.getPersonalDetails().getCountryCode() + user.getPersonalDetails().getMobileNumber(), code)) {
                loginDetails.setEncPwd(passwordEncoder.encode(newPwd));
                loginDetails.setLocked(false);
                loginDetails.setCount(0);
                loginDetails.setUpdatedTimeStamp(new Date());
                loginDetailsRepo.save(loginDetails);
            }
            return "Password updated successfully";

        } else {
            throw new CustomException("User not found", ErrorCodes.NOT_FOUND);
        }
    }

    public void sendOtp(String phoneNumber) {
        Verification verification = Verification.creator(
                verifyServiceSid,
                phoneNumber,
                "sms" // or "call" or "email"
        ).create();

        System.out.println("OTP sent: " + verification.getStatus());
    }

    public boolean verifyOtp(String phoneNumber, String code) {
        VerificationCheck verificationCheck = VerificationCheck.creator(
                        verifyServiceSid
                ).setTo(phoneNumber)
                .setCode(code)
                .create();
        return "approved".equals(verificationCheck.getStatus());
    }

    public void dummy(UserData data){
        userRepo.save(data);
    }


    //CRON JOB

    @Scheduled(cron = "0 0 0 * * *")
    public void resetCountInLogin() {
        List<LoginDetails> loginDetails = loginDetailsRepo.findAll();
        for (LoginDetails login : loginDetails) {
            if (login.getCount() < 3) {
                login.setCount(0);
                login.setLocked(false);
                loginDetailsRepo.save(login);
            }
        }
    }
}
