package com.genc.ecommerce.payment;

import com.genc.ecommerce.utils.Response;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping(value = "/payment")
public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping(value = "/process")
    public Response processPayment(@RequestParam UUID orderId,@RequestParam boolean isPaymentSuccess,@RequestParam PaymentData.PaymentMethod paymentMethod) {
        return new Response(paymentService.processPayment(orderId,isPaymentSuccess,paymentMethod));
    }

    @GetMapping(value = "/get-payment-status")
    public Response getPaymentStatus(@RequestParam UUID paymentId)
    {
     return new Response(paymentService.getPaymentStatus(paymentId));
    }
}
