package com.genc.ecommerce.user;

import com.genc.ecommerce.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping(value = "/user")
public class UserController {
    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping(value = "/create-user")
    public Response createUser(@RequestBody UserData userData) {
        return new Response(userService.createUser(userData));
    }

    @GetMapping(value = "/get-user-by-id")
    public Response getUserById(@RequestParam UUID userId) {
        return new Response(userService.getUserById(userId));
    }


    @GetMapping(value = "/validate-user")
    public Response validateUser(@RequestParam String userName, @RequestParam String pwd) {
        return new Response(userService.validateUser(userName, pwd));
    }

    @PutMapping(value = "/update-user")
    public Response updateUser(@RequestBody UserData userData) {
        return new Response(userService.updateUser(userData));
    }

    @PutMapping(value = "/change-password")
    public Response updatePwd(@RequestParam String userName, @RequestParam String oldPwd, @RequestParam String newPwd) {
        return new Response(userService.updatePwd(userName, oldPwd, newPwd));
    }

    @GetMapping(value = "/send-otp-forgot-pwd")
    public Response forgotPasswordSendOtp(@RequestParam String userName) {
        return new Response(userService.forgotPasswordSendOtp(userName));
    }

    @PutMapping(value = "/validate-otp-forgot-pwd")
    public Response forgotPasswordVerifyOtp(@RequestParam String userName, @RequestParam String otp, @RequestParam String newPwd) {
        return new Response(userService.forgotPasswordVerifyOtp(userName, otp, newPwd));
    }


}
