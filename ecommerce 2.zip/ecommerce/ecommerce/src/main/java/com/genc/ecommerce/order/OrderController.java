package com.genc.ecommerce.order;

import com.genc.ecommerce.utils.Response;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping(value = "/orders")
public class OrderController {
    private final OrderService orderService;

    @Autowired
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping(value = "/create", consumes = "application/json", produces = "application/json")
    public Response createOrder(@RequestParam UUID userId) {
        return new Response(orderService.createOrder(userId));
    }

    @Operation(summary = "Filter only one parameter at a time")
    @GetMapping(value = "/filter", produces = "application/json")
    public Response filterOrders(@RequestParam(required = false) UUID orderId,
                                 @RequestParam(required = false) UUID userId,
                                 @RequestParam(required = false) OrderData.Status status,
                                 @RequestParam int page,
                                 @RequestParam int size) {
        return new Response(orderService.filterOrders(orderId, userId, status, page, size));
    }

    @PutMapping(value = "/update", produces = "application/json")
    public Response updateOrderDetails(@RequestParam UUID orderId, @RequestParam OrderData.Status status) {
        return new Response(orderService.updateOrderDetails(orderId, status));
    }
}
