package com.genc.ecommerce.utils;

import lombok.Data;

@Data
public class ListResponse {
    private int count;
    private Object data;

}
