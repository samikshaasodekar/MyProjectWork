package com.genc.ecommerce.user;

import com.github.f4b6a3.uuid.UuidCreator;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

import java.util.Date;
import java.util.UUID;

@Entity
@Data
@Table(name = "Login_Credentials")
public class LoginDetails {
    @Id
    private UUID id;
    private String encPwd;
    private String userName;
    private int count;
    private boolean isLocked;
    private Date createdTimeStamp;
    private Date updatedTimeStamp;

    public LoginDetails() {
        if (this.id == null) {
            this.id = UuidCreator.getTimeOrderedWithRandom();
            this.count = 0;
            this.isLocked = false;
            this.createdTimeStamp = new Date();
            this.updatedTimeStamp = createdTimeStamp;
        }
    }
}
