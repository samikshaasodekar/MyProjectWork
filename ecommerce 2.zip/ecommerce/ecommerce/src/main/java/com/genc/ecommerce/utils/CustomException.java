package com.genc.ecommerce.utils;

import lombok.Data;

@Data
public class CustomException extends RuntimeException {
    private int code;

    public CustomException(String message, int errorCode) {
        super(message);
        this.code = errorCode;
    }
}
