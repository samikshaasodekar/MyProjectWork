package com.genc.ecommerce.product;

import com.github.f4b6a3.uuid.UuidCreator;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

import java.util.Date;
import java.util.UUID;

@Entity
@Data
@Table(name = "Category")
public class CategoryData {
    @Id
    private UUID categoryId;
    private String name;
    private Date createdTimeStamp;
    private Date updatedTimeStamp;

    public CategoryData() {
        if (this.categoryId == null) {
            this.categoryId = UuidCreator.getTimeOrdered();
            this.createdTimeStamp = new Date();
            this.updatedTimeStamp = createdTimeStamp;
        }
    }

}
