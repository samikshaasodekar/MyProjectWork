package com.genc.ecommerce.utils;

public interface ErrorCodes {
    int NOT_FOUND = 1000;
    int BAD_REQUEST = 1001;
    int ALREADY_EXISTS = 1002;
    int UNAUTHORIZED = 1003;

    String NOT_FOUND_MESSAGE = "Resource not found";
}
