package com.genc.ecommerce.product;

import com.genc.ecommerce.dto.ProductDto;
import com.genc.ecommerce.user.UserService;
import com.genc.ecommerce.utils.Response;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping(value = "/product")
public class ProductController {
    private final ProductService productService;


    @Autowired
    private UserService userService;

    @Autowired
    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @PostMapping(value = "/create-category")
    public Response createCategory(@RequestBody CategoryData categoryData) {
        return new Response(productService.createCategory(categoryData));
    }

    @GetMapping(value = "/get-all-categories")
    public Response getAllCategories() {
        return new Response(productService.getAllCategories());
    }

    @PostMapping(value = "/create")
    public Response createProduct(@RequestBody ProductDto productDto) {
        return new Response(productService.createProduct(productDto));
    }

    @PutMapping(value = "/update")
    public Response updateProduct(@RequestBody ProductData productData) {
        return new Response(productService.updateProduct(productData));
    }

    @DeleteMapping(value = "/delete")
    public Response deleteProduct(@RequestParam UUID id) {
        return new Response(productService.deleteProduct(id));
    }

    @GetMapping(value = "/get-by-id")
    public Response getById(@RequestParam UUID id) {
        return new Response(productService.getById(id));
    }

    @Operation(summary = "Filter only one parameter at a time")
    @GetMapping(value = "/filter")
    public Response filterProducts(@RequestParam(required = false) String productName,
                                   @RequestParam(required = false) Double startPrice,
                                   @RequestParam(required = false) Double endPrice,
                                   @RequestParam(required = false) UUID categoryId,
                                   @RequestParam int page, @RequestParam int size) {
        return new Response(productService.filterProducts(productName, startPrice, endPrice, categoryId, page, size));
    }
}
