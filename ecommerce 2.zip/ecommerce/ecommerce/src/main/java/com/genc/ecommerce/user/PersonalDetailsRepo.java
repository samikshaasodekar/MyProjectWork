package com.genc.ecommerce.user;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface PersonalDetailsRepo extends JpaRepository<PersonalDetails, UUID> {
}
