package com.genc.ecommerce.user;

import com.github.f4b6a3.uuid.UuidCreator;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

import java.util.UUID;

@Data
@Entity
@Table(name = "personal_details")
public class PersonalDetails {
    @Id
    private UUID id;
    private String firstName;
    private String lastName;
    private String countryCode;
    private String mobileNumber;
    private String address;
    private int pinCode;

    public PersonalDetails() {
        if (this.id == null) {
            this.id = UuidCreator.getTimeOrderedWithRandom();
        }
    }
}
