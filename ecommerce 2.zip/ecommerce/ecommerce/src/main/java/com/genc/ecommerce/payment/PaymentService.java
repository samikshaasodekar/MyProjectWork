package com.genc.ecommerce.payment;

import com.genc.ecommerce.order.OrderData;
import com.genc.ecommerce.order.OrderRepo;
import com.genc.ecommerce.utils.CustomException;
import org.hibernate.query.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.UUID;

import static com.genc.ecommerce.utils.ErrorCodes.NOT_FOUND;

@Service
public class PaymentService
{
    private final PaymentRepo paymentRepo;
    private final OrderRepo orderRepo;

    @Autowired
    public PaymentService(PaymentRepo paymentRepo, OrderRepo orderRepo) {
        this.paymentRepo = paymentRepo;
        this.orderRepo = orderRepo;
    }

    public String processPayment(UUID orderId, boolean isPaymentSuccess, PaymentData.PaymentMethod paymentMethod) {
        OrderData order=orderRepo.findById(orderId).orElseThrow(()->new CustomException("Order not found",NOT_FOUND));
        PaymentData payment=new PaymentData();
        payment.setPaymentMethod(paymentMethod);
        payment.setPaymentDate(new Date());
        if(isPaymentSuccess){
            payment.setPaymentStatus(PaymentData.PaymentStatus.COMPLETED);
            order.setStatus(OrderData.Status.PENDING);
        }
        else {
            payment.setPaymentStatus(PaymentData.PaymentStatus.FAILED);
            order.setStatus(OrderData.Status.CANCELLED);
        }
        orderRepo.save(order);
        payment.setOrder(order);
        paymentRepo.save(payment);
        return "Payment Processed Successfully";
    }

    public PaymentData.PaymentStatus getPaymentStatus(UUID paymentId) {
        PaymentData payment=paymentRepo.findById(paymentId).orElseThrow(()->new CustomException("Payment not found",NOT_FOUND));
        return payment.getPaymentStatus();
    }

}
