package com.genc.ecommerce.order;

import com.genc.ecommerce.cart.CartData;
import com.genc.ecommerce.cart.CartItem;
import com.genc.ecommerce.cart.CartRepo;
import com.genc.ecommerce.product.ProductData;
import com.genc.ecommerce.user.UserData;
import com.genc.ecommerce.user.UserRepo;
import com.genc.ecommerce.utils.CustomException;
import com.genc.ecommerce.utils.ListResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import static com.genc.ecommerce.utils.ErrorCodes.NOT_FOUND;

@Service
public class OrderService {
    private final static Logger logger = LoggerFactory.getLogger(OrderService.class);
    private final OrderRepo orderRepo;
    private final UserRepo userRepo;
    private final CartRepo cartRepo;

    @Autowired
    public OrderService(OrderRepo repo, UserRepo userRepo, CartRepo cartRepo) {
        this.cartRepo = cartRepo;
        this.userRepo = userRepo;
        this.orderRepo = repo;
    }

    public OrderData createOrder(UUID userId) {
        OrderData order=new OrderData();
        UserData userData=userRepo.findById(order.getUser().getUserId()).orElseThrow(()->new CustomException("User not found", NOT_FOUND));
        order.setUser(userData);
        CartData cartData=cartRepo.findByUser_UserId(userData.getUserId()).orElseThrow(()->new CustomException("Cart not found", NOT_FOUND));
        double totalAmount=0;
        List<ProductData> productData=new ArrayList<>();
             if(cartData.getCartItems()!=null && !cartData.getCartItems().isEmpty()) {
            for (CartItem p : cartData.getCartItems()) {
                productData.add(p.getProduct());
            }
        }
        if (!productData.isEmpty()) {
        for(ProductData p:productData){
           totalAmount+=p.getPrice();
        }
        }
        order.setTotalAmount(totalAmount);
        return orderRepo.save(order);
    }

    public ListResponse filterOrders(UUID orderId, UUID userId, OrderData.Status status, int page, int size) {
        ListResponse listResponse = new ListResponse();
        Pageable pageable = PageRequest.of(page, size);
        if (orderId != null) {
            if (orderRepo.existsById(orderId)) {
                listResponse.setData(orderRepo.findById(orderId));
                listResponse.setCount(1);
                return listResponse;
            }
        } else if (userId != null) {
            listResponse.setData(orderRepo.findByUser_UserId(userId, pageable));
            listResponse.setCount(orderRepo.findByUser_UserId(userId).size());
            return listResponse;
        } else if (status != null) {
            listResponse.setData(orderRepo.findByStatus(status, pageable));
            listResponse.setCount(orderRepo.findByStatus(status).size());
            return listResponse;
        }
        listResponse.setData(orderRepo.findAll(pageable));
        listResponse.setCount(orderRepo.findAll().size());
        return listResponse;
    }

    public String updateOrderDetails(UUID orderId, OrderData.Status status) {
        if (orderRepo.findById(orderId).isPresent()) {
            OrderData order = orderRepo.findById(orderId).get();
            order.setStatus(status);
            order.setUpdatedTimeStamp(new Date());
            orderRepo.save(order);
            return "Order details updated successfully";
        } else {
            throw new CustomException("No data found", NOT_FOUND);
        }
    }


}
