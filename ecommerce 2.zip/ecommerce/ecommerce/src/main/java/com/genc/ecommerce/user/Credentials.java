package com.genc.ecommerce.user;

import lombok.Data;

@Data
public class Credentials {
    private String userName;
    private String password;
    private String phoneNo;
}
