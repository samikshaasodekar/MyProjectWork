package com.genc.ecommerce.product;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface ProductRepo extends JpaRepository<ProductData, UUID> {
    Page<ProductData> findByNameContaining(String name, Pageable pageable);

    List<ProductData> findByNameContaining(String name);

    Page<ProductData> findByCategory_CategoryId(UUID categoryId, Pageable pageable);

    List<ProductData> findByCategory_CategoryId(UUID categoryId);

    List<ProductData> findByPriceBetween(double startPrice, double endPrice);

    Page<ProductData> findByPriceBetween(double startPrice, double endPrice, Pageable pageable);

    Page<ProductData> findByNameContainingOrPriceBetweenOrCategory_CategoryId(String name, Double startPrice, Double endPrice, UUID categoryId, Pageable pageable);
    List<ProductData> findByNameContainingOrPriceBetweenOrCategory_CategoryId(String name, Double startPrice, Double endPrice, UUID categoryId);
}
