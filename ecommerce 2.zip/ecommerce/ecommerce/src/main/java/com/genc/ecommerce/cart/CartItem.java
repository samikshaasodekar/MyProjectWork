package com.genc.ecommerce.cart;

import com.genc.ecommerce.product.ProductData;
import com.github.f4b6a3.uuid.UuidCreator;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;

import java.util.Date;
import java.util.UUID;

@Entity
@Data
public class CartItem {
    @Id
    private UUID cartItemId;
    @ManyToOne
    @JoinColumn(name = "cart_id")
    private CartData cart;
    @ManyToOne
    @JoinColumn(name = "product_id")
    private ProductData product;
    @PositiveOrZero
    private int quantity;
    private Date createdTimeStamp;
    private Date updatedTimeStamp;

    public CartItem(){
        if(this.cartItemId==null){
            this.cartItemId= UuidCreator.getTimeOrderedWithRandom();
            this.createdTimeStamp=new Date();
            this.updatedTimeStamp=createdTimeStamp;
        }
    }
}