package com.genc.ecommerce.cart;

import com.genc.ecommerce.dto.CartItemRequest;
import com.genc.ecommerce.product.ProductData;
import com.genc.ecommerce.product.ProductRepo;
import com.genc.ecommerce.utils.CustomException;
import com.genc.ecommerce.utils.ErrorCodes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class CartService {
    private final CartRepo cartRepository;
    private final CartItemRepo cartItemRepo;
    private final ProductRepo productRepo;

    @Autowired
    public CartService(CartRepo cartRepository,ProductRepo productRepo, CartItemRepo cartItemRepo) {
        this.cartRepository = cartRepository;
        this.cartItemRepo=cartItemRepo;
        this.productRepo=productRepo;
    }

    public CartData addCartItemToCart(CartItemRequest cartItemRequest){
        CartData savedCartData;
        CartData cartData= getCartByUserId(cartItemRequest.getUserId());
        CartItem cartItem= new CartItem();
        ProductData productData= productRepo.findById(cartItemRequest.getProductId()).orElseThrow(()-> new CustomException("Product not found", ErrorCodes.NOT_FOUND));
        cartItem.setProduct(productData);
        cartItem.setQuantity(cartItemRequest.getQuantity());
        cartData.getCartItems().add(cartItem);
        savedCartData=cartRepository.save(cartData);
        cartItem.setCart(cartData);
        cartItemRepo.save(cartItem);
        return savedCartData;
    }

    public CartData getCartByUserId(UUID userId) {
        return cartRepository.findByUser_UserId(userId).orElseThrow(()-> new CustomException("Cart not found for user", ErrorCodes.NOT_FOUND));
    }
}
