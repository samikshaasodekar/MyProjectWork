package com.genc.ecommerce.user;

import com.github.f4b6a3.uuid.UuidCreator;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.Date;
import java.util.UUID;

@Entity
@Data
@Table(name = "User")
public class UserData {
    @Id
    private UUID userId;
    @OneToOne
    @JoinColumn(name = "personal_details_id")
    private PersonalDetails personalDetails;
    @OneToOne
    @JoinColumn(name = "login_details_id")
    private LoginDetails loginDetails;
    private Role role;
    @NotBlank(message = "Email cannot be blank")
    @Email(message = "Please provide a valid email address")
    private String email;
    @Transient
    private String userName;
    @Transient
    private String decPwd;
    private Date createdTimeStamp;
    private Date updatedTimeStamp;

    public enum Role {
        SELLER, CUSTOMER, ADMIN
    }

    public UserData() {
        if (this.userId == null) {
            this.userId = UuidCreator.getTimeOrderedWithRandom();
            this.createdTimeStamp = new Date();
            this.updatedTimeStamp = createdTimeStamp;
        }
    }

}
