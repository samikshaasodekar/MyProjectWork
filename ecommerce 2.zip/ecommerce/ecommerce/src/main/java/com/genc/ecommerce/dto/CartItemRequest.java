package com.genc.ecommerce.dto;

import lombok.Data;

import java.util.UUID;

@Data
public class CartItemRequest {
    private UUID userId;
    private UUID productId;
    private int quantity;
}
