package com.genc.ecommerce.cart;

import com.genc.ecommerce.dto.CartItemRequest;
import com.genc.ecommerce.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping(value = "/cart")
public class CartController {
    private final CartService cartService;

    @Autowired
    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @PutMapping(value = "/addItems")
    public Response addItemsToCart(@RequestBody CartItemRequest cartItemRequest) {
        return  new Response(cartService.addCartItemToCart(cartItemRequest));
    }

    @GetMapping(value = "/getCartByUserId")
    public Response getCartByUserId(@RequestParam UUID userId) {
        return new Response(cartService.getCartByUserId(userId));
    }
}
