package com.genc.ecommerce.dto;

import lombok.Data;

import java.util.UUID;

@Data
public class ProductDto {
    private String productName;
    private String description;
    private double price;
    private UUID categoryId;
    private UUID userId;
    private int stockQuantity;
}
