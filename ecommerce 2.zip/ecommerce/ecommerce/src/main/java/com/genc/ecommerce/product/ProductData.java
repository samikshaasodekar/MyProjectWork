package com.genc.ecommerce.product;

import com.genc.ecommerce.user.UserData;
import com.github.f4b6a3.uuid.UuidCreator;
import jakarta.persistence.*;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;

import java.util.Date;
import java.util.UUID;

@Data
@Entity
@Table(name = "Product")
public class ProductData {
    @Id
    private UUID productId;
    private String name;
    @Lob
    private String description;
    @PositiveOrZero
    private double price;
    @ManyToOne
    @JoinColumn(name = "category_id")
    private CategoryData category;
    @ManyToOne
    @JoinColumn(name = "user_id")
    private UserData userData;
    @PositiveOrZero
    private int stockQuantity;
    private Date createdTimeStamp;
    private Date updatedTimeStamp;

    public ProductData() {
        if (this.productId == null) {
            this.productId = UuidCreator.getTimeOrderedWithRandom();
            this.createdTimeStamp = new Date();
            this.updatedTimeStamp = createdTimeStamp;
        }
    }
}
