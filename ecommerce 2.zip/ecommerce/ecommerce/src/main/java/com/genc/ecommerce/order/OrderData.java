package com.genc.ecommerce.order;

import com.genc.ecommerce.user.UserData;
import com.github.f4b6a3.uuid.UuidCreator;
import jakarta.persistence.*;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;

import java.util.Date;
import java.util.UUID;

@Entity
@Data
@Table(name = "Orders")
public class OrderData {
    @Id
    private UUID orderId;
    @ManyToOne
    @JoinColumn(name = "user_id")
    private UserData user;
    @PositiveOrZero
    private double totalAmount;
    private Status status;
    private Date createdTimeStamp;
    private Date updatedTimeStamp;

    public enum Status {
        INITIATED,
        PENDING,
        SHIPPED,
        DELIVERED,
        CANCELLED
    }

    public OrderData() {
        if (this.orderId == null) {
            this.orderId = UuidCreator.getTimeOrdered();
            this.createdTimeStamp = new Date();
            this.updatedTimeStamp = createdTimeStamp;
            this.status = Status.INITIATED;
        }
    }

}
