package com.genc.ecommerce.cart;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface CartRepo extends JpaRepository<CartData, UUID> {
    Optional<CartData> findByUser_UserId(UUID userId);
}
