package com.genc.ecommerce.payment;

import com.genc.ecommerce.order.OrderData;
import com.github.f4b6a3.uuid.UuidCreator;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;

import java.util.Date;
import java.util.UUID;

@Data
@Entity
public class PaymentData {
    @Id
    private UUID paymentId;
    @OneToOne
    @JoinColumn(name = "order_id")
    private OrderData order;
    @PositiveOrZero
    private double amount;
    private Date paymentDate;
    private PaymentStatus paymentStatus;
    private PaymentMethod paymentMethod;
    private Date createdTimeStamp;
    private Date updatedTimeStamp;

    public enum PaymentStatus {
        PENDING,
        COMPLETED,
        FAILED,
        REFUNDED
    }

    public enum PaymentMethod {
        CARD,
        BANK_TRANSFER,
        CASH_ON_DELIVERY
    }

    public PaymentData(){
        if(this.paymentId==null){
            this.paymentId= UuidCreator.getTimeBasedWithRandom();
            this.paymentStatus=PaymentStatus.PENDING;
            this.createdTimeStamp=new Date();
            this.updatedTimeStamp=createdTimeStamp;
        }
    }

}
