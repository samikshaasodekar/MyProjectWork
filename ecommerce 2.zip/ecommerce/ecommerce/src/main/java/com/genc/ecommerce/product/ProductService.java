package com.genc.ecommerce.product;

import com.genc.ecommerce.dto.ProductDto;
import com.genc.ecommerce.user.UserData;
import com.genc.ecommerce.user.UserRepo;
import com.genc.ecommerce.utils.CustomException;
import com.genc.ecommerce.utils.ErrorCodes;
import com.genc.ecommerce.utils.ListResponse;
import org.apache.catalina.User;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.UUID;

import static com.genc.ecommerce.utils.ErrorCodes.*;

@Service
public class ProductService {
    private final static Logger logger = LogManager.getLogger(ProductService.class);
    private final ProductRepo productRepo;
    private final CategoryRepo categoryRepo;
    private final UserRepo userRepo;

    @Autowired
    public ProductService(ProductRepo productRepo, CategoryRepo categoryRepo, UserRepo userRepo) {
        this.productRepo = productRepo;
        this.categoryRepo = categoryRepo;
        this.userRepo=userRepo;
    }

    public CategoryData createCategory(CategoryData category) {
        if (StringUtils.isNotBlank(category.getName())) {
            CategoryData savedData = categoryRepo.save(category);
            logger.info("Category - {} saved successfully at {}", category.getCategoryId().toString(), new Date());
            return savedData;
        } else {
            throw new CustomException("Category Name not found", BAD_REQUEST);
        }
    }

    public ListResponse getAllCategories() {
        ListResponse listResponse = new ListResponse();
        listResponse.setCount(categoryRepo.findAll().size());
        listResponse.setData(categoryRepo.findAll());
        return listResponse;
    }

    public ProductData createProduct(ProductDto data) {
        if (data.getUserId() != null) {
            UserData userData = userRepo.findById(data.getUserId()).orElseThrow(() -> new CustomException("User not found", NOT_FOUND));
            if (userData.getRole() == UserData.Role.SELLER || userData.getRole() == UserData.Role.ADMIN) {
                if (categoryRepo.findById(data.getCategoryId()).isPresent()) {
                    ProductData productData = new ProductData();
                    CategoryData categoryData = categoryRepo.findById(data.getCategoryId()).orElseThrow(() -> new CustomException("Category not found", NOT_FOUND));
                    if (StringUtils.isNotBlank(data.getProductName())) {
                        productData.setName(data.getProductName());
                        productData.setDescription(data.getDescription());
                        productData.setPrice(data.getPrice());
                        productData.setCategory(categoryData);
                        productData.setUserData(userData);
                        productData.setStockQuantity(data.getStockQuantity());
                        ProductData savedProduct = productRepo.save(productData);
                        logger.info("Product - {} saved successfully at {}", productData.getProductId().toString(), new Date());
                        return savedProduct;
                    } else {
                        throw new CustomException("Product Name is Empty", BAD_REQUEST);
                    }
                } else {
                    throw new CustomException("Category Not Found", NOT_FOUND);
                }
            }
            else {
                throw new CustomException("Access Denied", UNAUTHORIZED);
            }
        }else{
            throw new CustomException("User Id cannot be empty", BAD_REQUEST);
        }
    }

    public ListResponse filterProducts(String productName, Double startPrice, Double endPrice, UUID categoryId, int page, int size) {
        if((startPrice==null ) != ( endPrice==null)){
            throw new CustomException("Both startPrice and endPrice should be provided", BAD_REQUEST);
        }
        Pageable pageable = PageRequest.of(page, size);
        boolean filters=(StringUtils.isNotBlank(productName)) || (startPrice!=null && endPrice!=null) || (categoryId != null);
        ListResponse listResponse = new ListResponse();
        if (filters) {
            listResponse.setData(productRepo.findByNameContainingOrPriceBetweenOrCategory_CategoryId(productName,startPrice,endPrice,categoryId, pageable));
            listResponse.setCount(productRepo.findByNameContainingOrPriceBetweenOrCategory_CategoryId(productName,startPrice,endPrice,categoryId).size());
            return listResponse;
        }
        listResponse.setData(productRepo.findAll(pageable));
        listResponse.setCount(productRepo.findAll().size());
        return listResponse;
    }

    public ProductData getById(UUID id) {
       return productRepo.findById(id).orElseThrow();
    }

    public String updateProduct(ProductData productData) {
        if (productRepo.existsById(productData.getProductId())) {
            productData.setUpdatedTimeStamp(new Date());
            productRepo.save(productData);
            logger.info("Product - {} updated successfully at {}", productData.getProductId().toString(), new Date());
            return "Product Updated Successfully";
        } else {
            throw new CustomException("No product found", NOT_FOUND);
        }
    }

    public String deleteProduct(UUID productId) {
        if (productRepo.findById(productId).isPresent()) {
            productRepo.deleteById(productId);
            logger.info("Product - {} deleted successfully at {}", productId.toString(), new Date());
            return "Product Deleted Successfully";
        } else {
            throw new CustomException("No product found", NOT_FOUND);
        }
    }
}
