package com.genc.ecommerce.user;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface UserRepo extends JpaRepository<UserData, UUID> {
    Optional<UserData> findByEmailAndRole(String email, UserData.Role role);

    UserData findByLoginDetails_Id(UUID id);
}
