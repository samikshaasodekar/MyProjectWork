package com.genc.ecommerce.cart;

import com.genc.ecommerce.user.UserData;
import com.github.f4b6a3.uuid.UuidCreator;
import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Data
@Entity
public class CartData {
    @Id
    private UUID cartId;
    @OneToOne
    @JoinColumn(name = "user_id")
    private UserData user;

    @OneToMany(mappedBy = "cart", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<CartItem> cartItems;
    private Date createdTimeStamp;
    private Date updatedTimeStamp;


    public CartData(){
        if(this.cartId==null){
            this.cartId= UuidCreator.getTimeOrderedWithRandom();
            this.cartItems= new HashSet<>();
            this.createdTimeStamp=new Date();
            this.updatedTimeStamp=createdTimeStamp;
        }
    }

}
