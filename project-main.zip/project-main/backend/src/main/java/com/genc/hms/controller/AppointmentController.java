package com.genc.hms.controller;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.genc.hms.dto.AppointmentRequestDTO;
import com.genc.hms.dto.AppointmentResponseDTO;
import com.genc.hms.enums.AppointmentStatus;
import com.genc.hms.service.AppointmentService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin
@RequestMapping("/api/appointments")
public class AppointmentController {

    private static final Logger logger = LoggerFactory.getLogger(AppointmentController.class);

    @Autowired
    private AppointmentService appointmentService;

    // ----------------- Creation & Slots -----------------

    @PostMapping
    public ResponseEntity<AppointmentResponseDTO> bookAppointment(@Valid @RequestBody AppointmentRequestDTO requestDTO) {
        logger.info("Booking appointment for patient {} with doctor {} on {}", requestDTO.getPatientId(), requestDTO.getDoctorId(), requestDTO.getAppointmentDate());
        return appointmentService.bookAppointment(requestDTO)
                .map(dto -> new ResponseEntity<>(dto, HttpStatus.CREATED))
                .orElseGet(() -> {
                    logger.warn("Failed to book appointment: slot unavailable or invalid data");
                    return ResponseEntity.badRequest().build();
                });
    }

    @GetMapping("/slots/{doctorId}")
    public ResponseEntity<List<String>> getAvailableSlots(@PathVariable Long doctorId, @RequestParam LocalDate date) {
        logger.info("Fetching available slots for doctor {} on {}", doctorId, date);
        List<String> slots = appointmentService.getAvailableSlots(doctorId, date);
        return ResponseEntity.ok(slots);
    }

    // ----------------- Retrieval -----------------

    @GetMapping("/all")
    public ResponseEntity<List<AppointmentResponseDTO>> findAllAppointments() {
        logger.info("Retrieving all appointments");
        return ResponseEntity.ok(appointmentService.findAllAppointments());
    }

    @GetMapping("/{appointmentId}")
    public ResponseEntity<AppointmentResponseDTO> findAppointmentById(@PathVariable Long appointmentId) {
        logger.info("Fetching appointment {}", appointmentId);
        return appointmentService.findAppointmentById(appointmentId)
                .map(ResponseEntity::ok)
                .orElseGet(() -> {
                    logger.warn("Appointment {} not found", appointmentId);
                    return ResponseEntity.notFound().build();
                });
    }

    @GetMapping("/patient/{patientId}")
    public ResponseEntity<List<AppointmentResponseDTO>> getAppointmentsForPatient(@PathVariable Long patientId) {
        logger.info("Fetching appointments for patient {}", patientId);
        return ResponseEntity.ok(appointmentService.getAppointmentsForPatient(patientId));
    }

    @GetMapping("/doctor/{doctorId}")
    public ResponseEntity<List<AppointmentResponseDTO>> getAppointmentsForDoctor(@PathVariable Long doctorId) {
        logger.info("Fetching appointments for doctor {}", doctorId);
        return ResponseEntity.ok(appointmentService.getAppointmentsForDoctor(doctorId));
    }

    // ----------------- Modification -----------------

    @PutMapping("/{appointmentId}/reschedule")
    public ResponseEntity<AppointmentResponseDTO> rescheduleAppointment(@PathVariable Long appointmentId,
                                                                        @Valid @RequestBody AppointmentRequestDTO requestDTO) {
        logger.info("Rescheduling appointment {} to {} for doctor {}", appointmentId, requestDTO.getAppointmentDate(), requestDTO.getDoctorId());
        return appointmentService.rescheduleAppointment(appointmentId, requestDTO)
                .map(ResponseEntity::ok)
                .orElseGet(() -> {
                    logger.warn("Failed to reschedule appointment {}", appointmentId);
                    return ResponseEntity.badRequest().build();
                });
    }

    @PutMapping("/{appointmentId}/status")
    public ResponseEntity<AppointmentResponseDTO> updateAppointmentStatus(@PathVariable Long appointmentId,
                                                                          @RequestParam AppointmentStatus status, @RequestParam(required = false) String remarks) {
        logger.info("Updating appointment {} status to {}. Remarks: {}", appointmentId, status, remarks);
        return appointmentService.updateAppointmentStatus(appointmentId, status, remarks)
                .map(ResponseEntity::ok)
                .orElseGet(() -> {
                    logger.warn("Failed to update status for appointment {}", appointmentId);
                    return ResponseEntity.notFound().build();
                });
    }

    @PutMapping("/{appointmentId}/cancel")
    public ResponseEntity<Void> cancelAppointment(@PathVariable Long appointmentId) {
        logger.info("Cancelling appointment {}", appointmentId);
        boolean cancelled = appointmentService.cancelAppointment(appointmentId);
        if (cancelled) {
            return ResponseEntity.noContent().build();
        } else {
            logger.warn("Failed to cancel appointment {}", appointmentId);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }
}
