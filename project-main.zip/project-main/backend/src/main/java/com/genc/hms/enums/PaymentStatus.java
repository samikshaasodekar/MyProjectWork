package com.genc.hms.enums;

public enum PaymentStatus {
	PAID, PENDING, REFUNDED, CANCELLED
}
