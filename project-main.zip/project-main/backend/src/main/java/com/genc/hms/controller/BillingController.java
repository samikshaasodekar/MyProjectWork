package com.genc.hms.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.genc.hms.dto.BillResponseDTO;
import com.genc.hms.enums.PaymentStatus;
import com.genc.hms.service.BillingService;

import jakarta.servlet.http.HttpSession;

@RestController
@CrossOrigin
@RequestMapping("/api/bills")
public class BillingController {

    private static final Logger logger = LoggerFactory.getLogger(BillingController.class);

    private static final String LOGGED_IN_USER_ID_KEY = "LOGGED_IN_USER_ID";

    @Autowired
    private BillingService billingService;

    // ----------------- Retrieval -----------------

    @GetMapping("/{billId}")
    public ResponseEntity<BillResponseDTO> getBillById(@PathVariable Long billId, HttpSession session) {
        Long userId = (Long) session.getAttribute(LOGGED_IN_USER_ID_KEY);
        logger.info("User {} fetching bill by ID {}", userId, billId);

        return billingService.getBillById(billId)
                .map(dto -> {
                    logger.info("Bill {} found", billId);
                    return ResponseEntity.ok(dto);
                })
                .orElseGet(() -> {
                    logger.warn("Bill {} not found", billId);
                    return ResponseEntity.notFound().build();
                });
    }

    @GetMapping("/appointment/{appointmentId}")
    public ResponseEntity<BillResponseDTO> getBillByAppointmentId(@PathVariable Long appointmentId, HttpSession session) {
        Long userId = (Long) session.getAttribute(LOGGED_IN_USER_ID_KEY);
        logger.info("User {} fetching bill for appointment {}", userId, appointmentId);

        return billingService.getBillByAppointmentId(appointmentId)
                .map(dto -> {
                    logger.info("Bill for appointment {} found", appointmentId);
                    return ResponseEntity.ok(dto);
                })
                .orElseGet(() -> {
                    logger.warn("Bill for appointment {} not found", appointmentId);
                    return ResponseEntity.notFound().build();
                });
    }

    @GetMapping("/patient/{patientId}")
    public ResponseEntity<List<BillResponseDTO>> getBillsForPatient(@PathVariable Long patientId, HttpSession session) {
        Long userId = (Long) session.getAttribute(LOGGED_IN_USER_ID_KEY);
        logger.info("User {} fetching bills for patient {}", userId, patientId);

        List<BillResponseDTO> bills = billingService.getBillsByPatient(patientId);
        logger.info("Found {} bills for patient {}", bills.size(), patientId);
        return ResponseEntity.ok(bills);
    }

    @GetMapping
    public ResponseEntity<List<BillResponseDTO>> getBillsByStatus(@RequestParam PaymentStatus status, HttpSession session) {
        Long userId = (Long) session.getAttribute(LOGGED_IN_USER_ID_KEY);
        logger.info("User {} fetching bills with status {}", userId, status);

        List<BillResponseDTO> bills = billingService.getBillsByStatus(status);
        logger.info("Found {} bills with status {}", bills.size(), status);
        return ResponseEntity.ok(bills);
    }

    // ----------------- Modification -----------------

    @PutMapping("/{billId}/pay")
    public ResponseEntity<BillResponseDTO> recordPayment(@PathVariable Long billId, HttpSession session) {
        Long userId = (Long) session.getAttribute(LOGGED_IN_USER_ID_KEY);
        logger.info("User {} recording payment for bill {}", userId, billId);

        return billingService.recordPayment(billId)
                .map(dto -> {
                    logger.info("Payment recorded for bill {}", billId);
                    return ResponseEntity.ok(dto);
                })
                .orElseGet(() -> {
                    logger.warn("Failed to record payment: bill {} not found", billId);
                    return ResponseEntity.notFound().build();
                });
    }
}
