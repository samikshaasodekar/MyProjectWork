package com.genc.hms.enums;

public enum AppointmentStatus {
	CONFIRMED, CANCELLED, COMPLETED
}
