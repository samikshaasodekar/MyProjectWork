package com.genc.hms.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.genc.hms.dto.*;
import com.genc.hms.entity.User;
import com.genc.hms.repository.UserRepository;
import com.genc.hms.util.CustomPasswordEncoder;

@Service
public class AdminService {

    // --- Dependencies ---
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserService userService; // Helper for registration, role management

    @Autowired
    private PatientService patientService; // Patient-specific operations

    @Autowired
    private DoctorService doctorService; // Doctor-specific operations

    @Autowired
    private AppointmentService appointmentService; // Appointment retrieval

    @Autowired
    private BillingService billingService; // Billing retrieval

    @Autowired
    private CustomPasswordEncoder customPasswordEncoder;

    // =================================================================================
    // I. USER REGISTRATION
    // =================================================================================

    /**
     * Registers a new Doctor user.
     * Delegates core logic to UserService for role handling and persistence.
     */
    @Transactional
    public UserResponseDTO registerNewDoctor(DoctorRegisterRequestDTO registrationDetails) {
        return userService.registerDoctor(registrationDetails);
    }

    /**
     * Registers a new Patient user.
     * Delegates core logic to UserService.
     */
    @Transactional
    public UserResponseDTO registerNewPatient(PatientRegisterRequestDTO registrationDetails) {
        return userService.registerPatient(registrationDetails);
    }

    // =================================================================================
    // II. GENERAL USER MANAGEMENT (CRUD)
    // =================================================================================

    /**
     * Retrieves all users (Admins, Doctors, Patients) with role info.
     */
    @Transactional(readOnly = true)
    public List<UserResponseDTO> getAllUsers() {
        return userRepository.findAll().stream()
                .map(user -> new UserResponseDTO(
                        user.getUserId(),
                        userService.getRoleIdFromUser(user),
                        user.getEmail(),
                        user.getRole().name()
                ))
                .collect(Collectors.toList());
    }

    /**
     * Updates a user's email and/or role.
     * Returns updated DTO or empty if user not found.
     */
    @Transactional
    public Optional<UserResponseDTO> updateUserIdentity(Long userId, UserUpdateRoleAndEmailDTO updateDTO) {
        return userRepository.findById(userId).map(user -> {
            boolean changed = false;

            // Update email if provided
            if (updateDTO.getEmail() != null && !updateDTO.getEmail().equals(user.getEmail())) {
                user.setEmail(updateDTO.getEmail());
                changed = true;
            }

            // Update role if provided
            if (updateDTO.getRole() != null && updateDTO.getRole() != user.getRole()) {
                user.setRole(updateDTO.getRole());
                changed = true;
            }

            if (changed) {
                User savedUser = userRepository.save(user);
                Long roleId = userService.getRoleIdFromUser(savedUser);
                return new UserResponseDTO(savedUser.getUserId(), roleId, savedUser.getEmail(),
                        savedUser.getRole().name());
            }

            // Return current info if no changes
            Long roleId = userService.getRoleIdFromUser(user);
            return new UserResponseDTO(user.getUserId(), roleId, user.getEmail(), user.getRole().name());
        });
    }

    /**
     * Resets a user's password.
     * Encodes password before saving.
     */
    @Transactional
    public boolean resetUserPassword(Long userId, String newPassword) {
        return userRepository.findById(userId).map(user -> {
            user.setPassword(customPasswordEncoder.encode(newPassword));
            userRepository.save(user);
            return true;
        }).orElse(false);
    }

    /**
     * Deletes a user by ID.
     * Returns false if user not found.
     */
    @Transactional
    public boolean deleteUser(Long userId) {
        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isEmpty()) return false;

        User user = userOptional.get();
        // Note: Cascade/orphan removal may handle associated Doctor/Patient entries.
        userRepository.delete(user);
        return true;
    }

    // =================================================================================
    // III. ROLE-SPECIFIC MANAGEMENT & RETRIEVAL
    // =================================================================================

    // --- Patient Management ---

    /**
     * Retrieves all patient profiles.
     */
    @Transactional(readOnly = true)
    public List<PatientResponseDTO> getAllPatients() {
        return patientService.getAllPatients();
    }

    // --- Doctor Management ---

    /**
     * Retrieves all doctor profiles.
     */
    @Transactional(readOnly = true)
    public List<DoctorResponseDTO> getAllDoctors() {
        return doctorService.findAllDoctors();
    }

    /**
     * Updates a doctor's profile (non-identity fields, e.g., contact, specialization).
     */
    @Transactional
    public Optional<DoctorResponseDTO> updateDoctorProfile(Long doctorId, DoctorProfileUpdateDTO updateDTO) {
        return doctorService.updateDoctorProfile(doctorId, updateDTO);
    }

    // --- Appointment Management ---

    /**
     * Retrieves all appointments.
     */
    @Transactional(readOnly = true)
    public List<AppointmentResponseDTO> getAllAppointments() {
        return appointmentService.findAllAppointments();
    }

    // --- Billing Management ---

    /**
     * Retrieves all bills.
     */
    @Transactional(readOnly = true)
    public List<BillResponseDTO> getAllBills() {
        return billingService.getAllBills();
    }

    /**
     * Returns the total number of admin users.
     */
    public Long getCount() {
        return userRepository.getAdminCount();
    }
}
