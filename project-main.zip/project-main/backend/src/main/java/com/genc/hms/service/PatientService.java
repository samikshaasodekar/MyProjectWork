package com.genc.hms.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.genc.hms.dto.PatientResponseDTO;
import com.genc.hms.dto.PatientUpdateRequestDTO;
import com.genc.hms.entity.Patient;
import com.genc.hms.entity.User;
import com.genc.hms.repository.PatientRepository;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    // =================================================================================
    // I. PRIVATE UTILITY
    // =================================================================================

    /** Maps Patient entity to PatientResponseDTO including user info. */
    private PatientResponseDTO mapToResponseDTO(Patient patient) {
        User user = patient.getUser();
        return new PatientResponseDTO(
                patient.getPatientId(),
                user.getUserId(),
                user.getEmail(),
                patient.getName(),
                patient.getDob(),
                patient.getContactNumber(),
                patient.getAddress(),
                patient.getGender(),
                patient.getMedicalHistory()
        );
    }

    // =================================================================================
    // II. CREATE
    // =================================================================================

    /** Persists a new Patient entity. */
    @Transactional
    public Patient createPatient(Patient patient) {
        return patientRepository.save(patient);
    }

    // =================================================================================
    // III. UPDATE
    // =================================================================================

    /** Updates profile fields of an existing patient. */
    @Transactional
    public Patient updatePatientProfile(Long patientId, PatientUpdateRequestDTO updateDTO) {
        Optional<Patient> patientOpt = patientRepository.findById(patientId);
        if (patientOpt.isEmpty()) return null;

        Patient patient = patientOpt.get();
        patient.setName(updateDTO.getName());
        patient.setDob(updateDTO.getDob());
        patient.setContactNumber(updateDTO.getContactNumber());
        patient.setAddress(updateDTO.getAddress());
        patient.setGender(updateDTO.getGender());
        patient.setMedicalHistory(updateDTO.getMedicalHistory());

        return patientRepository.save(patient);
    }

    // =================================================================================
    // IV. RETRIEVAL
    // =================================================================================

    /** Retrieves all patients as DTOs. */
    @Transactional(readOnly = true)
    public List<PatientResponseDTO> getAllPatients() {
        return patientRepository.findAll().stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
    }

    /** Retrieves a patient by ID as DTO. */
    @Transactional(readOnly = true)
    public Optional<PatientResponseDTO> findPatientProfileByPatientId(Long patientId) {
        return patientRepository.findById(patientId)
                .map(this::mapToResponseDTO);
    }

    /** Retrieves a patient entity by ID (for internal use). */
    public Optional<Patient> findById(Long patientId) {
        return patientRepository.findById(patientId);
    }

    // =================================================================================
    // V. SEARCH
    // =================================================================================

    /** Searches patients by keyword in name (case-insensitive). */
    @Transactional(readOnly = true)
    public List<PatientResponseDTO> searchPatient(String keyword) {
        if (!StringUtils.hasText(keyword)) return null;

        return patientRepository.findByNameContainingIgnoreCase(keyword).stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
    }

    /** Finds patients by exact name (rarely used). */
    public List<Patient> findByName(String name) {
        return patientRepository.findByName(name);
    }

    // =================================================================================
    // VI. MISC
    // =================================================================================

    /** Returns total patient count. */
    public Long getCount() {
        return patientRepository.count();
    }

    /** Deletes a patient by ID; returns false if not found. */
    @Transactional
    public boolean deletePatient(long id) {
        Optional<Patient> patientOpt = patientRepository.findById(id);
        if (patientOpt.isEmpty()) return false;

        patientRepository.delete(patientOpt.get());
        return true;
    }
}
