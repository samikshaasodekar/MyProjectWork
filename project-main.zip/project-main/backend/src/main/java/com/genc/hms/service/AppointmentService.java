package com.genc.hms.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.genc.hms.dto.AppointmentRequestDTO;
import com.genc.hms.dto.AppointmentResponseDTO;
import com.genc.hms.entity.Appointment;
import com.genc.hms.entity.Doctor;
import com.genc.hms.entity.DoctorAvailability;
import com.genc.hms.entity.Patient;
import com.genc.hms.enums.AppointmentStatus;
import com.genc.hms.repository.AppointmentRepository;

@Service
public class AppointmentService {

    // --- Constants ---
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm");
    private static final int SLOT_DURATION_MINUTES = 30; // Standard appointment duration

    // --- Dependencies ---
    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private PatientService patientService;

    @Autowired
    private DoctorService doctorService;

    @Autowired
    private BillingService billingService;

    // =================================================================================
    // I. PRIVATE UTILITY & VALIDATION METHODS
    // =================================================================================

    /**
     * Converts a time slot string ("HH:mm-HH:mm") into LocalTime start/end objects.
     */
    private LocalTime[] parseTimeSlot(String timeSlot) {
        String[] parts = timeSlot.split("-");
        if (parts.length != 2) throw new IllegalArgumentException("Invalid time slot: " + timeSlot);
        return new LocalTime[]{ LocalTime.parse(parts[0], TIME_FORMATTER), LocalTime.parse(parts[1], TIME_FORMATTER) };
    }

    /**
     * Validates a requested appointment slot against a doctor's general schedule and standard duration.
     */
    private boolean validateTimeSlotAgainstAvailability(Doctor doctor, LocalDate date, String timeSlot) {
        try {
            LocalTime[] times = parseTimeSlot(timeSlot);
            long duration = ChronoUnit.MINUTES.between(times[0], times[1]);
            if (duration != SLOT_DURATION_MINUTES) return false;

            Optional<DoctorAvailability> availabilityOptional = checkDoctorGeneralAvailability(doctor, date);
            if (availabilityOptional.isEmpty()) return false;

            DoctorAvailability availability = availabilityOptional.get();
            return !times[0].isBefore(availability.getStartTime()) && !times[1].isAfter(availability.getEndTime());
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Returns the DoctorAvailability for the given date's weekday.
     */
    private Optional<DoctorAvailability> checkDoctorGeneralAvailability(Doctor doctor, LocalDate date) {
        return doctor.getDoctorAvailabilities().stream()
                .filter(a -> a.getDayOfWeek().name().equals(date.getDayOfWeek().name()))
                .findFirst();
    }

    /**
     * Checks if the requested slot is already booked for a doctor (ignoring cancelled appointments).
     */
    private boolean isSlotConflicted(Long doctorId, LocalDate date, String timeSlot) {
        return appointmentRepository.countByDoctorDoctorIdAndAppointmentDateAndTimeSlotAndStatusNot(
                doctorId, date, timeSlot, AppointmentStatus.CANCELLED) > 0;
    }

    /**
     * Maps an Appointment entity to a response DTO.
     */
    private AppointmentResponseDTO mapAppointmentToResponseDTO(Appointment appointment) {
        Doctor doctor = appointment.getDoctor();
        Patient patient = appointment.getPatient();
        return new AppointmentResponseDTO(
                appointment.getAppointmentId(),
                patient.getPatientId(),
                patient.getName(),
                doctor.getDoctorId(),
                doctor.getName(),
                doctor.getSpecialization(),
                appointment.getAppointmentDate(),
                appointment.getTimeSlot(),
                appointment.getReason(),
                appointment.getStatus(),
                appointment.getRemarks()
        );
    }

    // =================================================================================
    // II. READ OPERATIONS (GET)
    // =================================================================================

    /** Returns all appointments (admin view). */
    @Transactional(readOnly = true)
    public List<AppointmentResponseDTO> findAllAppointments() {
        return appointmentRepository.findAll().stream()
                .map(this::mapAppointmentToResponseDTO)
                .collect(Collectors.toList());
    }

    /** Returns all appointments for a specific patient. */
    @Transactional(readOnly = true)
    public List<AppointmentResponseDTO> getAppointmentsForPatient(Long patientId) {
        return appointmentRepository.findByPatient_PatientIdOrderByAppointmentDateAsc(patientId).stream()
                .map(this::mapAppointmentToResponseDTO).collect(Collectors.toList());
    }

    /** Returns all appointments for a specific doctor. */
    @Transactional(readOnly = true)
    public List<AppointmentResponseDTO> getAppointmentsForDoctor(Long doctorId) {
        return appointmentRepository.findByDoctor_DoctorIdOrderByAppointmentDateAsc(doctorId).stream()
                .map(this::mapAppointmentToResponseDTO).collect(Collectors.toList());
    }

    /** Finds an appointment by ID and returns the DTO. */
    @Transactional(readOnly = true)
    public Optional<AppointmentResponseDTO> findAppointmentById(Long appointmentId) {
        return appointmentRepository.findById(appointmentId).map(this::mapAppointmentToResponseDTO);
    }

    /** Returns the raw Appointment entity (internal use). */
    @Transactional(readOnly = true)
    public Optional<Appointment> findById(Long appointmentId) {
        return appointmentRepository.findById(appointmentId);
    }

    /**
     * Returns all available 30-minute slots for a doctor on a given date,
     * excluding booked or unavailable times.
     */
    @Transactional(readOnly = true)
    public List<String> getAvailableSlots(Long doctorId, LocalDate date) {
        Optional<Doctor> doctorOpt = doctorService.findById(doctorId);
        if (doctorOpt.isEmpty()) return List.of();

        Doctor doctor = doctorOpt.get();
        Optional<DoctorAvailability> availabilityOpt = checkDoctorGeneralAvailability(doctor, date);
        if (availabilityOpt.isEmpty()) return List.of();

        DoctorAvailability availability = availabilityOpt.get();
        List<String> allSlots = new ArrayList<>();
        LocalTime current = availability.getStartTime();

        while (current.plusMinutes(SLOT_DURATION_MINUTES).isBefore(availability.getEndTime().plusSeconds(1))) {
            String slot = current.format(TIME_FORMATTER) + "-" + current.plusMinutes(SLOT_DURATION_MINUTES).format(TIME_FORMATTER);
            allSlots.add(slot);
            current = current.plusMinutes(SLOT_DURATION_MINUTES);
        }

        // Remove already booked slots
        Set<String> booked = appointmentRepository.findByDoctorDoctorIdAndAppointmentDateAndStatusNot(
                        doctorId, date, AppointmentStatus.CANCELLED).stream()
                .map(Appointment::getTimeSlot).collect(Collectors.toSet());

        return allSlots.stream().filter(s -> !booked.contains(s)).collect(Collectors.toList());
    }

    // =================================================================================
    // III. CREATE OPERATION (Book)
    // =================================================================================

    /** Books a new appointment with validation against availability and conflicts. */
    @Transactional
    public Optional<AppointmentResponseDTO> bookAppointment(AppointmentRequestDTO requestDTO) {
        Optional<Patient> patientOpt = patientService.findById(requestDTO.getPatientId());
        Optional<Doctor> doctorOpt = doctorService.findById(requestDTO.getDoctorId());
        if (patientOpt.isEmpty() || doctorOpt.isEmpty()) return Optional.empty();

        Doctor doctor = doctorOpt.get();

        // Validate slot against doctor's schedule and existing bookings
        if (!validateTimeSlotAgainstAvailability(doctor, requestDTO.getAppointmentDate(), requestDTO.getTimeSlot())) return Optional.empty();
        if (isSlotConflicted(requestDTO.getDoctorId(), requestDTO.getAppointmentDate(), requestDTO.getTimeSlot())) return Optional.empty();

        Appointment appointment = new Appointment();
        appointment.setPatient(patientOpt.get());
        appointment.setDoctor(doctor);
        appointment.setAppointmentDate(requestDTO.getAppointmentDate());
        appointment.setTimeSlot(requestDTO.getTimeSlot());
        appointment.setReason(requestDTO.getReason());
        appointment.setStatus(AppointmentStatus.CONFIRMED);

        Appointment saved = appointmentRepository.save(appointment);
        billingService.createInitialBill(saved, doctor); // Trigger billing

        return Optional.of(mapAppointmentToResponseDTO(saved));
    }

    // =================================================================================
    // IV. UPDATE & CANCEL OPERATIONS
    // =================================================================================

    /** Reschedules an appointment to a new date/time/doctor with validations. */
    @Transactional
    public Optional<AppointmentResponseDTO> rescheduleAppointment(Long appointmentId, AppointmentRequestDTO requestDTO) {
        Optional<Appointment> appointmentOpt = appointmentRepository.findById(appointmentId);
        if (appointmentOpt.isEmpty()) return Optional.empty();

        Appointment appointment = appointmentOpt.get();
        if (appointment.getStatus() == AppointmentStatus.CANCELLED || appointment.getStatus() == AppointmentStatus.COMPLETED) return Optional.empty();

        Optional<Doctor> newDoctorOpt = doctorService.findById(requestDTO.getDoctorId());
        if (newDoctorOpt.isEmpty()) return Optional.empty();

        Doctor newDoctor = newDoctorOpt.get();
        LocalDate newDate = requestDTO.getAppointmentDate();
        String newTime = requestDTO.getTimeSlot();

        if (!validateTimeSlotAgainstAvailability(newDoctor, newDate, newTime)) return Optional.empty();

        boolean unchanged = appointment.getAppointmentDate().equals(newDate)
                && appointment.getTimeSlot().equals(newTime)
                && appointment.getDoctor().getDoctorId().equals(newDoctor.getDoctorId());

        if (!unchanged && isSlotConflicted(newDoctor.getDoctorId(), newDate, newTime)) return Optional.empty();

        // Update doctor and trigger billing if doctor changed
        if (!appointment.getDoctor().getDoctorId().equals(newDoctor.getDoctorId())) {
            appointment.setDoctor(newDoctor);
            billingService.updateBillForDoctorChange(appointment, newDoctor);
        }

        appointment.setAppointmentDate(newDate);
        appointment.setTimeSlot(newTime);
        appointment.setReason(requestDTO.getReason());
        appointment.setStatus(AppointmentStatus.CONFIRMED);

        return Optional.of(mapAppointmentToResponseDTO(appointmentRepository.save(appointment)));
    }

    /** Updates appointment status (e.g., COMPLETED, CANCELLED). */
    @Transactional
    public Optional<AppointmentResponseDTO> updateAppointmentStatus(Long appointmentId, AppointmentStatus newStatus, String remarks) {
        return appointmentRepository.findById(appointmentId).map(appointment -> {
            appointment.setStatus(newStatus);
            appointment.setRemarks(remarks);
            return mapAppointmentToResponseDTO(appointmentRepository.save(appointment));
        });
    }

    /** Cancels an appointment and triggers corresponding billing cancellation. */
    @Transactional
    public boolean cancelAppointment(Long appointmentId) {
        return appointmentRepository.findById(appointmentId).map(appointment -> {
            if (appointment.getStatus() == AppointmentStatus.COMPLETED) return false;
            if (appointment.getStatus() != AppointmentStatus.CANCELLED) {
                appointment.setStatus(AppointmentStatus.CANCELLED);
                appointmentRepository.save(appointment);
                billingService.cancelBillForAppointment(appointment);
                return true;
            }
            return false;
        }).orElse(false);
    }

    public Long getCount() {
        return appointmentRepository.count();
    }
}
