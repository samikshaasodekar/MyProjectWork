package com.genc.hms.enums;

public enum Role {
	PATIENT, DOCTOR, ADMIN
}