package com.genc.hms.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.genc.hms.dto.BillResponseDTO;
import com.genc.hms.entity.Appointment;
import com.genc.hms.entity.Bill;
import com.genc.hms.entity.Doctor;
import com.genc.hms.enums.PaymentStatus;
import com.genc.hms.repository.BillRepository;

@Service
public class BillingService {

    // --- Dependencies ---
    @Autowired
    private BillRepository billRepository;

    @Autowired
    private DoctorService doctorService;

    // =================================================================================
    // I. PRIVATE UTILITY METHODS
    // =================================================================================

    /**
     * Retrieves the consultation fee from a Doctor entity.
     * Delegates to DoctorService to ensure business logic isolation.
     */
    private BigDecimal getConsultationFee(Doctor doctor) {
        return doctorService.getDoctorFee(doctor);
    }

    /**
     * Converts a Bill entity to a response DTO.
     * This is used for sending data to controllers or API responses.
     */
    private BillResponseDTO mapBillToResponseDTO(Bill bill) {
        return new BillResponseDTO(
                bill.getBillId(),
                bill.getPatient().getPatientId(),
                bill.getPatient().getName(),
                bill.getAppointment().getAppointmentId(),
                bill.getBillAmount(),
                bill.getPaymentStatus(),
                bill.getBillDate()
        );
    }

    // =================================================================================
    // II. CREATE & WRITE OPERATIONS (Bill Modification/Creation)
    // =================================================================================

    /**
     * Creates the initial bill for a newly booked appointment.
     * - Prevents duplicate bills for the same appointment.
     * - Sets initial status as PENDING.
     */
    @Transactional
    public Optional<BillResponseDTO> createInitialBill(Appointment appointment, Doctor doctor) {
        if (billRepository.findByAppointment(appointment).isPresent()) {
            return Optional.empty(); // Bill already exists
        }

        Bill bill = new Bill();
        bill.setAppointment(appointment);
        bill.setPatient(appointment.getPatient());
        bill.setBillAmount(getConsultationFee(doctor)); // Initial fee from doctor
        bill.setBillDate(LocalDate.now());
        bill.setPaymentStatus(PaymentStatus.PENDING);

        Bill savedBill = billRepository.save(bill);
        return Optional.of(mapBillToResponseDTO(savedBill));
    }

    /**
     * Records payment for a bill and marks it as PAID.
     * - If already PAID, no change but still returns the bill DTO.
     */
    @Transactional
    public Optional<BillResponseDTO> recordPayment(Long billId) {
        return billRepository.findById(billId).flatMap(bill -> {
            if (bill.getPaymentStatus() == PaymentStatus.PAID) {
                return Optional.of(mapBillToResponseDTO(bill)); // Already paid
            }

            bill.setPaymentStatus(PaymentStatus.PAID);
            Bill updatedBill = billRepository.save(bill);
            return Optional.of(mapBillToResponseDTO(updatedBill));
        });
    }

    /**
     * Updates the bill when the doctor associated with an appointment changes.
     * - Updates the bill amount to match the new doctor's consultation fee.
     */
    @Transactional
    public Optional<BillResponseDTO> updateBillForDoctorChange(Appointment appointment, Doctor newDoctor) {
        return billRepository.findByAppointment(appointment).flatMap(bill -> {
            BigDecimal newFee = doctorService.getDoctorFee(newDoctor);
            bill.setBillAmount(newFee);
            Bill updatedBill = billRepository.save(bill);
            return Optional.of(mapBillToResponseDTO(updatedBill));
        });
    }

    /**
     * Handles billing when an appointment is cancelled.
     * - Paid bills → REFUNDED
     * - Pending bills → CANCELLED
     * - Already CANCELLED or REFUNDED bills remain unchanged
     */
    @Transactional
    public Optional<BillResponseDTO> cancelBillForAppointment(Appointment appointment) {
        return billRepository.findByAppointment(appointment).flatMap(bill -> {
            if (bill.getPaymentStatus() == PaymentStatus.PAID) {
                bill.setPaymentStatus(PaymentStatus.REFUNDED);
            } else if (bill.getPaymentStatus() == PaymentStatus.PENDING) {
                bill.setPaymentStatus(PaymentStatus.CANCELLED);
            }
            // Do nothing if already CANCELLED or REFUNDED
            Bill updatedBill = billRepository.save(bill);
            return Optional.of(mapBillToResponseDTO(updatedBill));
        });
    }

    // =================================================================================
    // III. READ OPERATIONS (Bill Retrieval)
    // =================================================================================

    /** Returns all bills in the system. */
    @Transactional(readOnly = true)
    public List<BillResponseDTO> getAllBills() {
        return billRepository.findAll().stream()
                .map(this::mapBillToResponseDTO)
                .collect(Collectors.toList());
    }

    /** Retrieves a specific bill by its ID. */
    @Transactional(readOnly = true)
    public Optional<BillResponseDTO> getBillById(Long billId) {
        return billRepository.findById(billId).map(this::mapBillToResponseDTO);
    }

    /** Retrieves the bill associated with a specific appointment. */
    @Transactional(readOnly = true)
    public Optional<BillResponseDTO> getBillByAppointmentId(Long appointmentId) {
        return billRepository.findByAppointment_AppointmentId(appointmentId)
                .map(this::mapBillToResponseDTO);
    }

    /** Retrieves all bills for a specific patient, newest first. */
    @Transactional(readOnly = true)
    public List<BillResponseDTO> getBillsByPatient(Long patientId) {
        return billRepository.findByPatientPatientIdOrderByBillDateDesc(patientId).stream()
                .map(this::mapBillToResponseDTO)
                .collect(Collectors.toList());
    }

    /** Retrieves bills filtered by payment status (PENDING, PAID, CANCELLED, REFUNDED). */
    @Transactional(readOnly = true)
    public List<BillResponseDTO> getBillsByStatus(PaymentStatus status) {
        return billRepository.findByPaymentStatus(status).stream()
                .map(this::mapBillToResponseDTO)
                .collect(Collectors.toList());
    }

    /** Returns the total count of bills in the system. */
    public Long getCount() {
        return billRepository.count();
    }
}
