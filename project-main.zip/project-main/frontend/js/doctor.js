var base_url = 'http://localhost:8085/api';
$.ajaxSetup({ xhrFields: { withCredentials: true } });

// --- Helper Functions for Formatting ---

/** Formats ISO date string to 'MMM DD, YYYY'. Returns '-' if invalid. */
function formatDate(dateString) {
  if (!dateString) return '-';
  try {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch (e) {
    return dateString.split('T')[0] || '-';
  }
}

/** Returns a hyperlink to patient_details.html with patientId. */
function createPatientLink(patientId, patientName) {
  return `<a href="patient_details.html?patientId=${patientId}" class="text-primary">${
    patientName || 'N/A'
  }</a>`;
}

// --- Event Handler: Doctor Entity Ready (for app.js dispatcher) ---

$(document).on('doctorEntityReady', function (evt, data) {
  try {
    if (!data) return;

    // Render doctor profile info if container exists
    if ($('#doctorInfo').length) {
      $('#doctorInfo').html(
        '<b>Name:</b> ' +
          data.name +
          '<br><b>Specialization:</b> ' +
          data.specialization +
          '<br><b>Contact:</b> ' +
          data.contactNumber +
          '<br><b>Fee:</b> ' +
          data.consultationFee
      );
    }

    // Load all appointments if relevant tables exist
    if (
      $('#appointmentsTable').length ||
      $('#upcomingAppointments').length ||
      $('#pastAppointments').length
    ) {
      loadDoctorAppointments(data.doctorId);
    }

    // Load patient details if on patient_details.html
    if ($('#patientDetails').length) {
      const params = new URLSearchParams(window.location.search);
      const pid = params.get('patientId');
      if (pid) {
        $.get(`${base_url}/patients/${pid}`)
          .done(function (patient) {
            $('#patientDetails').html(
              '<b>Name:</b> ' +
                patient.name +
                '<br><b>DOB:</b> ' +
                patient.dob +
                '<br><b>Gender:</b> ' +
                patient.gender +
                '<br><b>Contact:</b> ' +
                patient.contactNumber +
                '<br><b>Address:</b> ' +
                patient.address +
                '<br><b>History:</b> ' +
                patient.medicalHistory
            );
          })
          .fail(function (xhr) {
            console.error('Failed to load patient details', xhr);
            $('#patientDetails').html(
              '<div class="text-danger">Failed to load patient details</div>'
            );
          });
      }
    }
  } catch (e) {
    console.error('Error handling doctorEntityReady', e);
  }
});

// --- Function to Load and Render Appointments ---

function loadDoctorAppointments(doctorId) {
  // Fetch appointments for the doctor
  $.get(`${base_url}/appointments/doctor/${doctorId}`)
    .done(function (list) {
      ensureUpdateModal(); // Make sure the modal exists

      // Prepare tables
      const upcomingTbl = $('#upcomingAppointments');
      const pastTbl = $('#pastAppointments');
      const mainTbl = $('#appointmentsTable');

      const upBody = upcomingTbl.find('tbody').empty();
      const pastBody = pastTbl.find('tbody').empty();
      const mainBody = mainTbl.find('tbody').empty();

      // Sort appointments by date ascending
      list.sort(
        (a, b) => new Date(a.appointmentDate) - new Date(b.appointmentDate)
      );

      list.forEach(function (a) {
        // Categorize appointments
        const isUpcomingStatus =
          a.status === 'CONFIRMED' || a.status === 'SCHEDULED';
        const isPastStatus =
          a.status === 'COMPLETED' || a.status === 'CANCELLED';

        const patientLink = createPatientLink(a.patientId, a.patientName);

        // Common cells
        const dateCell = $('<td>').text(formatDate(a.appointmentDate));
        const timeCell = $('<td>').text(a.timeSlot || '-');
        const patientCell = $('<td>').html(patientLink);
        const reasonCell = $('<td>').text(a.reason || 'N/A');
        const statusCell = $('<td>').text(a.status || '-');

        // --- Render Upcoming Appointments ---
        if (isUpcomingStatus) {
          // Dashboard (5 columns)
          if (mainTbl.length) {
            const row = $('<tr>');
            row.append(
              dateCell.clone(),
              timeCell.clone(),
              patientCell.clone(),
              reasonCell.clone(),
              statusCell.clone()
            );
            mainBody.append(row);
          }

          // Upcoming appointments page (6 columns + action)
          if (upcomingTbl.length) {
            const row = $('<tr>');
            row.append(
              dateCell.clone(),
              timeCell.clone(),
              patientCell.clone(),
              reasonCell.clone(),
              statusCell.clone()
            );

            // Action cell with update button
            const actionCell = $('<td>');
            const btn = $('<button>')
              .addClass('btn btn-sm btn-success update-appointment')
              .attr({
                'data-id': a.appointmentId,
                'data-remarks': a.remarks || '',
              })
              .text('Complete');
            actionCell.append(btn);
            row.append(actionCell);
            upBody.append(row);
          }
        }

        // --- Render Past Appointments ---
        else if (isPastStatus && pastTbl.length) {
          const row = $('<tr>');
          row.append(
            dateCell.clone(),
            timeCell.clone(),
            patientCell.clone(),
            reasonCell.clone(),
            statusCell.clone()
          );
          // Remarks column
          row.append($('<td>').text(a.remarks || '—'));
          pastBody.append(row);
        }
      });

      // Fallback row if no appointments
      const noDataRow = (cols) =>
        `<tr><td colspan="${cols}" class="text-center py-4 text-gray-400">No appointments.</td></tr>`;

      if (mainTbl.length && mainBody.is(':empty')) mainBody.html(noDataRow(5));
      if (upcomingTbl.length && upBody.is(':empty')) upBody.html(noDataRow(6));
      if (pastTbl.length && pastBody.is(':empty')) pastBody.html(noDataRow(6));

      // Event delegation for update buttons -> open modal
      $(document)
        .off('click', '.update-appointment')
        .on('click', '.update-appointment', function () {
          const id = $(this).data('id');
          const remarks = $(this).data('remarks') || '';

          $('#updateAppointmentModal').data('appointment-id', id);
          $('#updateStatus').val('COMPLETED').prop('disabled', true);
          $('#updateRemarks').val(remarks);
          $('#updateAppointmentModal').modal('show');
        });
    })
    .fail(function (xhr) {
      console.error('Failed to load appointments', xhr);
      const errMsg =
        '<tr><td colspan="6" class="text-danger text-center">ERROR: Failed to load data.</td></tr>';
      $(
        '#upcomingAppointments tbody, #pastAppointments tbody, #appointmentsTable tbody'
      ).html(errMsg);
    });
}

// --- Modal Creation and Save Handler ---
function ensureUpdateModal() {
  if ($('#updateAppointmentModal').length) return;

  const modal = `
    <div class="modal fade" id="updateAppointmentModal" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Complete Appointment and Add Remarks</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
            <div class="form-group">
                <label for="updateStatus">Status</label>
                <input type="text" id="updateStatus" class="form-control" value="COMPLETED" disabled>
            </div>
            <div class="form-group">
              <label for="updateRemarks">Remarks/Consultation Notes</label>
              <textarea id="updateRemarks" class="form-control" rows="3" placeholder="Enter consultation findings, diagnosis, and next steps..."></textarea>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-success" id="saveUpdateBtn">Save Notes & Complete Appointment</button>
          </div>
        </div>
      </div>
    </div>`;
  $('body').append(modal);

  // Save handler
  $(document)
    .off('click', '#saveUpdateBtn')
    .on('click', '#saveUpdateBtn', function () {
      const id = $('#updateAppointmentModal').data('appointment-id');
      const status = 'COMPLETED';
      const remarks = $('#updateRemarks').val().trim();

      if (remarks.length < 5) {
        window.alert(
          'Please provide detailed remarks (at least 5 characters) before completing the appointment.'
        );
        return;
      }

      $.ajax({
        url: `${base_url}/appointments/${id}/status?status=${status}&remarks=${encodeURIComponent(
          remarks
        )}`,
        method: 'PUT',
      })
        .done(function () {
          $('#updateAppointmentModal').modal('hide');
          location.reload();
        })
        .fail(function (xhr) {
          window.alert(
            'Failed to update appointment: ' +
              (xhr.responseJSON?.message || 'Unknown error')
          );
          console.error('Update appointment failed', xhr);
        });
    });
}

// --- Legacy App.js Compatibility ---
window.loadDoctorPageLogic = function (data) {
  if ($('#doctorInfo').length) {
    $('#doctorInfo').html(
      '<b>Name:</b> ' +
        data.name +
        '<br><b>Specialization:</b> ' +
        data.specialization +
        '<br><b>Contact:</b> ' +
        data.contactNumber +
        '<br><b>Fee:</b> ' +
        data.consultationFee
    );
  }
  if (
    $('#appointmentsTable').length ||
    $('#upcomingAppointments').length ||
    $('#pastAppointments').length
  ) {
    loadDoctorAppointments(data.doctorId);
  }
  if ($('#patientDetails').length) {
    let params = new URLSearchParams(window.location.search);
    let pid = params.get('patientId');
    if (pid) {
      $.get(`${base_url}/patients/${pid}`)
        .done(function (data) {
          $('#patientDetails').html(
            '<b>Name:</b> ' +
              data.name +
              '<br><b>DOB:</b> ' +
              data.dob +
              '<br><b>Gender:</b> ' +
              data.gender +
              '<br><b>Contact:</b> ' +
              data.contactNumber +
              '<br><b>Address:</b> ' +
              data.address +
              '<br><b>History:</b> ' +
              data.medicalHistory
          );
        })
        .fail(function (xhr) {
          console.error('Failed to load patient details', xhr);
          $('#patientDetails').html(
            '<div class="text-danger">Failed to load patient details</div>'
          );
        });
    }
  }
};

// --- Standalone Page Initialization ---
$(document).ready(function () {
  const tokenUser = JSON.parse(localStorage.getItem('user'));
  if (!tokenUser) {
    window.location.href = '/login.html';
  } else if (tokenUser.role !== 'DOCTOR') {
    window.location.href = '/error.html';
  }

  if (typeof window.loadDoctorPageLogic === 'undefined') {
    $.get(`${base_url}/doctors/me`)
      .done(function (doctor) {
        $(document).trigger('doctorEntityReady', doctor);
      })
      .fail(function () {
        /* silent fail */
      });
  }
});
