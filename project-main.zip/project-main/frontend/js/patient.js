function showToast(message, type = 'info') {
  let container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container position-fixed top-0 end-0 p-3';
    document.body.appendChild(container);
  }

  const bgClass =
    {
      success: 'bg-success text-white',
      error: 'bg-danger text-white',
      info: 'bg-info text-white',
      warning: 'bg-warning text-dark',
    }[type] || 'bg-secondary text-white';

  const toast = document.createElement('div');
  toast.className = `toast align-items-center ${bgClass}`;
  toast.setAttribute('role', 'alert');
  toast.setAttribute('aria-live', 'assertive');
  toast.setAttribute('aria-atomic', 'true');
  toast.innerHTML = `
    <div class="d-flex">
      <div class="toast-body">${message}</div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
  `;

  container.appendChild(toast);
  const bsToast = new bootstrap.Toast(toast, { delay: 3500 });
  bsToast.show();
  toast.addEventListener('hidden.bs.toast', () => toast.remove());
}

// ================================================================
// Core Patient Page Logic (Handles Profile, Billing, Appointments)
// ================================================================

var base_url = 'http://localhost:8085/api';
$.ajaxSetup({ xhrFields: { withCredentials: true } });

const loadPatientPageLogic = (patientData) => {
  const patientId = patientData.patientId;
  const data = patientData;

  // ================================================================
  // 1. PROFILE SECTION: Display & Edit Patient Information
  // ================================================================

  if ($('#patientInfo').length) {
    const infoHtml = $('<div>')
      .append(
        $('<p>')
          .append('<b>Name: </b>')
          .append($('<span>').text(data.name || '-'))
      )
      .append(
        $('<p>')
          .append('<b>DOB: </b>')
          .append($('<span>').text(data.dob || '-'))
      )
      .append(
        $('<p>')
          .append('<b>Gender: </b>')
          .append($('<span>').text(data.gender || '-'))
      )
      .append(
        $('<p>')
          .append('<b>Contact: </b>')
          .append($('<span>').text(data.contactNumber || '-'))
      )
      .append(
        $('<p>')
          .append('<b>Address: </b>')
          .append($('<span>').text(data.address || '-'))
      )
      .append(
        $('<p>')
          .append('<b>Medical History: </b>')
          .append($('<span>').text(data.medicalHistory || '-'))
      );
    $('#patientInfo').empty().append(infoHtml);
  }

  if ($('#name').length) {
    $('#name').val(data.name || '');
    $('#dob').val(data.dob || '');
    $('#gender').val(data.gender || '');
    $('#contactNumber').val(data.contactNumber || '');
    $('#address').val(data.address || '');
    $('#medicalHistory').val(data.medicalHistory || '');
  }

  // ================================================================
  // 2. PENDING PAYMENTS: Display unpaid bills
  // ================================================================

  const getTBody = (tableId) => {
    const $table = $(`#${tableId}`);
    let $tbody = $table.find('tbody');
    if ($tbody.length === 0) {
      $tbody = $('<tbody>');
      $table.append($tbody);
    }
    return $tbody;
  };

  const loadPendingPayments = () => {
    const pendingBody = getTBody('pendingPaymentsTable');
    if (!pendingBody.length) return;

    $.get(`${base_url}/bills/patient/${patientId}`)
      .done(function (list) {
        pendingBody.empty();
        const colspan = 4;

        if (!Array.isArray(list) || list.length === 0) {
          pendingBody.append(
            `<tr><td colspan="${colspan}" class="text-muted text-center p-4">No pending payments!</td></tr>`
          );
          return;
        }

        list.forEach(function (bill) {
          if (bill.paymentStatus !== 'PENDING') return;
          const row = $('<tr>').addClass('table-danger');

          row.append(
            $('<td>')
              .addClass('text-nowrap')
              .text(bill.billDate || '-')
          );
          row.append($('<td>').text(bill.description || 'Medical Service Fee'));
          row.append(
            $('<td>')
              .addClass('text-right font-weight-bold')
              .text(`Rs. ${(bill.billAmount || 0).toFixed(2)}`)
          );

          const actionCell = $('<td>').addClass('text-center');
          actionCell.append(
            $('<a>')
              .addClass('btn btn-sm btn-warning')
              .attr('href', `billing.html?billId=${bill.billId}`)
              .html('<i class="fas fa-credit-card mr-1"></i> Pay Now')
          );
          row.append(actionCell);
          pendingBody.append(row);
        });
      })
      .fail(function () {
        pendingBody
          .empty()
          .append(
            '<tr><td colspan="4" class="text-danger text-center p-4">Failed to load payments.</td></tr>'
          );
        showToast('Failed to load pending payments', 'error');
      });
  };
  loadPendingPayments();

  // ================================================================
  // 3. APPOINTMENTS SECTION: Upcoming & Completed Appointments
  // ================================================================

  if ($('#upcomingAppointments').length || $('#completedAppointments').length) {
    $.get(`${base_url}/appointments/patient/${patientId}`)
      .done(function (list) {
        const upcomingBody = getTBody('upcomingAppointments');
        const completedBody = getTBody('completedAppointments');
        upcomingBody.empty();
        completedBody.empty();

        if (!Array.isArray(list) || list.length === 0) {
          upcomingBody.append(
            '<tr><td colspan="5" class="text-muted text-center p-4">No upcoming appointments</td></tr>'
          );
          completedBody.append(
            '<tr><td colspan="5" class="text-muted text-center p-4">No past appointments</td></tr>'
          );
          return;
        }

        list.forEach(function (a) {
          const row = $('<tr>');
          const statusBadge = `<span class="badge-status status-${(
            a.status || 'DEFAULT'
          ).toUpperCase()}">${a.status || '-'}</span>`;
          row.append(
            $('<td>')
              .addClass('text-nowrap')
              .text(a.appointmentDate || '-')
          );
          row.append(
            $('<td>')
              .addClass('text-nowrap')
              .text(a.timeSlot || '-')
          );
          row.append($('<td>').text(a.doctorName || '-'));
          row.append($('<td>').addClass('text-center').html(statusBadge));

          if (a.status === 'COMPLETED' || a.status === 'CANCELLED') {
            row.append(
              $('<td>').text(
                a.remarks || (a.status === 'CANCELLED' ? 'Cancelled' : '-')
              )
            );
            completedBody.append(row);
          } else {
            const actionCell = $('<td>').addClass('text-center');
            const apptDate = a.appointmentDate
              ? new Date(a.appointmentDate)
              : null;
            const now = new Date();

            if (
              apptDate &&
              apptDate.setHours(0, 0, 0, 0) >= now.setHours(0, 0, 0, 0)
            ) {
              actionCell.append(
                $('<button>')
                  .addClass('btn btn-sm btn-info edit-appointment me-2')
                  .attr('data-id', a.appointmentId)
                  .text('Edit')
              );
              actionCell.append(
                $('<button>')
                  .addClass('btn btn-sm btn-danger cancel-appointment')
                  .attr('data-id', a.appointmentId)
                  .text('Cancel')
              );
            } else {
              actionCell.text('-');
            }
            row.append(actionCell);
            upcomingBody.append(row);
          }
        });
      })
      .fail(function () {
        showToast('Failed to load appointments.', 'error');
      });
  }

  // ================================================================
  // 4. EVENT HANDLERS: Edit & Cancel Appointment Logic
  // ================================================================

  $(document)
    .off('click', '.edit-appointment')
    .on('click', '.edit-appointment', function () {
      window.location =
        'book_appointment.html?appointmentId=' + $(this).data('id');
    });

  $(document)
    .off('click', '.cancel-appointment')
    .on('click', '.cancel-appointment', function () {
      $('#confirmCancelButton').data('id', $(this).data('id'));
      $('#cancelConfirmModal').modal('show');
    });

  $('#confirmCancelButton')
    .off('click')
    .on('click', function () {
      const id = $(this).data('id');
      const $button = $(this);
      $button
        .prop('disabled', true)
        .html('<i class="fas fa-spinner fa-spin mr-2"></i> Cancelling...');

      $.ajax({ url: `${base_url}/appointments/${id}/cancel`, method: 'PUT' })
        .done(function () {
          $('#cancelConfirmModal').modal('hide');
          showToast('Appointment cancelled successfully', 'success');
          location.reload();
        })
        .fail(function () {
          $('#cancelConfirmModal').modal('hide');
          showToast('Failed to cancel appointment', 'error');
          $button.prop('disabled', false).text('Confirm Cancel');
        });
    });

  // ================================================================
  // 5. BILLING PAGE: Loads and displays all patient bills
  // ================================================================

  function renderStatusBadge(status) {
    const displayStatus = status || 'N/A';
    const statusClass = 'status-' + displayStatus.toUpperCase();
    return $('<span>')
      .addClass('badge-status')
      .addClass(statusClass)
      .text(displayStatus);
  }

  if ($('#billsTable').length) {
    $.get(`${base_url}/bills/patient/${patientId}`)
      .done(function (bills) {
        const tbody = $('#billsTable tbody');
        tbody.empty();

        if (!Array.isArray(bills) || bills.length === 0) {
          tbody.append(
            '<tr><td colspan="6" class="text-center text-muted p-4">No bills found.</td></tr>'
          );
          return;
        }

        bills.sort((a, b) => {
          if (a.paymentStatus === 'PENDING' && b.paymentStatus !== 'PENDING')
            return -1;
          if (a.paymentStatus !== 'PENDING' && b.paymentStatus === 'PENDING')
            return 1;
          return new Date(b.billDate) - new Date(a.billDate);
        });

        bills.forEach(function (b) {
          const row = $('<tr>');
          if (b.paymentStatus === 'PENDING') row.addClass('table-warning');
          row.append($('<td>').text(b.billId));
          row.append($('<td>').text(b.appointmentId));
          row.append($('<td>').text(b.billDate));
          row.append($('<td>').text(`Rs. ${b.billAmount.toFixed(2)}`));
          row.append($('<td>').append(renderStatusBadge(b.paymentStatus)));

          const actionCell = $('<td>');
          if (b.paymentStatus === 'PENDING') {
            actionCell.append(
              $('<button>')
                .addClass('btn btn-sm btn-pay pay-bill')
                .attr('data-id', b.billId)
                .attr('data-amount', b.billAmount.toFixed(2))
                .text('Pay')
            );
          } else {
            actionCell.text('-');
          }
          row.append(actionCell);
          tbody.append(row);
        });
      })
      .fail(function () {
        showToast('Failed to load bills.', 'error');
      });
  }

  // ================================================================
  // 6. PAYMENT MODAL: Trigger payment flow
  // ================================================================

  $(document)
    .off('click', '.pay-bill')
    .on('click', '.pay-bill', function () {
      const billId = $(this).data('id');
      const billAmount = $(this).data('amount');
      $('#confirmPayButton').data('id', billId);
      $('#billIdDisplay').text(billId);
      $('#billAmountDisplay').text(`Rs. ${billAmount}`);
      $('#payConfirmModal').modal('show');
    });

  $(document)
    .off('click', '#confirmPayButton')
    .on('click', '#confirmPayButton', function () {
      const id = $(this).data('id');
      $('#payConfirmModal').modal('hide');
      $.ajax({ url: `${base_url}/bills/${id}/pay`, method: 'PUT' })
        .done(function () {
          showToast('Payment successful', 'success');
          location.reload();
        })
        .fail(function () {
          showToast('Payment failed. Please try again.', 'error');
          location.reload();
        });
    });

  // ================================================================
  // 7. BOOKING PAGE: Logic for booking or rescheduling appointments
  // ================================================================

  if ($('#bookForm').length) {
    let selectedDoctor = null;
    let availableDays = [];
    let doctorMap = {};
    let selectedSlot = null;
    const dayMap = [
      'SUNDAY',
      'MONDAY',
      'TUESDAY',
      'WEDNESDAY',
      'THURSDAY',
      'FRIDAY',
      'SATURDAY',
    ];

    function setupDatePicker() {
      $('#appointmentDate').datepicker('destroy');
      $('#appointmentDate').datepicker({
        format: 'yyyy-mm-dd',
        startDate: new Date(),
        autoclose: true,
        todayHighlight: true,
        beforeShowDay: function (date) {
          const dayName = dayMap[date.getDay()];
          return availableDays.includes(dayName)
            ? { enabled: true, classes: 'available-day' }
            : { enabled: false, classes: 'disabled-day' };
        },
      });

      $('#appointmentDate')
        .off('changeDate')
        .on('changeDate', function (e) {
          const date = e.format('yyyy-mm-dd');
          const dayOfWeek = dayMap[new Date(date).getDay()];
          if (!availableDays.includes(dayOfWeek)) return;

          $.get(
            `${base_url}/appointments/slots/${selectedDoctor}?date=${date}`,
            function (slots) {
              let html = '';
              slots.forEach(function (s) {
                html += `<button type="button" class="btn btn-outline-primary slot-btn m-1" data-slot="${s}">${s}</button>`;
              });
              $('#timeSlot').html(html);

              $('#timeSlot')
                .off('click', '.slot-btn')
                .on('click', '.slot-btn', function () {
                  $('.slot-btn').removeClass('active');
                  $(this).addClass('active');
                  selectedSlot = $(this).data('slot');
                });
            }
          );
        });
    }

    $('#searchDoctorBtn').click(function () {
      const keyword = $('#doctorSearch').val();
      $.get(`${base_url}/doctors?keyword=${keyword}`, function (doctors) {
        const doctorList = $('#doctorList');
        doctorList.empty();
        doctorMap = {};

        doctors.forEach(function (d) {
          doctorMap[d.doctorId] = d;
          const fee = d.consultationFee != null ? `₹${d.consultationFee}` : '—';
          const card = $('<div>')
            .addClass('doctor-card p-3 mb-2 border rounded')
            .attr('data-doctor-id', d.doctorId);
          const header = $('<div>').addClass(
            'd-flex justify-content-between align-items-center'
          );
          const info = $('<div>');
          info.append($('<h5>').addClass('mb-1').text(d.name));
          info.append(
            $('<small>')
              .addClass('text-muted')
              .text(`${d.specialization} • Fee: ${fee}`)
          );
          const radioContainer = $('<div>').append(
            $('<input>').attr({
              type: 'radio',
              name: 'doctor',
              value: d.doctorId,
            })
          );
          header.append(info).append(radioContainer);
          card.append(header);
          if (d.availabilities && d.availabilities.length) {
            const days = d.availabilities.map((a) => a.dayOfWeek).join(', ');
            card.append(
              $('<div>').addClass('mt-2 text-muted').text(`Available: ${days}`)
            );
          }
          doctorList.append(card);
        });

        // Event: when doctor is selected, show appointment options
        doctorList
          .off('change', 'input[name="doctor"]')
          .on('change', 'input[name="doctor"]', function () {
            const newDoctorId = $(this).val();
            if (selectedDoctor && newDoctorId !== selectedDoctor) {
                $('#appointmentDate').val('');
                $('#timeSlot').empty();
            }

            selectedDoctor = newDoctorId;
            const doctor = doctorMap[selectedDoctor];
            availableDays = (doctor.availabilities || []).map(
              (a) => a.dayOfWeek
            );
            $('#appointmentDetails').show();
            setupDatePicker();
          });

        // Allow clicking the card (not just radio) to select the doctor
        doctorList
          .off('click', '.doctor-card')
          .on('click', '.doctor-card', function () {
            const radio = $(this).find('input[name="doctor"]');
            radio.prop('checked', true).trigger('change');
          });
      });
    });

    // Handle form submission for booking or rescheduling
    $('#bookForm').submit(function (e) {
      e.preventDefault();
      const params = new URLSearchParams(window.location.search);
      const appointId = params.get('appointmentId');
      const data = {
        patientId: patientId,
        doctorId: selectedDoctor,
        appointmentDate: $('#appointmentDate').val(),
        timeSlot: selectedSlot,
        reason: $('#reason').val(),
      };

      if (!selectedDoctor || !data.appointmentDate || !data.timeSlot) {
        showToast('Please select doctor, date, and time slot.', 'warning');
        return;
      }

      const request = appointId
        ? {
            url: `${base_url}/appointments/${appointId}/reschedule`,
            method: 'PUT',
          }
        : { url: `${base_url}/appointments`, method: 'POST' };

      $.ajax({
        ...request,
        contentType: 'application/json',
        data: JSON.stringify(data),
      })
        .done(function () {
          showToast('Appointment saved successfully!', 'success');
          window.location = 'appointments.html';
        })
        .fail(function () {
          showToast('Failed to save appointment.', 'error');
        });
    });

    // Reschedule mode: prefill data when editing an existing appointment
    const params = new URLSearchParams(window.location.search);
    if (params.get('appointmentId')) {
      const id = params.get('appointmentId');
      $.get(`${base_url}/appointments/${id}`, function (a) {
        selectedDoctor = a.doctorId;
        $('#doctorList').html('');
        $('#appointmentDetails').show();
        $('#reason').val(a.reason);

        // Helper: loads doctor's available days and UI
        const loadDoctorAvailability = function (doctor) {
          availableDays = (doctor.availabilities || []).map(
            (av) => av.dayOfWeek
          );
          const fee =
            doctor.consultationFee != null ? `₹${doctor.consultationFee}` : '—';

          const card = $('<div>')
            .addClass('doctor-card p-3 mb-2 border rounded')
            .attr('data-doctor-id', doctor.doctorId);
          const header = $('<div>').addClass(
            'd-flex justify-content-between align-items-center'
          );
          const info = $('<div>');
          info.append($('<h5>').addClass('mb-1').text(doctor.name));
          info.append(
            $('<small>')
              .addClass('text-muted')
              .text(`${doctor.specialization} • Fee: ${fee}`)
          );
          const radioContainer = $('<div>').append(
            $('<input>').attr({
              type: 'radio',
              name: 'doctor',
              value: doctor.doctorId,
              checked: true,
            })
          );
          header.append(info).append(radioContainer);
          card.append(header);

          if (doctor.availabilities && doctor.availabilities.length) {
            const days = doctor.availabilities
              .map((av) => av.dayOfWeek)
              .join(', ');
            card.append(
              $('<div>').addClass('mt-2 text-muted').text(`Available: ${days}`)
            );
          }
          $('#doctorList').empty().append(card);

          setupDatePicker();
          $('#appointmentDate').datepicker('setDate', a.appointmentDate);

          // Load time slots for the preselected doctor/date
          $.get(
            `${base_url}/appointments/slots/${a.doctorId}?date=${a.appointmentDate}`,
            function (slots) {
              let html = '';
              slots.forEach(function (s) {
                const activeClass = s === a.timeSlot ? 'active' : '';
                html += `<button type="button" class="btn btn-outline-primary slot-btn m-1 ${activeClass}" data-slot="${s}">${s}</button>`;
              });
              $('#timeSlot').html(html);
              selectedSlot = a.timeSlot;
            }
          );
        };

        // Load doctor info for reschedule mode
        if (doctorMap[selectedDoctor]) {
          loadDoctorAvailability(doctorMap[selectedDoctor]);
        } else {
          $.get(`${base_url}/doctors/${selectedDoctor}`, function (doctor) {
            doctorMap[doctor.doctorId] = doctor;
            loadDoctorAvailability(doctor);
          });
        }
      });
    }
  }
  // ================================================================
  // 8. PAGE INITIALIZATION & PROFILE UPDATE HANDLING
  // ================================================================
  // This section runs after the DOM is ready.
  // It validates the logged-in user, fetches their profile if needed,
  // and manages the Edit Profile form submission.

  window.loadPatientPageLogic = function (data) {
    // Store loaded patient data globally for later use
    window._patientEntity = data || null;
  };

  $(document).ready(function () {
    // Check login session
    const tokenUser = JSON.parse(localStorage.getItem('user'));
    if (!tokenUser) {
      showToast('Please log in first.', 'warning');
      window.location.href = '/login.html';
      return;
    } else if (tokenUser.role !== 'PATIENT') {
      showToast('Access denied. Patient account required.', 'error');
      window.location.href = '/error.html';
      return;
    }

    let patientId = null;
    const pre = window._patientEntity;

    // If patient data is already available, use it
    if (pre) {
      patientId = pre.patientId;
      if ($('#patientInfo').length) {
        $('#patientInfo').html(
          'Name: ' +
            (pre.name || '-') +
            '<br>DOB: ' +
            (pre.dob || '-') +
            '<br>Gender: ' +
            (pre.gender || '-') +
            '<br>Contact: ' +
            (pre.contactNumber || '-') +
            '<br>Address: ' +
            (pre.address || '-')
        );
      }
      if ($('#name').length) {
        $('#name').val(pre.name || '');
        $('#dob').val(pre.dob || '');
        $('#gender').val(pre.gender || '');
        $('#contactNumber').val(pre.contactNumber || '');
        $('#address').val(pre.address || '');
        $('#medicalHistory').val(pre.medicalHistory || '');
      }
    } else {
      // Otherwise, fetch current patient's details from API
      $.get(`${base_url}/patients/me`, function (data) {
        window._patientEntity = data;
        patientId = data.patientId;
        if ($('#patientInfo').length) {
          $('#patientInfo').html(
            'Name: ' +
              (data.name || '-') +
              '<br>DOB: ' +
              (data.dob || '-') +
              '<br>Gender: ' +
              (data.gender || '-') +
              '<br>Contact: ' +
              (data.contactNumber || '-') +
              '<br>Address: ' +
              (data.address || '-')
          );
        }
        if ($('#name').length) {
          $('#name').val(data.name || '');
          $('#dob').val(data.dob || '');
          $('#gender').val(data.gender || '');
          $('#contactNumber').val(data.contactNumber || '');
          $('#address').val(data.address || '');
          $('#medicalHistory').val(data.medicalHistory || '');
        }
      }).fail(function () {
        showToast('Could not load patient profile.', 'error');
      });
    }

    // ================================================================
    // Edit Profile Form Submission
    // ================================================================
    // Handles the update request for patient information.

    $(document)
      .off('submit', '#editProfileForm')
      .on('submit', '#editProfileForm', function (e) {
        e.preventDefault();

        const payload = {
          name: $('#name').val(),
          dob: $('#dob').val(),
          gender: $('#gender').val(),
          contactNumber: $('#contactNumber').val(),
          address: $('#address').val(),
          medicalHistory: $('#medicalHistory').val(),
        };

        $.ajax({
          url: `${base_url}/patients/me`,
          method: 'PUT',
          contentType: 'application/json',
          data: JSON.stringify(payload),
        })
          .done(function (resp) {
            showToast('Profile updated successfully!', 'success');

            if ($('#patientInfo').length) {
              $('#patientInfo').html(
                'Name: ' +
                  (payload.name || '-') +
                  '<br>DOB: ' +
                  (payload.dob || '-') +
                  '<br>Gender: ' +
                  (payload.gender || '-') +
                  '<br>Contact: ' +
                  (payload.contactNumber || '-') +
                  '<br>Address: ' +
                  (payload.address || '-')
              );
            }

            window._patientEntity = resp || {
              ...window._patientEntity,
              ...payload,
            };
            if (resp && resp.patientId) patientId = resp.patientId;

            // Redirect to dashboard after successful update
            setTimeout(() => {
              window.location = '/patient/dashboard.html';
            }, 1200);
          })
          .fail(function () {
            showToast('Failed to update profile.', 'error');
          });
      });
  });
};
