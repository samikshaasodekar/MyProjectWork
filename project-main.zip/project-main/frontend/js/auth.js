var base_url = 'http://localhost:8085/api';
$.ajaxSetup({ xhrFields: { withCredentials: true } });

const endpoints = {
    login: `${base_url}/users/login`,
    register: `${base_url}/users/register`,
    changePassword: `${base_url}/users/change-password`,
    logout: `${base_url}/users/logout`,
};

function showFormMessage(messageId, message, type = 'error', duration = 0) {
    const $messageArea = $(messageId);
    
    // 1. Clear any existing content and remove old classes
    $messageArea.removeClass('success error').hide().empty();

    // 2. Set new content and class
    $messageArea.text(message).addClass(type).fadeIn(300);

    // 3. Set a timeout to clear the message if a duration is specified
    if (duration > 0) {
        setTimeout(() => {
            $messageArea.fadeOut(300, function() {
                $(this).empty().removeClass('success error');
            });
        }, duration);
    }
}

function clearFormMessage(messageId) {
    $(messageId).fadeOut(300, function() {
        $(this).empty().removeClass('success error');
    });
}

$(document).ready(function () {
    // -------------------------
    // LOGIN FORM
    // -------------------------
    $('#loginForm').submit(function (e) {
        e.preventDefault();
        clearFormMessage('#login-message'); // Clear previous messages
        
        const loginData = {
            email: $('#email').val(),
            password: $('#password').val(),
        };

        // Authenticate user and redirect based on role
        $.ajax({
            url: endpoints.login,
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(loginData),
            xhrFields: { withCredentials: true },
            success: function (res) {
                localStorage.setItem('user', JSON.stringify(res));

                // Display success message briefly before redirecting
                showFormMessage('#login-message', 'Login successful! Redirecting...', 'success', 1000);
                
                // Redirect user according to their role after a slight delay
                setTimeout(() => {
                    if (res.role === 'PATIENT') window.location = '/patient/dashboard.html';
                    else if (res.role === 'DOCTOR')
                        window.location = '/doctor/dashboard.html';
                    else if (res.role === 'ADMIN')
                        window.location = '/admin/dashboard.html';
                }, 1200);
            },
            error: function (xhr) {
                // Display backend error or fallback message
                const errorMessage = xhr.responseJSON?.message || 'Login failed. Please check your credentials.';
                showFormMessage('#login-message', errorMessage, 'error');
            },
        });
    });

    // -------------------------
    // REGISTER FORM
    // -------------------------
    $('#registerForm').submit(function (e) {
        e.preventDefault();
        clearFormMessage('#register-message'); // Clear previous messages

        const regData = {
            email: $('#email').val(),
            password: $('#password').val(),
            name: $('#name').val(),
            dob: $('#dob').val(),
            gender: $('#gender').val(),
            contactNumber: $('#contactNumber').val(),
            address: $('#address').val(),
            medicalHistory: $('#medicalHistory').val(),
        };

        $.ajax({
            url: endpoints.register,
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(regData),
            xhrFields: { withCredentials: true },
            success: function () {
                // Replaced alert
                showFormMessage('#register-message', 'Registered successfully. Redirecting to login...', 'success', 1500);
                setTimeout(() => {
                    window.location = '/login.html';
                }, 1700);
            },
            error: function (xhr) {
                // Replaced alert
                const errorMessage = xhr.responseJSON?.message || 'Registration failed. Please check your details.';
                showFormMessage('#register-message', errorMessage, 'error');
            },
        });
    });

    // -------------------------
    // CHANGE PASSWORD FORM
    // -------------------------
    $('#changePasswordForm').submit(function (e) {
        e.preventDefault();
        clearFormMessage('#change-password-message'); // Clear previous messages

        const newPass = $('#newPassword').val();

        // Client-side validation: passwords must match
        if (newPass !== $('#confirmNewPassword').val()) {
            // Replaced alert
            showFormMessage('#change-password-message', 'New passwords do not match.', 'error');
            return;
        }

        const passData = {
            currentPassword: $('#currentPassword').val(),
            newPassword: newPass,
            confirmNewPassword: $('#confirmNewPassword').val(),
        };

        $.ajax({
            url: endpoints.changePassword,
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(passData),
            xhrFields: { withCredentials: true },
            success: function (res) {
                // Replaced alert
                const successMessage = res || 'Password changed successfully. Logging out...';
                showFormMessage('#change-password-message', successMessage, 'success', 1500);
                
                localStorage.removeItem('user'); // Clear local session
                
                setTimeout(() => {
                    window.location = '/login.html';
                }, 1700);
            },
            error: function (xhr) {
                // Replaced alert
                const errorMessage = xhr.responseJSON?.message || 'Password change failed. Check your current password.';
                showFormMessage('#change-password-message', errorMessage, 'error');
            },
        });
    });

    // -------------------------
    // LOGOUT BUTTON
    // -------------------------
    $('#logoutBtn').click(function () {
        $.ajax({
            url: endpoints.logout,
            method: 'POST',
            xhrFields: { withCredentials: true },
            complete: function () {
                localStorage.removeItem('user');
                window.location = '/login.html';
            },
        });
    });
});