$(document).ready(function () {
  // (Appointment creation and management handled in patient.js and doctor.js)
});
