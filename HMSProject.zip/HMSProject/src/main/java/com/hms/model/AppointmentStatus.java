package com.hms.model;

public enum AppointmentStatus {
    BOOKED,
    CANCELLED
}
