package com.hms.model;

public enum Role {
    ADMIN,
    DOCTOR,
    PATIENT
}