 package com.hms.model;
 import jakarta.persistence.*;
 @Entity
 public class Patient {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String contact;
    @OneToOne(fetch = FetchType.LAZY)
    private User user;
    public Patient() {}
    public Patient(String name, String contact, User user) {
        this.name = name;
        this.contact = contact;
        this.user = user;
    }
    // getters & setters
 public Long getId() { return id; }
 public void setId(Long id) { this.id = id; }
 public String getName() { return name; }
 public void setName(String name) { this.name = name; }
 public String getContact() { return contact; }
 public void setContact(String contact) { this.contact = contact; }
 public User getUser() { return user; }
 public void setUser(User user) { this.user = user; }
 }