 package com.hms.model;
 import jakarta.persistence.*;
 import java.time.LocalDate;
 @Entity
 public class Appointment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private LocalDate date;
    private String timeSlot;
    @ManyToOne(fetch = FetchType.LAZY)
    private Doctor doctor;
    @ManyToOne(fetch = FetchType.LAZY)
    private Patient patient;
    @Enumerated(EnumType.STRING)
    private AppointmentStatus status;
    public Appointment() {}
    public Appointment(LocalDate date, String timeSlot, Doctor doctor, Patient patient, 
AppointmentStatus status) {
        this.date = date;
        this.timeSlot = timeSlot;
        this.doctor = doctor;
        this.patient = patient;
        this.status = status;
    }
    // getters & setters
 public Long getId() { return id; }
 public void setId(Long id) { this.id = id; }
 public LocalDate getDate() { return date; }
 public void setDate(LocalDate date) { this.date = date; }
 public String getTimeSlot() { return timeSlot; }
 public void setTimeSlot(String timeSlot) { this.timeSlot = timeSlot; }
 public Doctor getDoctor() { return doctor; }
 public void setDoctor(Doctor doctor) { this.doctor = doctor; }
 public Patient getPatient() { return patient; }
 public void setPatient(Patient patient) { this.patient = patient; }
 public AppointmentStatus getStatus() { return status; }
 public void setStatus(AppointmentStatus status) { this.status = status; }
 }