package com.hms.service;
 import com.hms.dto.AppointmentRequest;
 import com.hms.dto.AppointmentResponse;
 import com.hms.exception.BadRequestException;
 import com.hms.exception.ResourceNotFoundException;
 import com.hms.model.*;
 import com.hms.repository.AppointmentRepository;
 import com.hms.repository.DoctorRepository;
 import com.hms.repository.PatientRepository;
 import org.slf4j.Logger;
 import org.slf4j.LoggerFactory;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.stereotype.Service;
 import org.springframework.transaction.annotation.Transactional;
 import java.util.List;
 import java.util.stream.Collectors;
 @Service
 public class AppointmentService {
 private static final Logger log = LoggerFactory.getLogger(AppointmentService.class);
 @Autowired
 private AppointmentRepository appointmentRepository;
 @Autowired
 private DoctorRepository doctorRepository;
 @Autowired
 private PatientRepository patientRepository;
 public AppointmentResponse bookAppointment(AppointmentRequest request) {
 log.debug("Attempt booking: doctorId={} patientId={} date={} slot={}",
 request.getDoctorId(), request.getPatientId(), request.getDate(), 
request.getTimeSlot());
 Doctor doctor = doctorRepository.findById(request.getDoctorId())
 .orElseThrow(() -> new ResourceNotFoundException("Doctor not found"));
 Patient patient = patientRepository.findById(request.getPatientId())
 .orElseThrow(() -> new ResourceNotFoundException("Patient not found"));
 if (appointmentRepository.existsByDoctorIdAndDateAndTimeSlot(doctor.getId(), 
request.getDate(), request.getTimeSlot())) {
 log.warn("Slot already booked: doctorId={} date={} slot={}", doctor.getId(), 
request.getDate(), request.getTimeSlot());
 throw new BadRequestException("Slot already booked");
 }
 Appointment appointment = new Appointment(request.getDate(), request.getTimeSlot(), 
doctor, patient, AppointmentStatus.BOOKED);
 Appointment saved = appointmentRepository.save(appointment);
 log.info("Appointment created: id={} doctorId={} patientId={}", saved.getId(), 
doctor.getId(), patient.getId());
 return mapToResponse(saved);
 }
 public List<AppointmentResponse> getAppointmentsByDoctor(Long doctorId) {
 log.debug("Retrieve appointments by doctor: {}", doctorId);
 List<Appointment> list = appointmentRepository.findByDoctorId(doctorId);
 return list.stream().map(this::mapToResponse).collect(Collectors.toList());
 }
 public List<AppointmentResponse> getAppointmentsByPatient(Long patientId) {
 log.debug("Retrieve appointments by patient: {}", patientId);
 List<Appointment> list = appointmentRepository.findByPatientId(patientId);
 return list.stream().map(this::mapToResponse).collect(Collectors.toList());
}
@Transactional
public void cancelAppointment(Long appointmentId) {
 log.debug("Cancelling appointment: {}", appointmentId);
 Appointment appointment = appointmentRepository.findById(appointmentId)
         .orElseThrow(() -> new ResourceNotFoundException("Appointment not found"));
 if (appointment.getStatus() == AppointmentStatus.CANCELLED) {
     log.warn("Attempt to cancel already cancelled appointment: {}", appointmentId);
     throw new BadRequestException("Appointment already cancelled");
 }
 appointment.setStatus(AppointmentStatus.CANCELLED);
 appointmentRepository.save(appointment);
 log.info("Appointment cancelled: {}", appointmentId);
}
private AppointmentResponse mapToResponse(Appointment a) {
 String doctorName = a.getDoctor() != null ? a.getDoctor().getName() : null;
 String patientName = a.getPatient() != null ? a.getPatient().getName() : null;
 Long doctorId = a.getDoctor() != null ? a.getDoctor().getId() : null;
 Long patientId = a.getPatient() != null ? a.getPatient().getId() : null;
 return new AppointmentResponse(a.getId(), a.getDate(), a.getTimeSlot(),
         doctorId, doctorName, patientId, patientName, a.getStatus().name());
}
}