 package com.hms.service;
 import com.hms.dto.BillRequest;
 import com.hms.dto.BillResponse;
 import com.hms.exception.ResourceNotFoundException;
 import com.hms.model.Appointment;
 import com.hms.model.Bill;
 import com.hms.repository.AppointmentRepository;
 import com.hms.repository.BillRepository;
 import org.slf4j.Logger;
 import org.slf4j.LoggerFactory;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.stereotype.Service;
 import java.time.LocalDate;
 import java.util.List;
 import java.util.stream.Collectors;
 @Service
 public class BillService {
    private static final Logger log = LoggerFactory.getLogger(BillService.class);
    @Autowired
    private BillRepository billRepository;
    @Autowired
    private AppointmentRepository appointmentRepository;
    public BillResponse generateBill(BillRequest request) {
        log.debug("Generating bill for appointmentId={} amount={}", request.getAppointmentId(), 
request.getAmount());
        Appointment appointment = appointmentRepository.findById(request.getAppointmentId())
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found"));
        Bill bill = new Bill(request.getAmount(), LocalDate.now(), appointment);
        Bill saved = billRepository.save(bill);
        log.info("Bill saved: id={} appointmentId={}", saved.getId(), appointment.getId());
        return new BillResponse(saved.getId(), saved.getAmount(), saved.getBillDate(), 
saved.getAppointment().getId());
    }
        public List<BillResponse> getBillsByPatient(Long patientId) {
            log.debug("Fetching bills for patientId={}", patientId);
            List<Bill> bills = billRepository.findByAppointmentPatientId(patientId);
            return bills.stream().map(b -> new BillResponse(b.getId(), b.getAmount(), b.getBillDate(), 
    b.getAppointment().getId())).collect(Collectors.toList());
        }
     }
    