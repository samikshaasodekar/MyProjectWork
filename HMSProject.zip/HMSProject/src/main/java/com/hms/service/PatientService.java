 package com.hms.service;
 import com.hms.dto.PatientResponse;
 import com.hms.dto.RegisterPatientRequest;
 import com.hms.model.Patient;
 import com.hms.model.Role;
 import com.hms.model.User;
 import com.hms.repository.PatientRepository;
 import org.slf4j.Logger;
 import org.slf4j.LoggerFactory;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.stereotype.Service;
 @Service
 public class PatientService {
    private static final Logger log = LoggerFactory.getLogger(PatientService.class);
    @Autowired
    private PatientRepository patientRepository;
    @Autowired
    private UserService userService;
    public PatientResponse registerPatient(RegisterPatientRequest request) {
        log.debug("Register patient request: username={} name={}", request.getUsername(), 
request.getName());
        User user = userService.registerUser(request.getUsername(), request.getPassword(), 
Role.PATIENT);
        Patient patient = new Patient(request.getName(), request.getContact(), user);
        Patient saved = patientRepository.save(patient);
        log.info("Patient saved: id={} username={}", saved.getId(), 
saved.getUser().getUsername());
        return new PatientResponse(saved.getId(), saved.getName(), saved.getContact(), 
saved.getUser().getUsername());
    }
 }