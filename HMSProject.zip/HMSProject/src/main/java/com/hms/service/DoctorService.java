 package com.hms.service;
 import com.hms.dto.DoctorResponse;
 import com.hms.dto.RegisterDoctorRequest;
 import com.hms.model.Doctor;
 import com.hms.model.Role;
 import com.hms.model.User;
 import com.hms.repository.DoctorRepository;
 import org.slf4j.Logger;
 import org.slf4j.LoggerFactory;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.stereotype.Service;
 @Service
 public class DoctorService {
	    private static final Logger log = LoggerFactory.getLogger(DoctorService.class);
	    @Autowired
	    private DoctorRepository doctorRepository;
	    @Autowired
	    private UserService userService;
	    public DoctorResponse registerDoctor(RegisterDoctorRequest request) {
	        log.debug("Register doctor request: username={} name={}", request.getUsername(), 
	request.getName());
	        User user = userService.registerUser(request.getUsername(), request.getPassword(), 
	Role.DOCTOR);
	        Doctor doctor = new Doctor(request.getName(), request.getSpecialization(), user);
	        Doctor saved = doctorRepository.save(doctor);
	        log.info("Doctor saved: id={} username={}", saved.getId(), 
	saved.getUser().getUsername());
	        return new DoctorResponse(saved.getId(), saved.getName(), saved.getSpecialization(), 
	saved.getUser().getUsername());
	    }
	 }