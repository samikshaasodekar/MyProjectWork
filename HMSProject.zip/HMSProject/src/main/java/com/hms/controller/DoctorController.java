 package com.hms.controller;
 import com.hms.dto.AppointmentResponse;
 import com.hms.service.AppointmentService;
 import org.slf4j.Logger;
 import org.slf4j.LoggerFactory;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.web.bind.annotation.*;
 import java.util.List;
 @RestController
 @RequestMapping("/api/doctor")
 public class DoctorController {
    private static final Logger log = LoggerFactory.getLogger(DoctorController.class);
    @Autowired
    private AppointmentService appointmentService;
    @GetMapping("/appointments/{doctorId}")
    public List<AppointmentResponse> getAppointments(@PathVariable Long doctorId) {
        log.info("Fetching appointments for doctorId={}", doctorId);
        return appointmentService.getAppointmentsByDoctor(doctorId);
    }
 }