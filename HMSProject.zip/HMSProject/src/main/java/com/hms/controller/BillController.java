package com.hms.controller;
 import com.hms.dto.BillRequest;
 import com.hms.dto.BillResponse;
 import com.hms.service.BillService;
 import jakarta.validation.Valid;
 import org.slf4j.Logger;
 import org.slf4j.LoggerFactory;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.http.ResponseEntity;
 import org.springframework.http.HttpStatus;
 import org.springframework.web.bind.annotation.*;
 import java.util.List;
 @RestController
 @RequestMapping("/api/bill")
 public class BillController {
    private static final Logger log = LoggerFactory.getLogger(BillController.class);
    @Autowired
    private BillService billService;
    @PostMapping("/generate")
    public ResponseEntity<BillResponse> generateBill(@Valid @RequestBody BillRequest request) {
        log.info("Generating bill for appointmentId={} amount={}", request.getAppointmentId(), 
request.getAmount());
        BillResponse bill = billService.generateBill(request);
        log.info("Bill generated: id={} appointmentId={}", bill.getId(), 
bill.getAppointmentId());
        return ResponseEntity.status(HttpStatus.CREATED).body(bill);
    }
    @GetMapping("/by-patient/{patientId}")
    public ResponseEntity<List<BillResponse>> getBillsByPatient(@PathVariable Long patientId) {
        log.info("Fetch bills for patientId={}", patientId);
        List<BillResponse> list = billService.getBillsByPatient(patientId);
        return ResponseEntity.ok(list);
    }
 }