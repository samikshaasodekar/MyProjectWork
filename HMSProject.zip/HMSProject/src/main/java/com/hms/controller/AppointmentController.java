package com.hms.controller;
 import com.hms.dto.AppointmentRequest;
 import com.hms.dto.AppointmentResponse;
 import com.hms.service.AppointmentService;
 import jakarta.validation.Valid;
 import org.slf4j.Logger;
 import org.slf4j.LoggerFactory;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.http.ResponseEntity;
 import org.springframework.http.HttpStatus;
 import org.springframework.web.bind.annotation.*;
 import java.util.List;
 @RestController
 @RequestMapping("/api/appointments")
 public class AppointmentController {
    private static final Logger log = LoggerFactory.getLogger(AppointmentController.class);
    @Autowired
    private AppointmentService appointmentService;
    @PostMapping("/book")
    public ResponseEntity<AppointmentResponse> bookAppointment(@Valid @RequestBody 
AppointmentRequest request) {
        log.info("Booking appointment: doctorId={}, patientId={}, date={}, slot={}",
                request.getDoctorId(), request.getPatientId(), request.getDate(), 
request.getTimeSlot());
        AppointmentResponse appointment = appointmentService.bookAppointment(request);
        log.info("Appointment booked: id={} doctorId={} patientId={}", appointment.getId(), 
        		appointment.getDoctorId(), appointment.getPatientId());
        return ResponseEntity.status(HttpStatus.CREATED).body(appointment);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> cancelAppointment(@PathVariable Long id) {
        log.info("Cancel appointment requested: id={}", id);
        appointmentService.cancelAppointment(id);
        log.info("Appointment cancelled: id={}", id);
        return ResponseEntity.noContent().build();
    }
    @GetMapping("/by-patient/{patientId}")
    public ResponseEntity<List<AppointmentResponse>> getByPatient(@PathVariable Long patientId) 
{
        log.info("Get appointments by patient: patientId={}", patientId);
        List<AppointmentResponse> list = appointmentService.getAppointmentsByPatient(patientId);
        return ResponseEntity.ok(list);
    }
 }
