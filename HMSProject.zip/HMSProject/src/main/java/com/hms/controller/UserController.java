package com.hms.controller;
 import com.hms.dto.PatientResponse;
 import com.hms.dto.RegisterPatientRequest;
 import com.hms.service.PatientService;
 import jakarta.validation.Valid;
 import org.slf4j.Logger;
 import org.slf4j.LoggerFactory;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.http.HttpStatus;
 import org.springframework.http.ResponseEntity;
 import org.springframework.web.bind.annotation.*;
 @RestController
 @RequestMapping("/api/user")
 public class UserController {
    private static final Logger log = LoggerFactory.getLogger(UserController.class);
    @Autowired
    private PatientService patientService;
    @PostMapping("/register-patient")
    public ResponseEntity<PatientResponse> registerPatient(@Valid @RequestBody 
RegisterPatientRequest request) {
        log.info("Register patient request received: username={}", request.getUsername());
        PatientResponse patient = patientService.registerPatient(request);
        log.info("Patient registered: id={} username={}", patient.getId(), 
patient.getUsername());
        return ResponseEntity.status(HttpStatus.CREATED).body(patient);
    }
 }