 package com.hms.controller;
 import com.hms.dto.DoctorResponse;
 import com.hms.dto.RegisterDoctorRequest;
 import com.hms.service.DoctorService;
 import jakarta.validation.Valid;
 import org.slf4j.Logger;
 import org.slf4j.LoggerFactory;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.http.HttpStatus;
 import org.springframework.http.ResponseEntity;
 import org.springframework.web.bind.annotation.*;
 @RestController
 @RequestMapping("/api/admin")
 public class AdminController {
    private static final Logger log = LoggerFactory.getLogger(AdminController.class);
    @Autowired
    private DoctorService doctorService;
    @PostMapping("/register-doctor")
    public ResponseEntity<DoctorResponse> registerDoctor(@Valid @RequestBody 
RegisterDoctorRequest request) {
        log.info("Admin requested doctor registration: username={}", request.getUsername());
        DoctorResponse doctor = doctorService.registerDoctor(request);
        log.info("Doctor registered: id={} username={}", doctor.getId(), doctor.getUsername());
        return ResponseEntity.status(HttpStatus.CREATED).body(doctor);
    }
 }