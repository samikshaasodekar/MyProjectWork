 package com.hms.dto;
 import jakarta.validation.constraints.NotNull;
 import jakarta.validation.constraints.Positive;
 public class BillRequest {
    @NotNull
    private Long appointmentId;
    @NotNull
    @Positive
    private Double amount;
    public BillRequest() {}
    public BillRequest(Long appointmentId, Double amount) {
        this.appointmentId = appointmentId;
        this.amount = amount;
    }
    // getters & setters
 public Long getAppointmentId() { return appointmentId; }
 public void setAppointmentId(Long appointmentId) { this.appointmentId = appointmentId; }
 public Double getAmount() { return amount; }
 public void setAmount(Double amount) { this.amount = amount; }
 }