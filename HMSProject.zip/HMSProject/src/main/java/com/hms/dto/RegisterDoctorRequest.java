 package com.hms.dto;
 import jakarta.validation.constraints.NotBlank;
 import jakarta.validation.constraints.Size;
 public class RegisterDoctorRequest {
    @NotBlank
    private String username;
    @NotBlank
    @Size(min = 6)
    private String password;
    @NotBlank
    private String name;
    @NotBlank
    private String specialization;
    public RegisterDoctorRequest() {}
    public RegisterDoctorRequest(String username, String password, String name, String 
specialization) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.specialization = specialization;
    }
    // getters & setters
 public String getUsername() { return username; }
 public void setUsername(String username) { this.username = username; }
 public String getPassword() { return password; }
 public void setPassword(String password) { this.password = password; }
 public String getName() { return name; }
 public void setName(String name) { this.name = name; }
 public String getSpecialization() { return specialization; }
 public void setSpecialization(String specialization) { this.specialization = 
specialization; }
 }