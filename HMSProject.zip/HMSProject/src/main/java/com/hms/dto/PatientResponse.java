package com.hms.dto;
 public class PatientResponse {
    private Long id;
    private String name;
    private String contact;
    private String username;
    public PatientResponse() {}
    public PatientResponse(Long id, String name, String contact, String username) {
        this.id = id; this.name = name; this.contact = contact; this.username = username;
    }
    // getters & setters
 public Long getId() { return id; }
 public void setId(Long id) { this.id = id; }
 public String getName() { return name; }
 public void setName(String name) { this.name = name; }
 public String getContact() { return contact; }
 public void setContact(String contact) { this.contact = contact; }
 public String getUsername() { return username; }
 public void setUsername(String username) { this.username = username; }
 }