 package com.hms.dto;
 import java.time.LocalDate;
 public class BillResponse {
    private Long id;
    private Double amount;
    private LocalDate billDate;
    private Long appointmentId;
    public BillResponse() {}
    public BillResponse(Long id, Double amount, LocalDate billDate, Long appointmentId) {
        this.id = id; this.amount = amount; this.billDate = billDate; this.appointmentId = 
appointmentId;
    }
    // getters & setters
 public Long getId() { return id; }
 public void setId(Long id) { this.id = id; }
 public Double getAmount() { return amount; }
 public void setAmount(Double amount) { this.amount = amount; }
 public LocalDate getBillDate() { return billDate; }
 public void setBillDate(LocalDate billDate) { this.billDate = billDate; }
 public Long getAppointmentId() { return appointmentId; }
 public void setAppointmentId(Long appointmentId) { this.appointmentId = appointmentId; }
 }