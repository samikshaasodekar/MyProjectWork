package com.hms.dto;
 import jakarta.validation.constraints.NotNull;
 import jakarta.validation.constraints.NotBlank;
 import java.time.LocalDate;
 public class AppointmentRequest {
    @NotNull
    private Long doctorId;
    @NotNull
    private Long patientId;
    @NotNull
    private LocalDate date;
    @NotBlank
    private String timeSlot;
    public AppointmentRequest() {}
    public AppointmentRequest(Long doctorId, Long patientId, LocalDate date, String timeSlot) {
        this.doctorId = doctorId;
        this.patientId = patientId;
        this.date = date;
        this.timeSlot = timeSlot;
    }
    // getters & setters
 public Long getDoctorId() { return doctorId; }
 public void setDoctorId(Long doctorId) { this.doctorId = doctorId; }
 public Long getPatientId() { return patientId; }
 public void setPatientId(Long patientId) { this.patientId = patientId; }
 public LocalDate getDate() { return date; }
 public void setDate(LocalDate date) { this.date = date; }
 public String getTimeSlot() { return timeSlot; }
 public void setTimeSlot(String timeSlot) { this.timeSlot = timeSlot; }
 }