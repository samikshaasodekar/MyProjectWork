 package com.hms.dto;
 import java.time.LocalDate;
 public class AppointmentResponse {
    private Long id;
    private LocalDate date;
    private String timeSlot;
    private Long doctorId;
    private String doctorName;
    private Long patientId;
    private String patientName;
    private String status;
    public AppointmentResponse() {}
    public AppointmentResponse(Long id, LocalDate date, String timeSlot,
                               Long doctorId, String doctorName,
                               Long patientId, String patientName,
                               String status) {
        this.id = id; this.date = date; this.timeSlot = timeSlot;
        this.doctorId = doctorId; this.doctorName = doctorName;
        this.patientId = patientId; this.patientName = patientName;
        this.status = status;
    }
    // getters & setters
 public Long getId() { return id; }
 public void setId(Long id) { this.id = id; }
 public LocalDate getDate() { return date; }
 public void setDate(LocalDate date) { this.date = date; }
 public String getTimeSlot() { return timeSlot; }
 public void setTimeSlot(String timeSlot) { this.timeSlot = timeSlot; }
 public Long getDoctorId() { return doctorId; }
 public void setDoctorId(Long doctorId) { this.doctorId = doctorId; }
 public String getDoctorName() { return doctorName; }
 public void setDoctorName(String doctorName) { this.doctorName = doctorName; }
 public Long getPatientId() { return patientId; }
 public void setPatientId(Long patientId) { this.patientId = patientId; }
 public String getPatientName() { return patientName; }
 public void setPatientName(String patientName) { this.patientName = patientName; }
 public String getStatus() { return status; }
 public void setStatus(String status) { this.status = status; }
 }