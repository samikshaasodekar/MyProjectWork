✅ Corrected HMS Frontend (Fully Working)
- Uses BASE_URL = http://localhost:8082
- Test via Live Server (http://127.0.0.1:5500)
- Integrated with AJAX + Bootstrap + jQuery
