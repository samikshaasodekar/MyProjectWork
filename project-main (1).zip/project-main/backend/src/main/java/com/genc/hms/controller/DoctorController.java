package com.genc.hms.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.genc.hms.dto.DoctorAvailabilityDTO;
import com.genc.hms.dto.DoctorResponseDTO;
import com.genc.hms.enums.WeekDay;
import com.genc.hms.service.DoctorService;

import jakarta.servlet.http.HttpSession;

@RestController
@CrossOrigin
@RequestMapping("/api/doctors")
public class DoctorController {

    private static final Logger logger = LoggerFactory.getLogger(DoctorController.class);
    private static final String LOGGED_IN_ROLE_ID_KEY = "LOGGED_IN_ROLE_ID";

    @Autowired
    private DoctorService doctorService;

    // ----------------- Self Profile -----------------

    @GetMapping("/me")
    public ResponseEntity<DoctorResponseDTO> getCurrentDoctor(HttpSession session) {
        Long doctorId = (Long) session.getAttribute(LOGGED_IN_ROLE_ID_KEY);
        if (doctorId == null) {
            logger.warn("Unauthorized access attempt to doctor profile (session missing)");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        logger.info("Doctor {} requested their profile", doctorId);
        return getDoctorById(doctorId);
    }

    @GetMapping("/{id}")
    public ResponseEntity<DoctorResponseDTO> getDoctorById(@PathVariable Long id) {
        Optional<DoctorResponseDTO> doctor = doctorService.findDoctorById(id);
        if (doctor.isPresent()) {
            logger.info("Doctor profile retrieved for ID {}", id);
            return ResponseEntity.ok(doctor.get());
        } else {
            logger.warn("Doctor profile not found for ID {}", id);
            return ResponseEntity.notFound().build();
        }
    }

    // ----------------- General Retrieval & Search -----------------

    @GetMapping("/all")
    public List<DoctorResponseDTO> getAllDoctors() {
        logger.info("Retrieved list of all doctors");
        return doctorService.findAllDoctors();
    }

    @GetMapping
    public ResponseEntity<List<DoctorResponseDTO>> getAllOrSearchDoctors(@RequestParam(required = false) String keyword) {
        List<DoctorResponseDTO> doctors = doctorService.searchDoctors(keyword);
        logger.info("Retrieved list of doctors with search keyword: {}", keyword);
        return ResponseEntity.ok(doctors);
    }

    // ----------------- Availability -----------------

    @GetMapping("/{doctorId}/availability")
    public List<DoctorAvailabilityDTO> getDoctorAvailability(@PathVariable Long doctorId) {
        logger.info("Retrieved full availability for doctor {}", doctorId);
        return doctorService.getDoctorAvailability(doctorId);
    }

    @GetMapping("/{doctorId}/available-days")
    public ResponseEntity<List<WeekDay>> getDoctorAvailableDays(@PathVariable Long doctorId) {
        List<WeekDay> availableDays = doctorService.getDoctorAvailableDays(doctorId);
        if (availableDays == null) {
            logger.warn("Available days not found for doctor {}", doctorId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        logger.info("Retrieved available days for doctor {}", doctorId);
        return ResponseEntity.ok(availableDays);
    }
}
