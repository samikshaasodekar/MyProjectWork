package com.genc.hms.controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.genc.hms.dto.*;
import com.genc.hms.entity.User;
import com.genc.hms.service.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/users")
@CrossOrigin
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    private static final String LOGGED_IN_USER_EMAIL_KEY = "LOGGED_IN_USER_EMAIL";
    private static final String LOGGED_IN_USER_ROLE_KEY = "ROLE";
    private static final String LOGGED_IN_USER_ID_KEY = "LOGGED_IN_USER_ID";
    private static final String LOGGED_IN_ROLE_ID_KEY = "LOGGED_IN_ROLE_ID";

    @Autowired
    private UserService userService;

    // ----------------- Registration & Login -----------------

    @PostMapping("/register")
    public ResponseEntity<UserResponseDTO> registerPatient(
            @Valid @RequestBody PatientRegisterRequestDTO registrationDetails) {
        try {
            if (userService.findByEmail(registrationDetails.getEmail()).isPresent()) {
                logger.warn("Registration attempt with existing email: {}", registrationDetails.getEmail());
                return ResponseEntity.status(HttpStatus.CONFLICT).build();
            }

            UserResponseDTO responseDTO = userService.registerPatient(registrationDetails);
            logger.info("New patient registered with userId: {}", responseDTO.getUserId());
            return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);
        } catch (Exception e) {
            logger.error("Error during patient registration for email: {}", registrationDetails.getEmail(), e);
            return new ResponseEntity<>(new UserResponseDTO(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<UserLoginResponseDTO> login(@Valid @RequestBody UserLoginRequestDTO loginRequest,
                                                      HttpSession session) {
        try {
            if (session.getAttribute(LOGGED_IN_USER_EMAIL_KEY) != null) {
                logger.warn("Login attempt while another user is active on this session");
                return ResponseEntity.status(HttpStatus.CONFLICT)
                        .body(new UserLoginResponseDTO(null, null, null, null,
                                "Another user is already logged in on this browser. Please logout first."));
            }

            Optional<User> userOptional = userService.findByEmail(loginRequest.getEmail());
            if (userOptional.isEmpty()) {
                logger.warn("Login failed for email: {}", loginRequest.getEmail());
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(new UserLoginResponseDTO(null, null, null, null, "Invalid email or password."));
            }

            User user = userOptional.get();
            Long roleId = userService.getRoleIdFromUser(user);

            UserLoginResponseDTO responseDTO = new UserLoginResponseDTO(user.getUserId(), roleId, user.getEmail(),
                    user.getRole().name(), "Login successful.");

            session.setAttribute(LOGGED_IN_USER_EMAIL_KEY, responseDTO.getEmail());
            session.setAttribute(LOGGED_IN_USER_ROLE_KEY, responseDTO.getRole());
            session.setAttribute(LOGGED_IN_USER_ID_KEY, responseDTO.getUserId());
            session.setAttribute(LOGGED_IN_ROLE_ID_KEY, responseDTO.getRoleId());

            logger.info("User {} logged in successfully", user.getUserId());
            return ResponseEntity.ok(responseDTO);

        } catch (Exception e) {
            logger.error("Error during login for email: {}", loginRequest.getEmail(), e);
            return new ResponseEntity<>(new UserLoginResponseDTO(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // ----------------- Session & Profile -----------------

    @GetMapping("/me")
    public ResponseEntity<UserLoginResponseDTO> getCurrentUser(HttpSession session) {
        try {
            String email = (String) session.getAttribute(LOGGED_IN_USER_EMAIL_KEY);
            String role = (String) session.getAttribute(LOGGED_IN_USER_ROLE_KEY);
            Long userId = (Long) session.getAttribute(LOGGED_IN_USER_ID_KEY);
            Long roleId = (Long) session.getAttribute(LOGGED_IN_ROLE_ID_KEY);

            if (email == null || role == null) {
                logger.warn("Session check failed: no active session found");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
            }

            logger.info("Session check for user {}", userId);
            UserLoginResponseDTO responseDTO = new UserLoginResponseDTO(userId, roleId, email, role, "Session active.");
            return ResponseEntity.ok(responseDTO);
        } catch (Exception e) {
            logger.error("Error checking current user session", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserResponseDTO> findUserById(@PathVariable long id, HttpSession session) {
        Optional<User> user = userService.findById(id);

        Long currentUserId = (Long) session.getAttribute(LOGGED_IN_USER_ID_KEY);

        if (user.isPresent()) {
            User u = user.get();
            UserResponseDTO userResponseDTO = new UserResponseDTO(u.getUserId(), userService.getRoleIdFromUser(u),
                    u.getEmail(), u.getRole().name());
            logger.info("User {} retrieved details of user {}", currentUserId, id);
            return ResponseEntity.ok(userResponseDTO);
        } else {
            logger.warn("User {} tried to retrieve non-existent user {}", currentUserId, id);
            return ResponseEntity.notFound().build();
        }
    }

    // ----------------- Modification & Logout -----------------

    @PostMapping("/change-password")
    public ResponseEntity<String> changePassword(@Valid @RequestBody UserChangePasswordRequestDTO request,
                                                 HttpSession session) {
        try {
            String authenticatedEmail = (String) session.getAttribute(LOGGED_IN_USER_EMAIL_KEY);
            Long currentUserId = (Long) session.getAttribute(LOGGED_IN_USER_ID_KEY);

            if (authenticatedEmail == null) {
                logger.warn("Unauthorized password change attempt");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body("User must be logged in to change password.");
            }

            boolean success = userService.changePassword(authenticatedEmail, request);

            if (success) {
                session.invalidate();
                logger.info("User {} changed password successfully", currentUserId);
                return ResponseEntity.ok("Password successfully changed. Please log in again.");
            } else {
                logger.warn("User {} failed to change password", currentUserId);
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body("Failed to change password. Check your current password.");
            }
        } catch (Exception e) {
            logger.error("Error during password change", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout(HttpSession session) {
        try {
            Long currentUserId = (Long) session.getAttribute(LOGGED_IN_USER_ID_KEY);
            session.invalidate();
            logger.info("User {} logged out", currentUserId != null ? currentUserId : "unknown");
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            logger.error("Error during logout", e);
            return ResponseEntity.internalServerError().build();
        }
    }
}
