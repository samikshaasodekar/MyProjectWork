package com.genc.hms.enums;

public enum Gender {
	MALE, FEMALE, OTHER
}
