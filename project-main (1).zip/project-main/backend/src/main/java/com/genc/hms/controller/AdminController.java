package com.genc.hms.controller;

import java.util.List;
import java.util.Optional;

import com.genc.hms.dto.*;
import com.genc.hms.entity.Appointment;
import com.genc.hms.entity.Patient;
import com.genc.hms.enums.AppointmentStatus;
import com.genc.hms.enums.Role;
import com.genc.hms.service.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

/**
 * REST Controller for administrator-level operations in the Hospital Management System.
 * All endpoints require the logged-in user to have the ADMIN role.
 */
@RestController
@CrossOrigin
@RequestMapping("/api/admin")
public class AdminController {

    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    private final PatientService patientService;
    private final DoctorService doctorService;

    @Autowired
    private AdminService adminService;

    @Autowired
    private UserService userService;

    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private BillingService billingService;

    private static final String LOGGED_IN_USER_ROLE_KEY = "ROLE";
    private static final String LOGGED_IN_USER_ID_KEY = "LOGGED_IN_USER_ID";

    public AdminController(DoctorService doctorService, PatientService patientService) {
        this.doctorService = doctorService;
        this.patientService = patientService;
    }

    private boolean isAdmin(HttpSession session) {
        return Role.ADMIN.name().equals(session.getAttribute(LOGGED_IN_USER_ROLE_KEY));
    }

    // ===================== I. USER MANAGEMENT =====================
    @GetMapping("/users")
    public ResponseEntity<List<UserResponseDTO>> getAllUsers(HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        logger.info("Admin [{}] requested all users", session.getAttribute(LOGGED_IN_USER_ID_KEY));
        return ResponseEntity.ok(adminService.getAllUsers());
    }

    @GetMapping("/users/{id}")
    public ResponseEntity<UserResponseDTO> getUserById(@PathVariable long id, HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        logger.info("Admin [{}] requested user with id {}", session.getAttribute(LOGGED_IN_USER_ID_KEY), id);
        UserResponseDTO user = userService.getUserById(id);
        return user != null ? ResponseEntity.ok(user) : ResponseEntity.notFound().build();
    }

    @PutMapping("/users/{userId}/identity")
    public ResponseEntity<UserResponseDTO> updateUserIdentity(
            @PathVariable Long userId,
            @Valid @RequestBody UserUpdateRoleAndEmailDTO updateDTO,
            HttpSession session) {

        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        if (updateDTO.getEmail() != null && userService.findByEmail(updateDTO.getEmail())
                .filter(u -> !u.getUserId().equals(userId)).isPresent()) {
            logger.warn("Admin [{}] attempted to update user [{}] with duplicate email {}",
                    session.getAttribute(LOGGED_IN_USER_ID_KEY), userId, updateDTO.getEmail());
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }

        Optional<UserResponseDTO> updatedUser = adminService.updateUserIdentity(userId, updateDTO);
        updatedUser.ifPresent(u -> logger.info("Admin [{}] updated user [{}]",
                session.getAttribute(LOGGED_IN_USER_ID_KEY), userId));
        return updatedUser.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/users/{userId}/reset-password")
    public ResponseEntity<String> resetPassword(@PathVariable Long userId, @RequestBody String password, HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        if (adminService.resetUserPassword(userId, password)) {
            logger.info("Admin [{}] reset password for user [{}]", session.getAttribute(LOGGED_IN_USER_ID_KEY), userId);
            return ResponseEntity.ok("Password successfully reset for user ID: " + userId);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/users/{userId}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long userId, HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        if (adminService.deleteUser(userId)) {
            logger.info("Admin [{}] deleted user [{}]", session.getAttribute(LOGGED_IN_USER_ID_KEY), userId);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // ===================== II. REGISTRATION =====================
    @PostMapping("/admin/register")
    public ResponseEntity<AdminResponseDTO> registerAdmin(@Valid @RequestBody AdminRegisterDTO registrationDetails, HttpSession session) {
        Long count = adminService.getCount();
        if (count != 0) {
            if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        if (userService.findByEmail(registrationDetails.getEmail()).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }

        AdminResponseDTO dto = userService.registerAdmin(registrationDetails);
        logger.info("Admin [{}] registered new admin [{}]", session.getAttribute(LOGGED_IN_USER_ID_KEY), dto.getUserId());
        return new ResponseEntity<>(dto, HttpStatus.CREATED);
    }

    @PostMapping("/doctors/register")
    public ResponseEntity<UserResponseDTO> registerDoctor(@Valid @RequestBody DoctorRegisterRequestDTO registrationDetails, HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        if (userService.findByEmail(registrationDetails.getEmail()).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }

        UserResponseDTO dto = adminService.registerNewDoctor(registrationDetails);
        logger.info("Admin [{}] registered new doctor [{}]", session.getAttribute(LOGGED_IN_USER_ID_KEY), dto.getUserId());
        return new ResponseEntity<>(dto, HttpStatus.CREATED);
    }

    @PostMapping("/patients/register")
    public ResponseEntity<UserResponseDTO> registerPatient(@Valid @RequestBody PatientRegisterRequestDTO registrationDetails, HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        if (userService.findByEmail(registrationDetails.getEmail()).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }

        UserResponseDTO dto = adminService.registerNewPatient(registrationDetails);
        logger.info("Admin [{}] registered new patient [{}]", session.getAttribute(LOGGED_IN_USER_ID_KEY), dto.getUserId());
        return new ResponseEntity<>(dto, HttpStatus.CREATED);
    }

    // ===================== III. DOCTOR MANAGEMENT =====================
    @GetMapping("/doctors")
    public ResponseEntity<List<DoctorResponseDTO>> getAllDoctors(HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        logger.info("Admin [{}] requested all doctors", session.getAttribute(LOGGED_IN_USER_ID_KEY));
        return ResponseEntity.ok(adminService.getAllDoctors());
    }

    @GetMapping("/doctors/{doctorId}")
    public ResponseEntity<DoctorResponseDTO> getDoctorById(@PathVariable Long doctorId, HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        Optional<DoctorResponseDTO> doctor = doctorService.findDoctorById(doctorId);
        return doctor.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/doctors/{doctorId}")
    public ResponseEntity<DoctorResponseDTO> updateDoctorProfile(@PathVariable Long doctorId, @Valid @RequestBody DoctorProfileUpdateDTO updateDTO, HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        Optional<DoctorResponseDTO> updated = adminService.updateDoctorProfile(doctorId, updateDTO);
        updated.ifPresent(d -> logger.info("Admin [{}] updated doctor [{}]", session.getAttribute(LOGGED_IN_USER_ID_KEY), doctorId));
        return updated.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/doctors/{id}")
    public ResponseEntity<Void> deleteDoctor(@PathVariable long id, HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        if (doctorService.deleteDoctor(id)) {
            logger.info("Admin [{}] deleted doctor [{}]", session.getAttribute(LOGGED_IN_USER_ID_KEY), id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // ===================== IV. PATIENT MANAGEMENT =====================
    @GetMapping("/patients")
    public ResponseEntity<List<PatientResponseDTO>> getAllPatients(HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        logger.info("Admin [{}] requested all patients", session.getAttribute(LOGGED_IN_USER_ID_KEY));
        return ResponseEntity.ok(adminService.getAllPatients());
    }

    @GetMapping("/patients/{id}")
    public ResponseEntity<PatientResponseDTO> getPatientById(@PathVariable long id, HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        Optional<PatientResponseDTO> optionalPatient = patientService.findPatientProfileByPatientId(id);
        return optionalPatient.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/patients/{id}")
    public ResponseEntity<PatientResponseDTO> updatePatientProfile(@PathVariable long id, @RequestBody PatientUpdateRequestDTO updateRequestDTO, HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        Patient updatedPatient = patientService.updatePatientProfile(id, updateRequestDTO);
        logger.info("Admin [{}] updated patient [{}]", session.getAttribute(LOGGED_IN_USER_ID_KEY), id);
        PatientResponseDTO dto = new PatientResponseDTO(updatedPatient.getPatientId(), updatedPatient.getUser().getUserId(), updatedPatient.getUser().getEmail(),
                updatedPatient.getName(), updatedPatient.getDob(), updatedPatient.getContactNumber(), updatedPatient.getAddress(),
                updatedPatient.getGender(), updatedPatient.getMedicalHistory());
        return ResponseEntity.ok(dto);
    }

    @DeleteMapping("/patients/{id}")
    public ResponseEntity<Void> deletePatient(@PathVariable long id, HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        if (patientService.deletePatient(id)) {
            logger.info("Admin [{}] deleted patient [{}]", session.getAttribute(LOGGED_IN_USER_ID_KEY), id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // ===================== V. APPOINTMENT MANAGEMENT =====================
    @GetMapping("/appointments")
    public ResponseEntity<List<AppointmentResponseDTO>> getAllAppointments(HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        logger.info("Admin [{}] requested all appointments", session.getAttribute(LOGGED_IN_USER_ID_KEY));
        return ResponseEntity.ok(adminService.getAllAppointments());
    }

    @GetMapping("/appointments/{id}")
    public ResponseEntity<AppointmentResponseDTO> getAppointmentById(@PathVariable long id, HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        Optional<Appointment> optionalAppointment = appointmentService.findById(id);
        if (optionalAppointment.isEmpty()) return ResponseEntity.notFound().build();

        Appointment appointment = optionalAppointment.get();
        AppointmentResponseDTO dto = new AppointmentResponseDTO(
                appointment.getAppointmentId(),
                appointment.getPatient().getPatientId(),
                appointment.getPatient().getName(),
                appointment.getDoctor().getDoctorId(),
                appointment.getDoctor().getName(),
                appointment.getDoctor().getSpecialization(),
                appointment.getAppointmentDate(),
                appointment.getTimeSlot(),
                appointment.getReason(),
                appointment.getStatus(),
                appointment.getRemarks()
        );
        return ResponseEntity.ok(dto);
    }

    @PutMapping("/appointments/{appointmentId}/status")
    public ResponseEntity<AppointmentResponseDTO> updateAppointmentStatus(
            @PathVariable Long appointmentId,
            @RequestParam AppointmentStatus newStatus,
            @RequestParam(required = false) String remarks,
            HttpSession session) {

        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        Optional<AppointmentResponseDTO> updatedAppointment = appointmentService.updateAppointmentStatus(appointmentId, newStatus, remarks);
        return updatedAppointment.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/appointments/{appointmentId}/cancel")
    public ResponseEntity<Void> cancelAppointment(@PathVariable Long appointmentId, HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        if (appointmentService.cancelAppointment(appointmentId)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    // ===================== VI. BILLING MANAGEMENT =====================
    @GetMapping("/billing")
    public ResponseEntity<List<BillResponseDTO>> getAllBills(HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        return ResponseEntity.ok(adminService.getAllBills());
    }

    @PostMapping("/billing/{billId}/pay")
    public ResponseEntity<BillResponseDTO> recordPayment(@PathVariable Long billId, HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        Optional<BillResponseDTO> updatedBill = billingService.recordPayment(billId);
        return updatedBill.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    // ===================== VII. COUNT MANAGEMENT =====================
    @GetMapping("/count")
    public ResponseEntity<Long> getCount(@RequestParam String name, HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        Long count = switch (name.toLowerCase()) {
            case "doctors" -> doctorService.getCount();
            case "patients" -> patientService.getCount();
            case "admins" -> adminService.getCount();
            case "users" -> userService.getCount();
            case "appointments" -> appointmentService.getCount();
            case "bills" -> billingService.getCount();
            default -> null;
        };

        return count != null ? ResponseEntity.ok(count) : ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
    }
}
