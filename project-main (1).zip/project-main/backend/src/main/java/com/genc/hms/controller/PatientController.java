package com.genc.hms.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.genc.hms.dto.PatientResponseDTO;
import com.genc.hms.dto.PatientUpdateRequestDTO;
import com.genc.hms.entity.Patient;
import com.genc.hms.enums.Role;
import com.genc.hms.service.PatientService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@RestController
@CrossOrigin
@RequestMapping("/api/patients")
public class PatientController {

    private static final Logger logger = LoggerFactory.getLogger(PatientController.class);

    public static final String LOGGED_IN_USER_ROLE_KEY = "ROLE";
    public static final String LOGGED_IN_ROLE_ID_KEY = "LOGGED_IN_ROLE_ID";

    @Autowired
    private PatientService patientService;

    private Optional<Long> getAuthorizedPatientId(HttpSession session) {
        Long patientId = (Long) session.getAttribute(LOGGED_IN_ROLE_ID_KEY);
        String role = (String) session.getAttribute(LOGGED_IN_USER_ROLE_KEY);

        if (patientId == null || !Role.PATIENT.name().equals(role)) {
            return Optional.empty();
        }
        return Optional.of(patientId);
    }

    // ----------------- Self-Management -----------------

    @GetMapping("/me")
    public ResponseEntity<PatientResponseDTO> getPatientProfile(HttpSession session) {
        Optional<Long> patientIdOptional = getAuthorizedPatientId(session);

        if (patientIdOptional.isEmpty()) {
            logger.warn("Unauthorized patient profile access attempt");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Long patientId = patientIdOptional.get();
        Optional<PatientResponseDTO> patientDTO = patientService.findPatientProfileByPatientId(patientId);

        if (patientDTO.isPresent()) {
            logger.info("Patient {} retrieved their profile", patientId);
            return ResponseEntity.ok(patientDTO.get());
        } else {
            logger.warn("Patient {} not found in database", patientId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    @PutMapping("/me")
    public ResponseEntity<PatientResponseDTO> updatePatientProfile(
            @Valid @RequestBody PatientUpdateRequestDTO updateDTO, HttpSession session) {

        Optional<Long> patientIdOptional = getAuthorizedPatientId(session);

        if (patientIdOptional.isEmpty()) {
            logger.warn("Unauthorized patient profile update attempt");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Long patientId = patientIdOptional.get();
        Patient patient = patientService.updatePatientProfile(patientId, updateDTO);

        if (patient != null) {
            PatientResponseDTO dto = new PatientResponseDTO(
                    patient.getPatientId(),
                    patient.getUser().getUserId(),
                    patient.getUser().getEmail(),
                    patient.getName(),
                    patient.getDob(),
                    patient.getContactNumber(),
                    patient.getAddress(),
                    patient.getGender(),
                    patient.getMedicalHistory()
            );
            logger.info("Patient {} updated their profile", patientId);
            return ResponseEntity.ok(dto);
        } else {
            logger.warn("Patient {} not found during profile update", patientId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    // ----------------- General Retrieval (Staff/Admin) -----------------

    @GetMapping
    public ResponseEntity<List<PatientResponseDTO>> getAllOrSearchPatients(
            @RequestParam(required = false) String keyword) {

        List<PatientResponseDTO> patientResponseDto = patientService.searchPatient(keyword);
        logger.info("Retrieved list of patients (search keyword: {})", keyword);
        return ResponseEntity.ok(patientResponseDto);
    }

    @GetMapping("/{id}")
    public ResponseEntity<PatientResponseDTO> getPatientFromId(@PathVariable Long id) {
        Optional<Patient> patientOptional = patientService.findById(id);

        if (patientOptional.isEmpty()) {
            logger.warn("Patient with ID {} not found", id);
            return ResponseEntity.notFound().build();
        }

        Patient patient = patientOptional.get();
        PatientResponseDTO dto = new PatientResponseDTO(
                patient.getPatientId(),
                patient.getUser().getUserId(),
                patient.getUser().getEmail(),
                patient.getName(),
                patient.getDob(),
                patient.getContactNumber(),
                patient.getAddress(),
                patient.getGender(),
                patient.getMedicalHistory()
        );

        logger.info("Retrieved details of patient {}", id);
        return new ResponseEntity<>(dto, HttpStatus.OK);
    }
}
