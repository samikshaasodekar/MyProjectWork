var base_url = 'http://localhost:8085/api';
$.ajaxSetup({ xhrFields: { withCredentials: true } });

// -------------------------
// Navbar Rendering
// -------------------------
function renderNavbar(role) {
  const origin = window.location.origin;

  // Inline <style> ensures consistent Emerald Green theme across pages
  let nav = `
    <style>
      /* Emerald theme and hover effects */
      :root { --primary-color: #10b981; --primary-dark: #059669; }
      .bg-primary { background-color: var(--primary-color) !important; }
      .text-primary { color: var(--primary-color) !important; }
      .navbar-nav .nav-link { color: #fff !important; font-weight: 500; padding: 0.6rem 1rem !important; border-radius: 0.5rem; transition: all 0.3s ease; }
      .navbar-nav .nav-link:hover, .navbar-nav .nav-link.active { background-color: var(--primary-dark); color: #fff !important; text-shadow: 0 0 5px rgba(255,255,255,0.2); }
      .navbar-brand { font-weight: 700 !important; letter-spacing: 0.5px; color: #fff !important; transition: color 0.3s ease; }
      .navbar-brand:hover { color: #ccfffa !important; }
      #logoutBtn { background-color: #fff !important; color: var(--primary-color) !important; border-color: #fff !important; font-weight: bold; border-radius: 0.5rem; padding: 0.5rem 1rem !important; }
      #logoutBtn:hover { background-color: #f0f0f0 !important; color: var(--primary-dark) !important; }
      .navbar-toggler { border: 1px solid rgba(255,255,255,0.5); padding: 0.25rem 0.5rem; border-radius: 0.5rem; }
      .navbar-toggler-icon { filter: brightness(0) invert(1); }
    </style>

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-lg py-3">
      <div class="container-fluid container-lg">
        <a class="navbar-brand me-4" href="${origin}/index.html" style="font-size:1.4rem;">Jeevan Hospital</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarContent"
          aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarContent">
          <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
    `;

  // -------------------------
  // Menu Links per Role
  // -------------------------
  if (!role) {
    // Public visitor
    nav += `
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/#hero">Home</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/#about">About</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/#services">Services</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/#departments">Departments</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/#testimonials">Testimonials</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/#contact">Contact</a></li>
        `;
  } else if (role === 'PATIENT') {
    nav += `
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/patient/dashboard.html">Dashboard</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/patient/appointments.html">Appointments</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/patient/billing.html">Billing</a></li>
        `;
  } else if (role === 'DOCTOR') {
    nav += `
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/doctor/dashboard.html">Dashboard</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/doctor/appointments.html">Appointments</a></li>
        `;
  } else if (role === 'ADMIN') {
    nav += `
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/admin/dashboard.html">Dashboard</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/admin/patients.html">Patients</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/admin/doctors.html">Doctors</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/admin/appointments.html">Appointments</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/admin/billings.html">Billing</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/admin/users.html">Users</a></li>
        `;
  }

  nav += `</ul><ul class="navbar-nav ms-auto mb-2 mb-lg-0 align-items-lg-center">`;

  // -------------------------
  // Right-side buttons (login/logout)
  // -------------------------
  if (!role) {
    nav += `
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/login.html">Login</a></li>
            <li class="nav-item">
                <a class="nav-link btn btn-outline-light btn-sm ms-lg-2 mt-2 mt-lg-0 font-weight-bold" href="${origin}/register.html" style="border-radius: 0.5rem; padding: 0.5rem 1rem;">Register</a>
            </li>
        `;
  } else {
    nav += `
            <li class="nav-item"><a class="nav-link px-3" href="${origin}/change_password.html">Change Password</a></li>
            <li class="nav-item"><a class="nav-link ms-lg-2 mt-2 mt-lg-0" href="#" id="logoutBtn">Logout</a></li>
        `;
  }

  nav += `</ul></div></div></nav>`;

  // Inject navbar if the container exists
  const navbarContainer = document.getElementById('navbar');
  if (navbarContainer) navbarContainer.innerHTML = nav;
}

// -------------------------
// Authentication Check & Role Dispatcher
// -------------------------
$.ajax({
  url: `${base_url}/users/me`,
  method: 'GET',
  success: function (userData) {
    renderNavbar(userData.role);

    // Load role-specific entity and trigger page logic if defined
    if (userData.role === 'PATIENT') {
      $.get(`${base_url}/patients/me`)
        .done((data) => {
          window._patientEntity = data;
          $(document).trigger('patientEntityReady', [data]);
          if (typeof loadPatientPageLogic === 'function')
            loadPatientPageLogic(data);
        })
        .fail(() => console.error('Could not load patient entity data.'));
    } else if (userData.role === 'DOCTOR') {
      $.get(`${base_url}/doctors/me`)
        .done((data) => {
          window._doctorEntity = data;
          $(document).trigger('doctorEntityReady', [data]);
          if (typeof loadDoctorPageLogic === 'function')
            loadDoctorPageLogic(data);
        })
        .fail(() => console.error('Could not load doctor entity data.'));
    } else if (userData.role === 'ADMIN') {
      if (typeof loadAdminPageLogic === 'function')
        loadAdminPageLogic(userData);
    }
  },
  error: function (xhr) {
    renderNavbar(null);

    // Redirect unauthorized users away from protected paths
    const protectedPaths = ['/patient/', '/doctor/', '/admin/'];
    const currentPath = window.location.pathname;
    const isProtected = protectedPaths.some((path) =>
      currentPath.includes(path)
    );

    if (
      isProtected &&
      !currentPath.includes('/login.html') &&
      !currentPath.includes('/register.html')
    ) {
      window.location.href = '/login.html';
    }
  },
});

// -------------------------
// Logout Handler
// -------------------------
$(document).on('click', '#logoutBtn', function (e) {
  e.preventDefault();
  $.ajax({ url: `${base_url}/users/logout`, method: 'POST' }).done(
    () => (window.location.href = '/login.html')
  );
});

// -------------------------
// Custom Confirmation Modal
// -------------------------
let confirmCallback;

// Show a Bootstrap modal for confirmation with a callback
function showCustomConfirm(message, callback) {
  confirmCallback = callback;
  $('#customConfirmMessage').text(message);
  $('#customConfirmModal').modal('show');
}

$(function () {
  // User clicks "Yes" in the modal
  $('#customConfirmYes')
    .off('click')
    .on('click', function () {
      $('#customConfirmModal').modal('hide');
      if (confirmCallback) {
        confirmCallback(true);
        confirmCallback = null;
      }
    });

  // Reset callback if modal is closed without confirming
  $('#customConfirmModal').on('hidden.bs.modal', function () {
    confirmCallback = null;
  });
});
