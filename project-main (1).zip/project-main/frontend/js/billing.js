var base_url = 'http://localhost:8085/api';
$.ajaxSetup({ xhrFields: { withCredentials: true } });

$(document).ready(function () {
  // -------------------------
  // ADMIN BILLING TABLE
  // -------------------------
  if ($('#billsTable').length && window.location.pathname.includes('/admin/')) {
    $.get(`${base_url}/admin/billing`)
      .done(function (bills) {
        const tbody = $('#billsTable tbody').empty();

        bills.forEach(function (b) {
          let row = `<tr>
              <td>${b.billId}</td>
              <td>${b.appointmentId}</td>
              <td>${b.billDate}</td>
              <td>${b.billAmount}</td>
              <td>
                <span class="badge-status ${
                  b.paymentStatus === 'UNPAID'
                    ? 'status-PENDING'
                    : 'status-PAID'
                }">${b.paymentStatus}</span>
              </td>
              <td>`;

          if (b.paymentStatus === 'UNPAID') {
            row += `<button class="btn btn-sm btn-pay pay-bill" data-id="${b.billId}" data-amount="${b.billAmount}">Pay</button>`;
          }

          row += '</td></tr>';
          tbody.append(row);
        });

        if (bills.length === 0) {
          tbody.html(
            `<tr><td colspan="6" class="text-center py-4 text-muted">No bills found.</td></tr>`
          );
        }
      })
      .fail(function () {
        $('#billsTable tbody').html(
          `<tr><td colspan="6" class="text-center text-danger">Failed to load bills.</td></tr>`
        );
      });
  }

  // -------------------------
  // HANDLE BILL PAYMENT WITH MODAL
  // -------------------------
  $(document).on('click', '.pay-bill', function () {
    const billId = $(this).data('id');
    const billAmount = $(this).data('amount');

    $('#billIdDisplay').text(billId);
    $('#billAmountDisplay').text(billAmount);
    $('#confirmPayButton').data('id', billId);

    // Hide any previous error message
    $('#payConfirmModal .modal-body .text-danger').remove();

    $('#payConfirmModal').modal('show');
  });

  // Confirm payment button in modal
  $('#confirmPayButton').click(function () {
    const id = $(this).data('id');

    // Insert inline error message container
    let modalBody = $('#payConfirmModal .modal-body');
    modalBody.find('.text-danger').remove();

    if (!id) {
      modalBody.append('<p class="text-danger mt-2">No bill selected.</p>');
      return;
    }

    $.ajax({
      url: `${base_url}/admin/billing/${id}/pay`,
      method: 'POST',
      xhrFields: { withCredentials: true },
    })
      .done(function () {
        $('#payConfirmModal').modal('hide');
        location.reload();
      })
      .fail(function () {
        modalBody.append(
          '<p class="text-danger mt-2">Failed to process payment. Please try again.</p>'
        );
      });
  });
});
