package com.hms.entity;

import jakarta.persistence.*;
import java.util.Objects;

@Entity
@Table(name="patients")
public class Patient {
  @Id
  @Column(length=100)
  private String id;           // same as username for login to keep things simple

  private String name;
  private String address;
  private String contactNumber;
  private String dateOfBirth;
  private String gender;

  @Lob
  private String medicalHistory;

  public String getId() { return id; }
  public void setId(String id) { this.id = id; }
  public String getName() { return name; }
  public void setName(String name) { this.name = name; }
  public String getAddress() { return address; }
  public void setAddress(String address) { this.address = address; }
  public String getContactNumber() { return contactNumber; }
  public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }
  public String getDateOfBirth() { return dateOfBirth; }
  public void setDateOfBirth(String dateOfBirth) { this.dateOfBirth = dateOfBirth; }
  public String getGender() { return gender; }
  public void setGender(String gender) { this.gender = gender; }
  public String getMedicalHistory() { return medicalHistory; }
  public void setMedicalHistory(String medicalHistory) { this.medicalHistory = medicalHistory; }

  @Override public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof Patient)) return false;
    Patient p = (Patient) o;
    return Objects.equals(id, p.id);
  }
  @Override public int hashCode() { return Objects.hash(id); }
}
