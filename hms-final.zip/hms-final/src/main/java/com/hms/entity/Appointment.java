package com.hms.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.Objects;

@Entity
@Table(name="appointments")
public class Appointment {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  // store patientId as Patient.id
  @Column(nullable=false, length=100)
  private String patientId;

  // store doctorId as Doctor.id
  @Column(nullable=false)
  private Long doctorId;

  private LocalDate appointmentDate; // yyyy-MM-dd
  private String appointmentTime;    // "09:30 AM"

  private Integer fee;               // snapshot of fee
  private String status;             // SCHEDULED/CONFIRMED/CHECKED_IN/COMPLETED/CANCELLED
  private String paidStatus;         // UNPAID/PARTIAL/PAID

  private String type;               // New / Old (optional)
  private String notes;              // optional

  public Long getId() { return id; }
  public void setId(Long id) { this.id = id; }
  public String getPatientId() { return patientId; }
  public void setPatientId(String patientId) { this.patientId = patientId; }
  public Long getDoctorId() { return doctorId; }
  public void setDoctorId(Long doctorId) { this.doctorId = doctorId; }
  public LocalDate getAppointmentDate() { return appointmentDate; }
  public void setAppointmentDate(LocalDate appointmentDate) { this.appointmentDate = appointmentDate; }
  public String getAppointmentTime() { return appointmentTime; }
  public void setAppointmentTime(String appointmentTime) { this.appointmentTime = appointmentTime; }
  public Integer getFee() { return fee; }
  public void setFee(Integer fee) { this.fee = fee; }
  public String getStatus() { return status; }
  public void setStatus(String status) { this.status = status; }
  public String getPaidStatus() { return paidStatus; }
  public void setPaidStatus(String paidStatus) { this.paidStatus = paidStatus; }
  public String getType() { return type; }
  public void setType(String type) { this.type = type; }
  public String getNotes() { return notes; }
  public void setNotes(String notes) { this.notes = notes; }

  @Override public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof Appointment)) return false;
    Appointment that = (Appointment) o;
    return Objects.equals(id, that.id);
  }
  @Override public int hashCode() { return Objects.hash(id); }
}