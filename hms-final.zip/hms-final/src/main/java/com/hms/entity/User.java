package com.hms.entity;

import jakarta.persistence.*;
import java.util.Objects;

@Entity
@Table(name="users")
public class User {
  @Id
  @Column(length = 100)
  private String username;              

  @Column(nullable = false)
  private String password;              

  @Column(nullable = false, length = 30)
  private String role;                  

  private String name;
  private String address;
  private String contactNumber;
  private String dateOfBirth;
  private String gender;

  @Lob
  private String medicalHistory;

  public String getUsername() { return username; }
  public void setUsername(String username) { this.username = username; }
  public String getPassword() { return password; }
  public void setPassword(String password) { this.password = password; }
  public String getRole() { return role; }
  public void setRole(String role) { this.role = role; }
  public String getName() { return name; }
  public void setName(String name) { this.name = name; }
  public String getAddress() { return address; }
  public void setAddress(String address) { this.address = address; }
  public String getContactNumber() { return contactNumber; }
  public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }
  public String getDateOfBirth() { return dateOfBirth; }
  public void setDateOfBirth(String dateOfBirth) { this.dateOfBirth = dateOfBirth; }
  public String getGender() { return gender; }
  public void setGender(String gender) { this.gender = gender; }
  public String getMedicalHistory() { return medicalHistory; }
  public void setMedicalHistory(String medicalHistory) { this.medicalHistory = medicalHistory; }

  @Override public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof User)) return false;
    User user = (User) o;
    return Objects.equals(username, user.username);
  }
  @Override public int hashCode() { return Objects.hash(username); }
}