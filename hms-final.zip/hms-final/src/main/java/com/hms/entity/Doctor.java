package com.hms.entity;

import jakarta.persistence.*;
import java.util.Objects;

@Entity
@Table(name="doctors")
public class Doctor {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(nullable=false)
  private String name;

  // "MBBS" or "MD" etc.
  @Column(nullable=false)
  private String qualification;

  // can be null initially (admin UI says MBBS-only ok)
  private String specialization;

  private Integer fee; // consultation fee

  // stored as JSON-ish text for simplicity (weekly availability)
  @Lob
  private String scheduleJson;

  // Link to login username (optional convenience)
  private String userRef; // equals User.username if a doctor has login

  public Long getId() { return id; }
  public void setId(Long id) { this.id = id; }
  public String getName() { return name; }
  public void setName(String name) { this.name = name; }
  public String getQualification() { return qualification; }
  public void setQualification(String qualification) { this.qualification = qualification; }
  public String getSpecialization() { return specialization; }
  public void setSpecialization(String specialization) { this.specialization = specialization; }
  public Integer getFee() { return fee; }
  public void setFee(Integer fee) { this.fee = fee; }
  public String getScheduleJson() { return scheduleJson; }
  public void setScheduleJson(String scheduleJson) { this.scheduleJson = scheduleJson; }
  public String getUserRef() { return userRef; }
  public void setUserRef(String userRef) { this.userRef = userRef; }

  @Override public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof Doctor)) return false;
    Doctor doctor = (Doctor) o;
    return Objects.equals(id, doctor.id);
  }
  @Override public int hashCode() { return Objects.hash(id); }
}