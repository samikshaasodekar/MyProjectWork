package com.hms;

import com.hms.service.DepartmentService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HmsFinalApplication implements CommandLineRunner {

    private final DepartmentService departmentService;

    public HmsFinalApplication(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    public static void main(String[] args) {
        SpringApplication.run(HmsFinalApplication.class, args);
    }

    @Override
    public void run(String... args) {
        // Seed departments only if table is empty
        departmentService.seedIfEmpty();
    }
}
