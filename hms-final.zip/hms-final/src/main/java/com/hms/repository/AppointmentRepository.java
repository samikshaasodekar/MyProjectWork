package com.hms.repository;

import com.hms.entity.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
  List<Appointment> findByDoctorId(Long doctorId);
  List<Appointment> findByPatientId(String patientId);
  List<Appointment> findByAppointmentDate(LocalDate date);
}
