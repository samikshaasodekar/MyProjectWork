package com.hms.security;

import com.hms.entity.User;
import com.hms.repository.UserRepository;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

  private final UserRepository userRepo;

  public SecurityConfig(UserRepository userRepo) {
    this.userRepo = userRepo;
  }

  @Bean
  public PasswordEncoder passwordEncoder(){
    return new BCryptPasswordEncoder();
  }

  @Bean
  public UserDetailsService userDetailsService(){
    return username -> {
      User u = userRepo.findById(username)
        .orElseThrow(() -> new UsernameNotFoundException("User not found"));
      return org.springframework.security.core.userdetails.User
        .withUsername(u.getUsername())
        .password(u.getPassword())
        .roles(u.getRole().replace("ROLE_",""))
        .build();
    };
  }

  @Bean
  public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    http
      .csrf(csrf -> csrf.disable())
      .authorizeHttpRequests(auth -> auth
        // static frontend
        .requestMatchers("/", "/index.html", "/login.html", "/register.html",
                         "/admin.html", "/doctor.html", "/patient.html",
                         "/css/**", "/js/**", "/images/**").permitAll()
        // public registration endpoint
        .requestMatchers("/api/v1/auth/register").permitAll()
        // who am i requires basic
        .requestMatchers("/api/v1/auth/me").authenticated()
        // APIs
        .requestMatchers("/doctors/**", "/appointments/**", "/patients/**").authenticated()
        .anyRequest().permitAll()
      )
      .httpBasic(Customizer.withDefaults())
      .formLogin(form -> form.disable());
    return http.build();
  }
}
