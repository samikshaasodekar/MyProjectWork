package com.hms.controller;

import com.hms.entity.Patient;
import com.hms.entity.User;
import com.hms.dto.RegisterRequest;
import com.hms.repository.PatientRepository;
import com.hms.repository.UserRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

  private final UserRepository userRepo;
  private final PatientRepository patientRepo;
  private final PasswordEncoder encoder;

  public AuthController(UserRepository userRepo, PatientRepository patientRepo, PasswordEncoder encoder) {
    this.userRepo = userRepo;
    this.patientRepo = patientRepo;
    this.encoder = encoder;
  }

  // Public registration (your frontends call this)
  @PostMapping("/register")
  public ResponseEntity<?> register(@Valid @RequestBody RegisterRequest req) {
    if (userRepo.existsById(req.getUsername())) {
      return ResponseEntity.badRequest().body(
        java.util.Map.of("error","Username already exists"));
    }

    String role = (req.getRole() == null || req.getRole().isBlank())
      ? "PATIENT" : req.getRole().toUpperCase();

    User u = new User();
    u.setUsername(req.getUsername());
    u.setPassword(encoder.encode(req.getPassword()));
    u.setRole(role.startsWith("ROLE_") ? role : "ROLE_"+role);
    u.setName(req.getName());
    u.setAddress(req.getAddress());
    u.setContactNumber(req.getContactNumber());
    u.setDateOfBirth(req.getDateOfBirth());
    u.setGender(req.getGender());
    u.setMedicalHistory(req.getMedicalHistory());
    userRepo.save(u);

    // if a patient, also maintain Patient table for listing etc.
    if (u.getRole().equals("ROLE_PATIENT")) {
      Patient p = new Patient();
      p.setId(u.getUsername());
      p.setName(u.getName());
      p.setAddress(u.getAddress());
      p.setContactNumber(u.getContactNumber());
      p.setDateOfBirth(u.getDateOfBirth());
      p.setGender(u.getGender());
      p.setMedicalHistory(u.getMedicalHistory());
      patientRepo.save(p);
    }

    return ResponseEntity.ok(java.util.Map.of("message","registered"));
  }

  // Basic-auth check (frontend uses this to route by role)
  @GetMapping("/me")
  public ResponseEntity<?> me(Authentication auth) {
    if (auth == null) return ResponseEntity.status(401).build();
    return userRepo.findById(auth.getName())
      .<ResponseEntity<?>>map(u -> ResponseEntity.ok(
        java.util.Map.of(
          "username", u.getUsername(),
          "role", u.getRole(),
          "name", u.getName()
        )))
      .orElseGet(() -> ResponseEntity.status(404).build());
  }
}

