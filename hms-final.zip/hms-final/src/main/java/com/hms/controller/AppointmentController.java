package com.hms.controller;

import com.hms.entity.Appointment;
import com.hms.repository.AppointmentRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;

@RestController
@RequestMapping("/appointments")
public class AppointmentController {
  private final AppointmentRepository repo;

  public AppointmentController(AppointmentRepository repo) { this.repo = repo; }

  @GetMapping
  public List<Appointment> all() { return repo.findAll(); }

  @GetMapping("/{id}")
  public ResponseEntity<Appointment> get(@PathVariable Long id) {
    return repo.findById(id).map(ResponseEntity::ok)
      .orElse(ResponseEntity.notFound().build());
  }

  @PostMapping
  public Appointment create(@RequestBody Appointment a) {
    if (a.getStatus()==null || a.getStatus().isBlank()) a.setStatus("SCHEDULED");
    if (a.getPaidStatus()==null || a.getPaidStatus().isBlank()) a.setPaidStatus("UNPAID");
    return repo.save(a);
  }

  @PutMapping("/{id}")
  public ResponseEntity<Appointment> update(@PathVariable Long id, @RequestBody Appointment a) {
    return repo.findById(id).map(ex -> {
      ex.setPatientId(a.getPatientId());
      ex.setDoctorId(a.getDoctorId());
      ex.setAppointmentDate(a.getAppointmentDate());
      ex.setAppointmentTime(a.getAppointmentTime());
      ex.setFee(a.getFee());
      ex.setStatus(a.getStatus());
      ex.setPaidStatus(a.getPaidStatus());
      ex.setType(a.getType());
      ex.setNotes(a.getNotes());
      return ResponseEntity.ok(repo.save(ex));
    }).orElse(ResponseEntity.notFound().build());
  }

  // update status
  @PutMapping("/{id}/status")
  public ResponseEntity<?> updateStatus(@PathVariable Long id, @RequestParam String status) {
    return repo.findById(id).map(ex -> {
      ex.setStatus(status);
      repo.save(ex);
      return ResponseEntity.ok().build();
    }).orElse(ResponseEntity.notFound().build());
  }

  // update payment
  @PutMapping("/{id}/payment")
  public ResponseEntity<?> updatePayment(@PathVariable Long id, @RequestParam String paidStatus) {
    return repo.findById(id).map(ex -> {
      ex.setPaidStatus(paidStatus);
      repo.save(ex);
      return ResponseEntity.ok().build();
    }).orElse(ResponseEntity.notFound().build());
  }

  // by doctor
  @GetMapping("/by-doctor/{doctorId}")
  public List<Appointment> byDoctor(@PathVariable Long doctorId) {
    return repo.findByDoctorId(doctorId);
  }

  // today
  @GetMapping("/today")
  public List<Appointment> today() {
    return repo.findByAppointmentDate(LocalDate.now());
  }
}

