package com.hms.controller;

import com.hms.entity.Doctor;
import com.hms.repository.DoctorRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/doctors")
public class DoctorController {
  private final DoctorRepository repo;

  public DoctorController(DoctorRepository repo) { this.repo = repo; }

  @GetMapping
  public List<Doctor> all() { return repo.findAll(); }

  @GetMapping("/{id}")
  public ResponseEntity<Doctor> get(@PathVariable Long id) {
    return repo.findById(id).map(ResponseEntity::ok)
      .orElse(ResponseEntity.notFound().build());
  }

  @PostMapping
  public Doctor create(@RequestBody Doctor d) {
    if (d.getQualification()==null || d.getQualification().isBlank()) d.setQualification("MBBS");
    if (d.getFee()==null) d.setFee(500);
    return repo.save(d);
  }

  @PutMapping("/{id}")
  public ResponseEntity<Doctor> update(@PathVariable Long id, @RequestBody Doctor d) {
    return repo.findById(id).map(ex -> {
      ex.setName(d.getName()!=null?d.getName():ex.getName());
      ex.setQualification(d.getQualification()!=null?d.getQualification():ex.getQualification());
      ex.setSpecialization(d.getSpecialization());
      ex.setFee(d.getFee()!=null?d.getFee():ex.getFee());
      ex.setScheduleJson(d.getScheduleJson());
      ex.setUserRef(d.getUserRef()!=null?d.getUserRef():ex.getUserRef());
      return ResponseEntity.ok(repo.save(ex));
    }).orElse(ResponseEntity.notFound().build());
  }

  // Schedules: store raw JSON string (frontend sends { availabilityType:'WEEKLY', weekly:{...} })
  @GetMapping("/{id}/schedule")
  public ResponseEntity<?> getSchedule(@PathVariable Long id) {
    return repo.findById(id).<ResponseEntity<?>>map(d -> {
      String json = d.getScheduleJson();
      if (json == null || json.isBlank()) json = "{\"availabilityType\":\"WEEKLY\",\"weekly\":{}}";
      return ResponseEntity.ok(json);
    }).orElse(ResponseEntity.notFound().build());
  }

  @PutMapping("/{id}/schedule")
  public ResponseEntity<?> putSchedule(@PathVariable Long id, @RequestBody String json) {
    return repo.findById(id).map(d -> {
      d.setScheduleJson(json);
      repo.save(d);
      return ResponseEntity.ok().build();
    }).orElse(ResponseEntity.notFound().build());
  }

  // search helpers
  @GetMapping("/search")
  public List<Doctor> search(@RequestParam Optional<String> name,
                             @RequestParam Optional<String> specialization) {
    if (name.isPresent()) return repo.findByNameContainingIgnoreCase(name.get());
    if (specialization.isPresent()) return repo.findBySpecializationContainingIgnoreCase(specialization.get());
    return repo.findAll();
  }
}

