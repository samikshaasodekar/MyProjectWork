package com.hms.controller;

import com.hms.entity.Patient;
import com.hms.repository.PatientRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/patients")
public class PatientController {
  private final PatientRepository repo;

  public PatientController(PatientRepository repo) { this.repo = repo; }

  @GetMapping
  public List<Patient> all() { return repo.findAll(); }

  @GetMapping("/{id}")
  public Patient get(@PathVariable String id) {
    return repo.findById(id).orElse(null);
  }

  @PutMapping("/{id}")
  public Patient update(@PathVariable String id, @RequestBody Patient p) {
    return repo.findById(id).map(ex -> {
      ex.setName(p.getName());
      ex.setAddress(p.getAddress());
      ex.setContactNumber(p.getContactNumber());
      ex.setDateOfBirth(p.getDateOfBirth());
      ex.setGender(p.getGender());
      ex.setMedicalHistory(p.getMedicalHistory());
      return repo.save(ex);
    }).orElse(null);
  }
}

