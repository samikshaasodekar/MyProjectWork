package com.hms.dto;

import jakarta.validation.constraints.NotBlank;

public class RegisterRequest {
  @NotBlank
  private String username;
  @NotBlank
  private String password;

  // optional patient profile inputs
  private String name;
  private String address;
  private String contactNumber;
  private String dateOfBirth;
  private String gender;
  private String medicalHistory;

  // "PATIENT" | "DOCTOR" | "ADMIN" (default PATIENT from your UI)
  private String role;

  public String getUsername() { return username; }
  public void setUsername(String username) { this.username = username; }
  public String getPassword() { return password; }
  public void setPassword(String password) { this.password = password; }
  public String getName() { return name; }
  public void setName(String name) { this.name = name; }
  public String getAddress() { return address; }
  public void setAddress(String address) { this.address = address; }
  public String getContactNumber() { return contactNumber; }
  public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }
  public String getDateOfBirth() { return dateOfBirth; }
  public void setDateOfBirth(String dateOfBirth) { this.dateOfBirth = dateOfBirth; }
  public String getGender() { return gender; }
  public void setGender(String gender) { this.gender = gender; }
  public String getMedicalHistory() { return medicalHistory; }
  public void setMedicalHistory(String medicalHistory) { this.medicalHistory = medicalHistory; }
  public String getRole() { return role; }
  public void setRole(String role) { this.role = role; }
}