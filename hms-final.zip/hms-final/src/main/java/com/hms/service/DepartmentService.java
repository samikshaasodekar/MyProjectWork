package com.hms.service;

import com.hms.entity.Department;
import com.hms.repository.DepartmentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentService {
    private final DepartmentRepository repo;

    public DepartmentService(DepartmentRepository repo) {
        this.repo = repo;
    }

    public List<Department> getAll() {
        return repo.findAll();
    }

    public Department saveIfMissing(String name) {
        return repo.findByNameIgnoreCase(name).orElseGet(() -> repo.save(new Department(name)));
    }

    public void seedIfEmpty() {
        if (repo.count() > 0) return;

        List<String> names = List.of(
            "Accident & Emergency",
            "Anesthesiology",
            "Bariatric & Metabolic Surgery",
            "Cardiac Sciences",
            "Hematology",
            "Critical Care Unit",
            "Dentistry",
            "Dermatology & Cosmetology",
            "Dietetics & Nutrition (Lifestyle)",
            "Endocrinology & Diabetology",
            "Fetal & Genetic Medicine",
            "Gastroscience",
            "General Surgery",
            "GI Surgery",
            "Hepatology and Liver transplantation",
            "Interventional Radiology",
            "Internal Medicine",
            "Infectious Disease",
            "IVF & Reproductive Medicine",
            "Medical Oncology",
            "Nephrology & Renal transplant",
            "Neuroscience",
            "Nuclear Medicine",
            "Obstetrics & Gynae",
            "Ophthalmology",
            "Oral & Maxillofacial",
            "Organ Transplant",
            "Orthopaedic",
            "ENT (Ear, Nose, Throat)",
            "Proctology",
            "Physiotherapy & Rehabilitation",
            "Plastic & Reconstructive Surgery",
            "Psychiatry",
            "Paediatrics",
            "Pulmonary Medicine",
            "Pain Management",
            "Robotic Assisted Surgery",
            "Radiation Oncology",
            "Rheumatology & Immunology",
            "Surgical Oncology",
            "Transfusion Medicine",
            "Urology",
            "Vascular Surgery",
            "Wellness"
        );
        names.forEach(this::saveIfMissing);
        System.out.println("✅ Departments seeded: " + names.size());
    }
}

