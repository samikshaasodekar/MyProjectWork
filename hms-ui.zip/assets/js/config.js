// ==== CONFIG ====
const BASE_URL = 'http://localhost:8082';
function setAuth(u, p, role){
  const token = btoa(u + ':' + p);
  localStorage.setItem('hms_auth', token);
  localStorage.setItem('hms_user', u);
  if(role) localStorage.setItem('hms_role', role);
}
function clearAuth(){
  localStorage.removeItem('hms_auth');
  localStorage.removeItem('hms_user');
  localStorage.removeItem('hms_role');
}
function getAuthHeader(){
  const t = localStorage.getItem('hms_auth');
  return t ? {'Authorization': 'Basic ' + t} : {};
}
async function api(url, method='GET', body=null){
  const headers = Object.assign({'Content-Type':'application/json'}, getAuthHeader());
  const res = await fetch(BASE_URL + url, { method, headers, body: body? JSON.stringify(body): null });
  const data = await res.json().catch(()=>({}));
  if(!res.ok){ throw new Error(data.message || ('HTTP '+res.status)); }
  return data;
}
function toast(msg, isOk=true){ alert((isOk?'✅ ':'❌ ') + msg); }
function requireRole(roles){
  const r = localStorage.getItem('hms_role');
  if(!r || roles.indexOf(r)===-1){ window.location.href='login.html'; }
}
